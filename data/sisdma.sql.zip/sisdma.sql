-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 17-Nov-2014 às 06:20
-- Versão do servidor: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sisdma`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

CREATE TABLE IF NOT EXISTS `agenda` (
  `id_agenda` int(9) NOT NULL AUTO_INCREMENT,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `text` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `convidados` text NOT NULL,
  `event_location` text NOT NULL,
  PRIMARY KEY (`id_agenda`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Extraindo dados da tabela `agenda`
--

INSERT INTO `agenda` (`id_agenda`, `start_date`, `end_date`, `text`, `details`, `convidados`, `event_location`) VALUES
(1, '2014-11-17 10:00:00', '2014-11-17 15:00:00', 'Título do Evento', 'Descrição do Evento', 'Fulano, Cicrano, Beltrano', 'IPLANFOR');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos`
--

CREATE TABLE IF NOT EXISTS `contatos` (
  `idcontatos` int(11) NOT NULL AUTO_INCREMENT,
  `nomecontatos` varchar(255) NOT NULL,
  `siglacontatos` varchar(255) DEFAULT NULL,
  `orgaocontatos` varchar(255) DEFAULT NULL,
  `enderecoorgao` varchar(255) DEFAULT NULL,
  `telefone` varchar(255) DEFAULT NULL,
  `ramalfone` varchar(255) DEFAULT NULL,
  `emailcontato` varchar(255) DEFAULT NULL,
  `celcontato` varchar(255) DEFAULT NULL,
  `cargocontato` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idcontatos`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Tabela de Contatos	' AUTO_INCREMENT=469 ;

--
-- Extraindo dados da tabela `contatos`
--

INSERT INTO `contatos` (`idcontatos`, `nomecontatos`, `siglacontatos`, `orgaocontatos`, `enderecoorgao`, `telefone`, `ramalfone`, `emailcontato`, `celcontato`, `cargocontato`) VALUES
(1, 'Fabricio Mendes', '----', 'Projeto Pirambu Digital', '----', '(85)3236-0541', '----', 'fabricio.mendes.ti@gmail.com', '(85)9981-7163', 'Presidente'),
(2, 'Ronaldo Ramos', '----', 'Craff Tecnologia', '----', '----', '----', 'ronaldo.ramos@gmail.com', '(85) 8821-5525', '-'),
(3, 'Alexandre Neto ', '-----', '----', '----', '----', '----', '----', '----', '----'),
(4, 'Annia Saboya ', '-----', '----', '----', '(85)3105-1356', '----', 'annia.saboya@fortaleza.ce.gov.br', '(85)8970-4549', '----'),
(5, 'Chico Mauro', '-----', 'Craff Tecnologia', '----', '----', '----', 'chmauro@fortalnet.com.br', '(85)99840577', '----'),
(6, 'Ayrton', '-----', '-----', '-----', '-----', '----', 'ayrton@nucleo.infor.com.br', '----', '----'),
(7, 'Dr. Francisco Carlos Moraes (Chiquinho)', '-----', '-----', '-----', '(085)3466-4880', '4881', '----', '----', '-'),
(8, 'Eduardo Fontenele', '-----', '-----', '-----', '(85) 3452 4562', '----', 'eduardo.fontenele@fortaleza.ce.gov.br', '(85)8895 5682', 'Assessor '),
(9, 'Fatima Aragão', '-----', '-----', '-----', '-', '----', 'fatima.aragao@fortaleza.ce.gov.br', '----', '----'),
(10, 'Reubem Azevedo Damasceno Gabriel', '-----', 'Gabinete do Vice-Prefeito', '-----', '(85) 3452-4659', '----', 'reubem.azevedo@fortaleza.ce.gov.br', '----', 'Coordenador técnico Financeiro'),
(11, 'Socorro Aranha/Cleneide', '-----', '-----', '-----', '(085)3105-1446', '(085)3105-1447', '----', '----', 'Assessoras'),
(12, 'Livia Regueira', '-----', '-----', '-----', '(85) 3105-1378', '-----', '-----', '-----', '-'),
(13, 'Ednelda', '-----', 'Escola Papa João XXIII', 'Rua 13 de Abril, 595 - Vila União', '(85) 3131-7712', '----', '-', '----', 'Diretora'),
(14, 'Margarete', '-----', 'Escola Papa João XXIII', 'Rua 13 de Abril, 595 - Vila União', '(85) 3131-7712', '----', '----', '----', 'Secretaria'),
(15, 'Cristiane Mourão Carvalhedo', '-----', 'UAPS CLODOALDO PINTO', 'Rua Banward Bezerra, nº 100 - Padre Andrade', '----', '----', 'crismcarvalhedo@hotmail.com', '(85)9991-9718', 'Gestor do posto de saúde'),
(16, 'Juliana Noronha', '-----', 'UAPS WALDO PESSOA - SER VI', 'RUA CAPITAO HUGO BEZERRA – BARROSO', '----', '----', 'julianacnmedeiros@hotmail.com', '(85)8730-2148', 'Gestor do posto de saúde'),
(17, 'Carlos Eduardo de Sousa Praxedes', '-----', 'UAPS MESSEJANA - SER VI', 'Rua Coronel Guilherme Alencar, s/ nº – Messejana', '-', '-', 'cpraxedes@sms.fortaleza.ce.gov.br/sousa praxedes@ig.com.br', '(85)9197-3602', 'Gestor do posto de saúde'),
(18, 'Carla Eduvia Viana Vasconcelos', '-----', 'Posto de Saúde Anísio Teixeira', 'Rua Guarani, 355. Messejana. Fica próximo a BR 116', '-----', '----', 'carlaeduvia@gmail.com', ' (85) 88865132', 'Coordenadora'),
(19, 'Minuchy Mendes Carneiro Alves', '-----', 'UAPS HUMBERTO BEZERRA - SER III ', 'Rua Hugo Victor, 51 - Antonio Bezerra', '----', '----', 'minuchy.mendes@hotmail.com', '(85)9998-9893/ (85)8833-0682', 'Gestor do posto de saúde'),
(20, 'Draurio Pinho', '-----', '-----', 'Rua Pinto Madeira 535 Sl-29/30, Centro', '(085)3253 1546', '----', '----', '----', '----'),
(21, 'Maria Isabel Litwak Nascimento', '-----', 'UAPS ARGEU HERBSTER - SER V', 'Rua Coronel João Corrêia,728, Bom Jardim', '----', '----', 'isalit22@yahoo.com.br', '----', 'Gestor do posto de saúde'),
(22, 'Talita Melo', ' Assessoria Jurídica ', ' Assessoria Jurídica ', '-----', '----', '----', 'talita.melo@fortaleza.ce.gov.br', '----', 'secretaria '),
(23, 'Fabio Braga Nunes', 'ABACUS', 'Empresa de solftwer', 'Rua Osvaldo Cruz, 1614 – Sala 2', '----', '---', 'fabio@abacus.net.br', '(85) 9181-3223', '----'),
(24, 'Leon Gardeon', 'ABACUS', 'Empresa de solftwer', 'Rua Osvaldo Cruz, 1614 – Sala 2', '(085)3244-1531', '----', 'leongardel@gmail.com', '96935300', '----'),
(25, 'Homero Carls Silva', 'ACFORA', 'Autarquia de Regulação ,Fiscalização e Controle dos Serviços Públicos de Saneamento Ambiental', 'Av.Antonio Sales,1885- Sobre loja ', '(085)3433-2789', '----', 'maribarreirasoares@gmail.com', '----', 'Presidente'),
(26, 'Jorge Cunha', 'Alberflex', 'Alberflex', '----', '----', '----', '----', '(85) 9900-2688', '----'),
(27, 'andre lira', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3488-5733', '----', 'andre.lira@fortaleza.ce.gov.br', '----', '----'),
(28, 'André Lira', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(85) 3488-5737', '----', 'andre.lira@fortaleza.ce.gov.br', '----', 'Gestro de TI'),
(29, 'DR. ROMULO', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3488 3201 ', '/02', 'romulo.montezuma@fortaleza.ce.gov.br', '----', 'COORDENADOR '),
(30, 'Nazaré ', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3433-9717', '(085)3433-9734', '----', '----', '----'),
(31, 'Rosina ', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(85) 3488-5724 ', '----', 'gpa.amc@gmail.com', '----', 'Gerente de Planejamento e Análise'),
(32, 'Vitor Cosmo Ciasca Neto ', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3433-9734', '9732', 'vitor.ciasca@fortaleza.ce.gov.br', '----', 'Presidente '),
(33, 'André Garcia Xerez ', 'Assessor Juridico ', 'Assessor Juridico ', '-----', '085-3105-1367', '----', 'andre.xerez@fortaleza.ce.gov.br', '----', '----'),
(34, 'Evilene', 'ATENÇÃO BASICA', 'Atenção Básica  a familia ', 'Rua do Rosário ,283,2ºe 3º.Andar - Centro ', '(085)3452-6966', '----', '----', '----', '----'),
(35, 'Chico', 'Atlantico', 'Instituto atlântico', '---', '(85)3216-7967/3216-7976', '-', 'chicos@atlantico.com.br', '(85)9603-8001', '-'),
(36, 'Cilis', 'Atlantico', 'Instituto atlântico', '-', '(85)3276-7836', '-', 'cilis.benevides@gmail.com', '(85)8802-8529', '-'),
(37, 'Emanuela Jordânia', 'Atlantico', 'Instituto atlântico', '-', '(85)3276-7836', '----', 'emanuelajord@gmail.com / emanuela.costa@fortaleza.ce.gov.br', '(85) 8703-7831', 'Analista de Sistema'),
(38, 'Asier Ansorena', 'Banco Palmas', '-----', '-----', '(85) 3459-4848 ', '----', 'asier@bancopalmas.org.br', '(85) 8916-4876', '----'),
(39, 'Sol', 'Banco Palmas', '-----', '-----', '(85) 3459-4848 ', '----', '----', '(85) 8772-1419', '----'),
(40, 'Ayrton Saboia', 'BNB', '-', '-', '(85)3251-7177', '-', 'airtonjr@bnb.gov.br', '(85)8838-4420', '-'),
(41, 'Uchoa', 'CADIC', 'Cadic Brasil', ' Rua Marcos Macêdo, 1333 - Aldeota', '(85) 3268-3639', '----', 'uchoa@cadicbrasil.com.br', '----', '----'),
(42, 'Lucirene Araújo Maciel', 'CÉLULA DE JORNALISMO', 'Célula de Jornalismo ', 'Rua São José,01 - Centro ', '(085)3105-1441', '1446', 'lucirenemaciel@gmail.com', '----', 'Célula de Jornalismo'),
(43, 'Eduardo Martins da Silva', 'Central de Licitações', '----', '----', '----', '----', 'eduardo.martins@fortaleza.ce.gov.br\ndumartinsm@yahoo.com.br', '(85)9206-3297', 'Assistente Técnico - pregoeiro'),
(44, 'Francisco Fábio Santiago', 'Central de Licitações', '----', '----', '(85)3105-1157', '----', 'fabio.santiago@fortaleza.ce.gov.br\nsantiago.fabio@hotmail.com', '(85)9175-3703', 'Assessor de Banco de Dados'),
(45, 'Camila Freitas', 'Central de Licitações', '----', '----', '(85)3452-3474', '----', 'camilahollanda@hotmail.com.br', '(85)9749-0401', 'Assessor Técnico'),
(46, 'Benedita Lino', 'Central de Licitações', '----', '----', '(85)3105-1157', '----', 'licita.comprafortaleza@hotmail.com', '(85)3105-1157', '-'),
(47, 'Samuel Alexandre', 'Central de Licitações', '----', '----', '(85)3452-3474', '----', 'samuelallexandre@hotmail.com', '(85)9932-3876', 'Assistente Pregoeiro'),
(48, 'Fernanda Fernandes', 'CEPPJ', 'COORDENADORIA ESPECIAL DE POLÍTICAS PÚBLICAS PARA JUVENTUDE', 'Av. Luciano Carneiro, 2235 – Vila União', '(85) 3452-4657', '----', 'fernanda.fernandes@fortaleza.ce.gov.br / fernandaassisfernandes@hotmail.com', '(85) 8868-7070', 'Assessora Jurídica'),
(49, 'Dora - Secretaria', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '(85) 3452-6181', '----', 'dora.bessa@fortaleza.ce.gov.br', '89704864', '----'),
(50, 'Professor Vasco', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '(85) 3452-6181', '----', 'furtado.vasco@fortaleza.ce.gov.br/furtado.vasco@gmail.com', '99978951', '----'),
(51, 'Tarcisio Pequeno ', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '(85) 3452-6181', '----', 'tarcisiopequeno@gmail.com', '----', 'Coordenador '),
(52, 'Professora Wládia', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '-', '-', '-', '(85) 9994-5287', '-'),
(53, 'Erick Medrado', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3452-3472', '----', 'erick.medrado@fortaleza.ce.gov.br', '(085) 8898-5353', '----'),
(54, 'Haroldo Albuquerque Maranhão de Oliveira ', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'haroldo.maranhao@fortaleza.ce.gov.br', '(085)8970-3033', 'Coordenador geral'),
(55, 'Igor Leite', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3452-3430', '-', 'igor.leite@fortaleza.ce.gov.br', '(85)8970-6139', '-'),
(56, 'Hermes Lima De Oliveira', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'hermes.oliveira@fortaleza.ce.gov.br', '(085) 8970 4071/9996 3221', '-'),
(57, 'Jonas Cavalcanti Neto', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'jonascavalcantineto@gmail.com / jonas.neto@fortaleza.ce.gov.br', '(85) 8687-2577', 'Desenvolvedor'),
(58, 'Luiz Carlos A Maia', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'luiz.maia@fortaleza.ce.gov.br', '(085) 97251730', '----'),
(59, 'Mikaely Greggio', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(85) 3452.3430', '----', 'mikaely.greggio@fortaleza.ce.gov.bR', '(85) 8970-3494', '----'),
(60, 'Bruno Tinoco', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3430', '----', 'bruno.tinoco@fortaleza.ce.gov.br', '(85) 86303442', '----'),
(61, 'Verônica Aguiar', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(85) 3452-3430', '(85) 3452-3472', 'veronica.aguiar@fortaleza.ce.gov.br', '----', '----'),
(62, 'Italo Alencar', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '-', '-', 'italo.alencar@fortaleza.ce.gov.br', '(85) 8970-3726/(85) 8949-0845', '-'),
(63, 'Max Chagas', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3452-3472', '----', 'maxlane.chagas@fortaleza.ce.gov.br', '-', '-'),
(64, 'Sullivan Estrela ', 'COGECT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '(085)3452 - 6773 / 6777', '----', 'sullivan.estrela@fortaleza.ce.gov.br', '(085)86072191/9813-2814', '----'),
(65, 'Sergio Gomes Cavalcante ', 'COID', 'Coordenadoria Especial do Idoso ', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3452-2344', '----', 'relacoespublicas@hotmail.com', '----', 'Coordenador'),
(66, 'Lucas Gurgel', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av. Luciano Carneiro, 2235 – Vila União                 ', '(085)3254-5376', '----', 'LUCAS.GURGEL@FORTALEZA.CE.GOV.BR', '(085)8819-1153', '----'),
(67, 'Marina Guedes', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av. Luciano Carneiro, 2235 – Vila União                 ', '(085)3452-5376', '----', 'MARINABUA@GMAIL.COM', '(085)8965-4460', '----'),
(68, 'Fabiana', 'COORDENADORIA', 'Coord.especial Participação Popular ', 'Av. Luciano Carneiro, 2235 –Vila União', '-', '----', '----', '----', '----'),
(69, 'Jade Afonso Romero ', 'COORDENADORIA', 'Coordenadora da Coordenadoria Especial de Participação Popular', 'Av. Luciano Carneiro, 2235 –Vila União', '(085)3105-1569', '----', 'jaderomero@gmail.com/jade.romero@fortaleza.ce.gov.br/sabigsb@gmail.com', '----', '----'),
(70, 'José Élcio Batista ', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '(085)3452-2118', '----', 'elcioelcioelcio@gmail.com', '----', 'Coordenador'),
(71, 'Juliana Formiga ', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '----', '----', 'JULIANAFORMIGA@GMAIL.COM', '(085)8840-7777', '----'),
(72, 'Verônia', 'Coordenadoria', 'Coord.de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '----', '----', '----', '----', '----'),
(73, 'Camila Silveira', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '(85)3452-5373', '5371', 'camilasilveirace@gmail.com', '-', '-'),
(74, 'Larissa Maria Fernandes Gaspar Da Costa ', 'COORDENADORIA', 'Coordenadora de Politica Para as Mulheres', 'Rua  Pedro l, s/ n – Cidade da Criança - Centro ', '(085)3105-1398', '----', 'coordenadoriadamulherfor@yahoo.com.br', '----', '----'),
(75, 'Francisco Cristiano Ferrer', 'COORDENADORIA', 'Coordenadoria Municipal de Proteção e Defesa Civil', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-7132', '/6229', 'fc_ferrer@hotmail.com', '----', 'Coordenador Especial '),
(76, 'Julio Cals de Alencar', 'COORDENADORIA', 'Coordenadoria para Promoção da Cidadania e Direitos Humanos', 'Rua Pedro I,461-Cidade da Criança - Centro', '(085)3452-2364', '----', 'julio.cals@fortaleza.ce.gov.br', '----', 'Coordenador'),
(77, 'Andréa Rossati', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas para Diversidade Sexual', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3452-2349', '2345', 'andrearossati40@hotmail.com', '----', 'Coordenadora'),
(78, 'Larissa Maria Fernades Gaspar da Costa ', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas para as Mulheres', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1398', '----', 'coordenadoriamulherfor@yahoo.com.br', '----', 'Coordenadora '),
(79, 'João Batista Uchuôa ', 'COORDENADORIA', 'Coordenadoria de Publicidade e Marketing', 'Rua São José ,01- Centro', '(085)3105-1448', '3452-7299', 'joao.uchuoa@fortaleza.ce.gov.br', '----', 'Coordenador'),
(80, 'Norma Zélia Moreira Pinheiro de Andrade', 'COORDENADORIA', 'Coordenadoria de Ceremonial ', 'Rua São José ,01- centro Paço Municipal', '(085)3105-1364', '1365/1366', 'nzandrade@gmail.com', '----', 'Coordenadoria de Cerimonial'),
(81, 'Lúcio  Bruno', 'Coordenadoria', 'Coord.especial Articulação Política ', 'Rua São José ,01-Centro', '(085)3105-1371', '----', 'lucio.bruno@fortaleza.ce.gov.br', '----', '----'),
(82, 'Lúcio Alburquerque Bruno Figueiredo ', 'COORDENADORIA', 'Coordenadoria Especial de Articulação Política', 'Rua São José ,01-Centro', '(085)3105-1371', '1013', 'lucio-bruno@ig.com.br', '----', 'Coordenador '),
(83, 'ED. Lúcio Oliveira ', 'COORDENADORIA', 'Coordenadoria de Eventos', 'Rua São José 01-Centro', '(085)3105-1447', '----', 'ed.lucio@fortaleza', '----', 'Coordenador '),
(84, 'Moacir Maia Dos Santos ', 'COORDENADORIA', 'Coordenadoria de Comunicação Social ', 'Rua São José 01-Centro', '(085)3105-1442', '1446', 'jornalistamoacirmaia@gmail.com', '----', 'Coordenador '),
(85, 'Hermann Hesse Feitosa Alexandrino', 'COORDENADORIA', 'Coordenadoria de Comunicação Institucional ', 'Rua São José.01 -Centro', '(085)3452-1655', '----', 'hermann.hesse@fortaleza.ce.gov.br ', '----', 'Coordenador '),
(86, 'José Elcio Batista ', 'COORDENADORIA ', 'Coordenadora Especial De Politicas Públicas De Juventude ', 'Av. Luciano Carneiro, 2235 – Vila União                 ', '(085) 3452-4657', '----', 'elcioelcioelcio@gmail.com', '085-8970-3031', '----'),
(87, 'Thauser ', 'COPEDEF ', 'Coordenadoria de Pessoas com Deficiência', '-----', '----', '----', '----', '(85)8808-1158', '----'),
(88, 'Francisco Thauzer Coelho Fonteles', 'COPEDEF ', 'Coordenadoria Especial da Pessoa com Deficiência ', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3252-3436', '----', 'prof.thauzer@gmail.com', '----', 'Coordenador'),
(89, 'Cristiano Lima ', 'COPPIR', 'Coordenadoria Especial de Políticas Públicas de Promoção de Igualdade Racial', 'Rua Pedro l s/n, Cidade da Criança', '(085)3452-7747', '-', ' josecoopir@fortaleza.ce.gov.br / coopir.scdh@fortaleza.ce.gov.br', '----', 'Coordenador Especial'),
(90, 'Ricardo (Ponto Web)', 'COTEC', 'Celula de tecnologia', 'Rua Julio Siqueira, 1101- Joaquim Távora', '----', '----', '----', '(85) 8794-1119', '----'),
(91, 'Rodolfo Sikora', 'COTEC', 'Celula de tecnologia', 'Rua Julio Siqueira, 1101- Joaquim Távora', '(85) 3433-3635', '-', 'rodolfo.sikora@fortaleza.ce.gov.br', '(085)8888-0103', '----'),
(92, 'Juliana Mara de Freitas Sena Mota', 'CPDROGAS', 'Coordenadoria de Políticas sobre drogas', 'Av.Luciano Carneiro ,99- Villa União ', '(085)3452-7296', '7283', 'mjulianasena@gmail.com', '----', 'Coordenadora'),
(93, 'Maria Lourdes dos Santos', 'CPDROGAS', 'Coordenadoria de Políticas sobre drogas', 'Av.Luciano Carneiro ,99- Villa União ', '(85) 3452-7296', '----', 'mlourdes7@yahoo.com.br', '----', 'Coordenadora do Núcleo de Pesquisa'),
(94, 'Raul ', 'CPDROGAS', 'Coordenadoria de Políticas sobre drogas', 'Av.Luciano Carneiro ,99- Villa União ', '----', '----', '----', '----', '----'),
(95, 'Cristiane', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3105-1150', '----', 'crislicitacaofortaleza@gmail.com', ' (85)8890 9945', '----'),
(96, 'Geovania  Machado ', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3252-1630', '3452-3477', 'geovania4@hotmail.com ', '----', '-'),
(97, 'Geovania Sabino Machado ', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3452-3477', '----', 'geovania4@hotmail.com', '----', 'Presidente'),
(98, 'Giovania', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3452 3477', '----', '----', '----', '----'),
(99, 'Vera Lucia', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3452-3480', '----', 'vera.lucia@fortaleza.ce.gov.br', '----', '----'),
(100, 'Joias', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(85)3452-3473', '-', '---', '(85) 8657-4243', '-'),
(101, 'Vanusa', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(85) 3452-3482', '-', '-', '-', '-'),
(102, 'Jade Afonso Romero ', 'CPP', 'Coordenadoria Especial de Participação Popular', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-6780', '----', 'jaderomero@gmail.com', '----', 'Coordenadora'),
(103, 'Rafaelle Reis ', 'CPP', 'Coordenadoria Especial de Participação Popular', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-6792', '----', 'RAFAELLEREIS@YAHOO.COM.BR', '(085)8818-5791', '----'),
(104, 'Carlos Alberto Alves de Sousa', 'CTC', 'Companhia de Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '(085)3433-9670', '----', 'c.alberto.alves@hotmail.com', '----', 'Presidente'),
(105, 'Carlos Alberto Alves de Sousa', 'CTC', ' Companhia De Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '(085)3433-9670', '----', 'c.alberto.alves@hotmail.com', '----', 'Presidente'),
(106, 'Carlos Alberto Alves De Sousa ', 'CTC', 'Companhia de Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '(085)3433-9670', '----', 'c.alberto.alves@hotmail.com/anicecampos@bol.com.br', '----', '----'),
(107, 'Nice ', 'CTC', 'Companhia de Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '----', '----', '----', '----', '----'),
(108, 'Sergio Henrique  Lima Miranda ', 'CTIS', 'Centro deTecnologia', '-----', '(085) 3047-5449', '----', 'sergio.miranda@ctis.com.br', '----', 'Representante Comercial '),
(109, 'Rafael Fonseca', 'CTIS IT Services', 'CTIS Tecnologia S.A', 'SCN Q. 04, BL. B, sala 204, 2º andar, Centro Empresarial Varig Brasilia-DF, Cep : 70714-900', '(61)3426-9406', '----', 'rafaelc@ctis.com.br', '(61)9276-8364', 'Diretor de Partner Solutions'),
(110, 'Fernanda', 'CUCA', '--------', '-------', '(85)3452-4658', '-', '------', '(85)8868-7070', 'Acessora Juridica.'),
(111, 'Filizolina De Souza ', 'DAF', 'Departamento Administrativo Financeiro', 'Rua São José ,01- centro', '(085)3105-1456', '----', 'filizolina.sousa@fortaleza.ce.gov.br', '----', '----'),
(112, 'Paulo Afonso Cavalcante Júnior ', 'DAF', 'Departamento Administrativo Financeiro', 'Rua São José ,01- centro', '(085)3105-1456', '1472', 'paulo.afonso@fortaleza.ce.gov.br', '----', 'Diretor   '),
(113, 'Valéria Borges', 'DAF', 'Departamento Administrativo Financeiro', 'Rua São José ,01- centro', '(085)3105-1472', '----', 'valeria.borges@fortaleza.ce.gov.br', '----', '----'),
(114, 'Cristiano Ferrer', 'DEFESA CIVIL', 'Coordenadoria Municipal de Proteção e Defesa Civil', 'Rua  Delmiro de Farias, 1900 – Rodolfo Teófilo', '(085)3281-7132', '6229', 'cristiano.ferrer@fortaleza.ce.gov.br', ' (085)8713 4300', 'Diretor'),
(115, 'EDIRAN', 'DIEESE', 'Departamento Intersindical de Estátisca e Estudos Socioeconômicos', '-----', '(085)32533962', '----', '----', '----', '----'),
(116, 'Sâmia Cristina de C. Fernandes', 'DIPRE', 'Divisão de Proteção ao Estudante', '-----', '----', '----', '----', '----', 'Chefe da divisão de Tecnologia da Informação'),
(117, 'Otavio Gondim', 'DNOCS', 'Departamento Nacional de Obras Contras a Secas', 'Av.Duque de Caxias,1700', '(085)3391-5103', '----', 'otavio.gondim@dnocs.gov.br', '----', '----'),
(118, 'José Ronaldo Rocha Nogueira ', 'EMLURB', 'Empresa Municipal de Limpeza Urbana', 'Rua Marechal Deodoro ,1501- Benfica', '(085)3131-7619', '7604', 'ronaldonogueirapmf@gmail.com', '----', 'Presidente '),
(119, 'Kelma/Vera ', 'EMLURB', 'Empresa Municipal de Limpeza Urbana', 'Rua Marechal Deodoro ,1501- Benfica', '----', '----', '----', '----', '----'),
(120, 'Osmar Jose do Nascimento', 'Epidemiologia/Dengue', '-', '-', '-', '-', '-', '-', '-'),
(121, 'Antonio Ferreira', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '(085)3452 9333', '----', '----', '----', 'Diretor  Técnico'),
(122, 'Antônio Ferreira', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '-----', '----', '----', '----', 'Diretor técnico'),
(123, 'Caroline Pinheiro ', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '(085)3452-9299', '3452-9322/9252', 'carolpinheiro84@hotmail.com', '----', '----'),
(124, 'Rogerio de Alencar Araripe Pinheiro', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '(085)3452-9322', '9252/9205', 'rogerio@etufor.ce.gov.br', '----', 'Presidente'),
(125, 'Adriana Furtado ', 'FMDS', '-------', '-', '(085)3433-3742', '3433-3748', '-', '-', '-'),
(126, 'Narcélio Giordanny Conrado Napolião', 'FUNCET', 'Fundação de Cultura ,Esporte e Turismo ', 'Rua meton Alencar ,1040- Casa 4- Centro', '(085)3105-1360', '----', 'giordanny.napolião@gmail.com', '----', 'Presidente'),
(127, 'Noemi ', 'FUNCET', 'Fundação de Cultura ,Esporte e Turismo ', 'Rua meton Alencar ,1040- Casa 4- Centro', '----', '----', 'Noemi.fonseca@fortaleza.ce.gov.br', '----', '----'),
(128, 'Francisco Arquimedes Rodrigues Pinheiro', 'FUNCI', 'Fundação da Criança e Familia Cidadã/Coordenadoria da Criança e do Adolescente', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1316', '----', 'arquimedespinheiro@hotmail.com', '----', 'Coordenador '),
(129, 'Luciene Araújo ', 'FUNCI', 'Fundação da Criança e Familia Cidadã/Coordenadoria da Criança e do Adolescente', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1316', '----', '----', '----', '----'),
(130, 'Tânia Gurgel', 'FUNCI', 'Fundação da Criança e Familia Cidadã/Coordenadoria da Criança e do Adolescente', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1316', '----', 'tania.gurgel@fortaleza.ce.gov.br', '----', '----'),
(131, 'Carolina Cunha  Bezerra ', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1651', '2116/2112', 'carol.bezerra@fortaleza.ce.gov.br', '----', 'Primeira Dama do Municipio'),
(132, 'Célia/andreia/livia/débora', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1651', '3452-1656', 'celia.medeiros@fortaleza.ce.gov.br', '----', '----'),
(133, 'Cristiana Ferreira', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1651', '----', 'silva_ferreira_cristiana@yahoo.com.br', '(085)8543-5484', '----'),
(134, 'Maria Letícia Mota Moreira', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-7276', '----', 'leticiamm4@gmail.com', '(85) 8768-8997', '----'),
(135, 'Gilmar', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', '-----', '----', '----', 'gilmar.soares@fortaleza.ce.gov.br', '(85) 8890-9944', 'Prefeito do Gabinete do Prefeito'),
(136, 'Edna Brasil/nágela', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1373', '(085)3105-1374', 'edna.brasil@fortaleza.ce.gov.b', '----', '----'),
(137, 'Eliane Leão', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1369', '(085)3105-1369', 'eliane.leao@fortaleza.ce.gov.br', '----', 'Assessora Do Chefe De Gabinete'),
(138, 'Glaucia Diogo ', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1369', '----', 'glaucia.diogo@fortaleza.ce.gov.br', '----', 'Assessora Do Chefe De Gabinete '),
(139, 'Anelize / Elizabete / Ueila / Uiara', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(85) 3105-1165', '-', '-', '-', '-'),
(140, 'Evanildo Nascimento (Pipoca)', 'GABINETE DO PREFEITO', 'Gabiente do Prefeito', 'Rua São josé ,01-Centro', '----', '-', 'evanildorpipoca@hotmail.com', '(85)8710-7196/(85)8863-4308/ (85)9764-9333', 'Supervisor Industrial'),
(141, 'Alfredo Lopes', 'GABINETE DO PREFEITO', 'Gabiente do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1169', '----', '----', '-', 'Assessor Técnico'),
(142, 'Danúsio Magalhães ', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1460', '----', '----', '----', '----'),
(143, 'Danúsio/sr Raimundo/sr.matos/cesar/francisco', 'GABINETE DO PREFEITO', 'Gabiente do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1460', '----', '----', '----', '----'),
(144, 'Diana Carvalho ', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1002', '----', 'diana.carvalho@fortaleza.ce.gov.br', '----', '----'),
(145, 'Elizabete/liduina /ana Lúcia Nádja/conceição/ricardo', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1366', '1365', '----', '----', '----'),
(146, 'Francisco José Queiroz Maia Filho', 'GABINETE DO PREFEITO', 'Chefia de Gabinete do Prefeito ', 'Rua São josé ,01-Centro', '(085)3105-1378', '----', 'queiroz.maia@fortaleza.ce.gov.br', '----', 'Secretário Chefe de Gabinete do Prefeito'),
(147, 'Francisco José Queiroz Maia Filho', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1378', '1167', 'QUEIROZ.MAIA@FORTALEZA.CE.GOV.BR/QUEIROZMAIA@HOTMAIL.COM.COM.BR', '----', '----'),
(148, 'Ivanilda/neuza/fátima/fred/colombo ', 'GABINETE DO PREFEITO', 'Redação - Gabinete do prefeito', 'Rua São josé ,01-Centro', '(085)3452-6798', '----', '----', '----', '----'),
(149, 'Manuela /Ariane/Carla', 'Gabinete do prefeito', 'GABINETE DO PREFEITO', 'Rua São José ,01-Centro', '----', '----', '----', '----', 'Secretarias Do Prefeito '),
(150, 'Roberto Claúdio Rodrigues Bezerra', 'GABINETE DO PREFEITO', 'Gabinete  do Prefeito ', 'Rua São josé ,01-Centro', '(085)3105-1099', '----', 'robertoclaudio@gabpref.fortaleza.ce.gov.br', '----', 'Prefeito Municipal'),
(151, 'Capitão Bastos/Major Sousa', 'Gabinete do Prefeito ', 'Seguranças Do Prefeito', 'Rua São José ,01- centro', '(085)3105-1461', '----', 'laudelio.bastos@fortaleza.ce.gov.br', '----', '----'),
(152, 'Gerardo ', 'Gabinete do Prefeito ', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '----', '----', 'gerardo.junior@fortaleza.ce.gov.br', '(85) 8888-2601', 'Gerente de TI'),
(153, 'Mazim', 'Gabinete Prefeito ', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1022', '----', '----', '----', 'Assessor Do Prefeito '),
(154, 'Holanda', 'GB', 'Gabinete do Prefeito', 'Rua São José,01 - Centro ', '(85) 3105-1165', '-', '-', '(85) 8788-1927', 'Chefe de Segurança'),
(155, 'Ana Leticia ', 'GMF', 'Guarda Municipal de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085) 3281-1672', '3281-9937', '----', '----', '----'),
(156, 'Antonio Azevedo Vieira Filho', 'GMF', 'Guarda Municipal  de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-8804', '8151', 'gabinete.sesec@gmail.com', '----', 'Diretor geral da Guarda Municipal e Sec. Executivo'),
(157, 'Inspetor Adson', 'GMF', 'Guarda Municipal  de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '-', '----', '-', '(85) 8867-9277', 'Coordenador de Tecnologia'),
(158, 'Inspetora Arilza', 'GMF', 'Guarda Municipal  de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '-', '-', 'subinspetorarilza@yahoo.com.br', '(85) 8879-7623', '-'),
(159, 'Cibele/Juciana', 'HABITAFOR', 'fundação De Desenvolvimento Habitacional De Fortaleza ', 'Rua Nogueira Acioly,1400,1ºAndar - Centro', '(085)3488-3377', '(085) 3488-3376', 'juciana.ribeiro@fortaleza.ce.gov.br', '----', '----'),
(160, 'Francisca Eliana Gomes Dos Santos ', 'HABITAFOR', 'fundação De Desenvolvimento Habitacional De Fortaleza ', 'Rua Nogueira Acioly,1400,1ºAndar - Centro', '(085)3488-3377', '----', 'presidenciahabitafor@fortaleza.ce.gov.br/belecoelho@gmail.com', '----', '----'),
(161, 'Anaxágoras Girão ', 'IFCE', 'Instituto Federal de educação ,ciênciae e tecnologia do ceará', 'Avenida Treze de Maio, 2081 - Benfica, Fortaleza - CE', '(085) 3105 1355', '----', 'anaxa2006@gmail.com', '(085)8105-8070', '----'),
(162, 'Rodrigo Carvalho Sousa Costa', 'IFCE', 'Instituto Federal do Ceará', 'Avenida Treze de Maio, 2081 - Benfica, Fortaleza - CE', '(085)3455-9006', '----', 'rodccosta@gmail.com', '(085)81022854', '----'),
(163, 'Romulo Ferrer Lima Carneiroa', 'IFCE', 'Instituto Federal do Ceará', 'Avenida Treze de Maio, 2081 - Benfica, Fortaleza - CE', '(085) 3105 1355', '----', 'romulo.ferrer@gmail.com', '(085) 99703890 / 81627874', '----'),
(164, 'Anaxágoras', 'IFCE', 'Instituto Federal do Ceará', '-', '-', '----', 'anaxa2006@gmail.com', '(085)81508070', '----'),
(165, 'Ângela Deyse Jucá Oliveira', 'IJF', 'Instituto Dr.José Frota ', 'Rua Barão do Rio  Branco ,1816 - Centro', '(85) 3255-5180 / 3255-5081 ', '----', 'adeysejs@hotmail.com.br', '(85) 9996-4447', 'Gerente de TI'),
(166, 'Francisco Walter Frota de Paiva', 'IJF', 'Instituto Dr.José Frota ', 'Rua Barão do Rio  Branco ,1816 - Centro', '(085)3255-5205', '5206/3255', 'walterfrota@hotmail.com', '----', 'Superintendente'),
(167, 'Sergio Costa ', 'Imagem Segurança', '-----', '-----', '(085)32531546', '----', '----', '(85)8728 0863', '----'),
(168, 'André Ramos Silva', 'IMPARH', 'Instituto  Muncipal de Pesquisas e Administração e recursos humanos', 'Av. João Pessoa- 5609  Bairro Damas', '(085)3243-2960', '2961', 'ANDRE.SILVA8@GMAIL.COM.BR/VIRGINIAVJMARCIO@GMAIL.COM', '----', '----'),
(169, 'Virginia ', 'IMPARH', 'Instituto  Muncipal de Pesquisas e Administração e recursos humanos', 'Av. João Pessoa- 5609  Bairro Damas', '(085)3467-6704', '----', 'virginia.oliveira@fortaleza.ce.gov.br', '----', '----'),
(170, 'Robson Pessoa', 'Informática', '-----', '-----', '(61) 3426-9402', '----', 'robson.pessoa@ctis.com.br', '(61) 8406-8667', '----'),
(171, 'Romero Antunes', 'Informática', 'Solution Architect', 'SBS Quadra 02 - Bloco E - Sala 206, Ed. Prime Business Convenience, 70070-120 Brasilia, DF.', '(61)3041-9599', '----', 'rantunes@informatica.com', '(61)9929-9701', '----'),
(172, 'Jaime Araujo', 'Intelletto', 'Intelletto Soluções', 'SHN Quadra 2 Bloco F Sala 1004 Brasília, DF 70702-906 Brasil', '----', '----', 'jaime@intelletto.com.br', '(61)99435472 / (61)9233.5472 / 82036161 ', '----'),
(173, 'Berger', 'IPCE', '------', '-', '(85)3101-3512', '-', '-', '-', '-'),
(174, 'Roberta', 'IPCE', '--------', '-', '(85)3101-3521', '-', '-', '-', 'Secretária do Ataliba'),
(175, 'Eugenio Paceli', 'IPCE', '-------', '-', '(85)3101-3505', '-', '-', '-', '-'),
(176, 'Adriano Sarquis ', 'IPECE', 'Instituto de Pesquisa e Estratégia Econômica do Ceará', 'Cambeba, Fortaleza - CE', '(085)3105 3496', '-', '-', '-', 'Diretor'),
(177, 'Cleiber', 'IPECE', '-------', '-', '3101-3523', '3101 3518', 'cleyber.medeiros@ipece.ce.gov.br', '-', 'Analista Estatistico '),
(178, 'Arthur Kubernat', 'IPEM', 'Instituto de Pesquisa e Medidas', '-----', '(85)  3131-4003', '----', 'arthur.ipem@fortaleza.ce.gov.br / cti.ipem@fortaleza.ce.gov.br', '(85) 9624-4608', 'Gestor de TI'),
(179, 'Fernando Rossas Freire ', 'IPEM', 'Instituto de Pesos e Medidas', 'Av.Luciano Carneiro ,1320-Vila União', '(085)3256-7044', '2390', 'superintendencia.ipm@fortaleza.ce.gov.br', '----', 'Superintendente'),
(180, 'Marcia Sampaio ', 'IPEM', 'Instituto de Pesos e Medidas', 'Av.Luciano Carneiro ,1320-Vila União', '(085)3256-7044', '2390', ' marciacidrack@hotmail.com', '----', '----'),
(181, 'Professor Inácio Bessa', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José ,01- centro', '(85) 3253-2221', '----', 'bessainacio@gmail.com', '(85)9983-2400 / 8814-1229', '----'),
(182, 'Rodrigo Petry', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '32320645', 'rodrigors.petry@gmail.com', '(085)96278697', '----'),
(183, 'Alexandrino Diogenes', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '----', '----', 'alexandrino.diogenes@fortaleza.ce.gov.br', '----', '----'),
(184, 'Joacy Da Silva Leite', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'joacyleite@gmail.com', '(085)9998 9438', '----'),
(185, 'Jorge Washigton Laffitte', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'laffittejorge@gmail.com', '(085) 96353556', '----'),
(186, 'Luiz Santos', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'luiz.santos@fortaleza.ce.gov.br/siul.sant@gmail.com', '(085) 9621 7016', 'Gerente da Sala Situacional'),
(187, 'Marcos Mendes ', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '3105 1355', 'marcosmendes938@gmail.com', '(085) 88151976', '----'),
(188, 'Mariana', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '----', '----', '----', '(085)88113338', 'Assistente'),
(189, 'Sergio Horacio Lopes B De Menezes', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'sergio.menezes@fortaleza.com', '(085) 89704354', '----'),
(190, 'Vaninha Rocha ', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '----', '----', 'vaninha.rocha@fortaleza.ce.gov.br', '----', '----'),
(191, 'Volia Rocha', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1314', '----', 'VOLIA.ROCHA@FORTALEZA.CE.GOV.BR', '(085)9938-8369', '----'),
(192, 'Conceição Cidrakc', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1354', '----', 'conceicao.cidrack@fortaleza.ce.gov.br', '----', '----'),
(193, 'Eudoro Walter de Santana ', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1354', '----', 'eudorosantana@gmail.com', '----', 'Presidente '),
(194, 'Fabio Weydson', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1354', '----', ' fabioweydson@gmail.com', '(85) 9799-9991 / 9766-3119', '----'),
(195, 'Felipe Teles', 'IPLANFOR', 'Diretoria De Monitoramento E Avaliação', 'Rua São josé ,01-Centro- Paço Municipal', ' (085)3105-1355', '----', 'felipejteles@gmail.com', '(085) 9136-9382 / 8970-4618', '----'),
(196, 'Luiza Perdigão', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(85) 3105-1357', '----', 'luizaperdigao@gmail.com / luiza.perdigao@fortaleza.ce.gov.br', '(85) 8970-3818', '----'),
(197, 'Thais Abreu Magalhães', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'thaisabreumagalhaes@gmail.com', '(85) 9748-7345', '----'),
(198, 'Marcio Seabra', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José,01 - Centro ', '(85) 3105-1355', '----', 'marcio.seabra@fortaleza.ce.gov.br', '(85) 9927-5721', 'Programador'),
(199, 'Raquel Honório', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José,01 - Centro ', '(85)3105-1355', '----', 'raquel.honorio@fortaleza.ce.gov.br / raquelshonorio@gmail.com', '(85) 87417219 / (85) 9901-9793', '----'),
(200, 'Tamile Solon', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José,01 - Centro ', '(085)3105-1354', '----', 'tamile.solon@fortaleza.ce.gov.br', '----', 'Assessora '),
(201, 'Rodrigo Pordeus', 'IPLANFOR', '-------', '-', '(085)3105-1354', '-', ' rodrigo.pordeus@fortaleza.ce.gov.br', '(85) 88057378 / (85) 89704619', '-'),
(202, 'Lia Parente', 'IPLANFOR', '--------', '-', '-', '-', 'lia.parente@fortaleza.ce.gov.br', '(85)8897-0581', '-'),
(203, 'IPLANFOR - Anexo', 'IPLANFOR - Anexo', 'Instituto de Planejamento de Fortaleza - Anexo', ' Rua 25 de Março, nº 268 – Centro', '(85) 3105-1285', '----', '----', '----', '----'),
(204, 'Aline', 'IPM', 'Instituto de Previdência do Município ', 'Rua Major Facundo ,1361- Centro', '(085)3105-1393', '3252-1797/1776', 'aline@ipmfor.ce.gov.br', '----', '----'),
(205, 'Fernando Rossas Freire ', 'IPM', 'Instituto de Previdência do Município ', 'Rua Major Facundo ,1361- Centro', '(085)3256-7044', '2390', 'superintendencia.ipem@fortaleza.ce.gov.br', '----', '----'),
(206, 'José Barbosa Porto ', 'IPM', 'Instituto de Previdência do Município ', 'Rua Major Facundo ,1361- Centro', '(085)3252-1797', '1776', 'dr.porto@ipmfor.ce.gov.br', '----', 'Superintendente'),
(207, 'André', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '-----', '-----', '-----', '(85)8619-0958 (85)9939-6881', 'Suport Tecnico'),
(208, 'Camila ', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '-----', '----', '----', '(85) 8970-7740 / 8970-7780', '----'),
(209, 'Cristiane', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '----', '----', 'cristianneamoris@gmail.com', '(85) 8970-4074 / 8680-5901', '----'),
(210, 'Help Desk (ISGH)', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '(85) 3195-2727', '-', '----', '----', '-'),
(211, 'Humberto', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '----', '----', '----', '(85) 8970-1892', '----'),
(212, 'Sergio Oliveira', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '----', '----', 'sergiooliveira@isgh.org.br', '(85) 8628-6016', '----'),
(213, 'Edgy Paiva', 'IVIA', '-----', 'Av. Washington 909, loja 97 - Shopping Salinas', '(85) 3305-4747 / 3305-4749', '----', 'edgy.paiva@ivia.com.br', '(85) 9982-3893', '----'),
(214, 'Camila ', 'JURIDICO', '-----', '-----', '(085)3105 1247', '----', '----', '----', '----'),
(215, 'Paulo Carvalho', 'KONPAX', 'KONPAX do Brasil', 'Rua Tibúrcio Cavalcante, 1573 – Aldeota ', '(85)4009-5293', '-', 'paulo@konpax.com', '(85) 8122-1100', 'Diretor Executivo'),
(216, 'Cristiane Eleutério Carvalho Deusdara', 'MAPFOR-SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3749', '----', 'cristiane.deusdara@fortaleza.ce.gov.br ', '(85)89703492', '----'),
(217, 'Augusto Martelo', 'N5Tecnologia', 'N5Tecnologia', '-', '-', '-', 'augusto@n5tecnologia.com.br', '(85) 8675-0182', 'Assistente Técnico'),
(218, 'Paulo Elan', 'Núcleo Imagem', 'Núcleo Imagem', 'Rua Barão de Aratanha, 1300 - Fátima', '(085)3455-2702', '2700', 'elan@nucleoinfo.com.br', '(085)88020175', 'Gerente de Negócios'),
(219, 'Pedro Monteiro', 'Núcleo Imagem', 'Núcleo Imagem', '-', '(85)3455-2716', '-', 'monteiro@nucleoinfo.com.br', '(85) 8804-0876', 'Supervisor de Pré venda'),
(220, 'Ribeiro', 'Núcleo Informatica', '------', '-', '-', '-', '-', '(85)8906-5957/(85)99504273', '-'),
(221, 'Liliane Da Silveira Araújo ', 'OGM', 'Ouvidoria Geral  do Municipio', 'Rua Meton de Alencar ,1791- Centro', '(085)3105-1501', '----', 'lilianemptceara@hotmail.com', '----', 'Ouvidoria Geral'),
(222, 'Gonsalves', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '----', '----', '----', '(85) 8664-9574 / 9993-0222', '----'),
(223, 'Pedro Alcantra', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '(85) 3226-9818', '----', 'pedro@omegagrupo.com.br', '(85) 8820-9278 / (19) 99766-2513', 'Coordenador'),
(224, 'Valdenor ', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '(85) 3226-9818', '----', 'valdenor@omegagrupo.com.br', '(19) 96192051 / (85) 9669 7302', '----'),
(225, 'Valmir Ferreira', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '(19) 3246-0100', '----', 'valmir@omegagrupo.com.br', '(19) 99604-8446', '----'),
(226, 'Claudia Regina', 'OMEGA ', '-------', '-', '(85)3246-0100', '----', 'claudia.rh@omegagrup.com.br', '-', '-'),
(227, 'Eliete ', 'PGM', 'Procuradoria Geral do Municipio', 'Av.Santos Dumont,5335,11ºAndar -Aldeota', '(085)3234-5422', '-', 'eliete.castro@fortaleza.ce.gov.br', '----', '----'),
(228, 'João Paulo', 'PGM', 'Procuradoria Geral do Municipio', 'Av.Santos Dumont,5335,11ºAndar -Aldeota', '(085)3265-2238', '----', '----', '----', '----'),
(229, 'José Leite Jucá Filho', 'PGM', 'Procuradoria Geral do Municipio', 'Av.Santos Dumont,5335,11ºAndar -Aldeota', '(085)3265-5114', '3265-5977', 'joseleite@gmail.com', '----', 'Procurador Geral '),
(230, 'José Leite Jucá Filho', 'PGM', 'Procuradoria Geral do Municipio', '-', '(085)3265-5114', '----', 'JOSELEITE@GMAIL.COM', '----', '-'),
(231, 'Claudia Freitas', 'PLANEJAMENTO SMS', '--------', '-', '(85)3452-6999', '-', 'cacaulima2@hotmail.com/acessoriaplanejamento@sms.fortaleza.ce.gov.br', '(85)8657-2291', 'Acessora de Planejamento'),
(232, 'Andre Ramos', 'PNAFM', 'PROGRAMA NACIONAL DE APOIO À MODERNIZAÇÃO ADMINISTRATIVA E FISCAL', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1237', '----', 'andre.ramos@sefin.fortaleza.ce.gov.br', '(085) 8843 2409', '----'),
(233, 'Marta Goes', 'PNAFM', 'PROGRAMA NACIONAL DE APOIO À MODERNIZAÇÃO ADMINISTRATIVA E FISCAL', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1237', '----', 'marta.goes@sefin.fortaleza.ce.gov.br', '-', '-'),
(234, 'Verônica', 'POP FOR', 'Pré-Vestibular Popular de Fortaleza', '-----', '(085)3452-7281', '----', '----', '----', '----'),
(235, 'Sônia Maria Pedrosa Cavalcante', 'PROCON', 'Coordenadoria Especialde Defesa do Consumidor - PROCON', '-----', '(85) 3452-2197 ', '----', 'spcavalcante@gmail.com', '(85) 9989-5091', 'Contadora'),
(236, 'George Lopes Valentim ', 'PROCON', 'Coordenadoria da Defesa do Consumidor ', 'Rua major Facundo ,869- centro', '(085)3105-1136', '1296', 'georgelopesvalentim@hotmail.com', '----', 'Coordenador geral'),
(237, 'Rejane Oliveira ', 'PROCON', 'Coordenadoria da Defesa do Consumidor ', 'Rua major Facundo ,869- centro', '(085)3105-1188', '3105-1296/1136', 'regioliveira.80@gmail.com', '----', '----'),
(238, 'Sara', 'Recepção Prefeito ', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3452-1651', '----', '----', '----', '----'),
(239, 'Marcos Frota', 'RNP-UFC', 'GIGAFOR', '----', '(85)3287-4314', '----', '----', '----', '----'),
(240, 'IPLANFOR - Sala da Diretoria', 'Sala da Diretoria', 'Instituto de Planejamento de Fortaleza - Anexo', ' Rua 25 de Março, nº 268 – Centro', '(85)3488-9248/ (85)3105-1355', '----', '----', '----', '-'),
(241, 'Karlo Meireles Kardozo', 'SCDH', 'Secretaria Municipal de Cidadania  e Direitos Humanos ', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3452-2320', '----', 'karlo.kardozo@fortaleza.ce.gov.br', '----', 'Secretário'),
(242, 'Jaciane', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '(85) 3272-4861', '----', '----', '(85) 8519-1386/(85)8970-4079', 'Secretaria Luiz Saboia'),
(243, 'João de Aguiar Pupo', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '(085)3261-6268', '----', 'joao_pupo@hotmail.com', '----', 'Secretário'),
(244, 'Lena - Secretaria', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '(085)3452-7275', '3261-6268', 'jlenassa@hotmail.com  ', '----', '----'),
(245, 'Luis Alberto Sabóia', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '085) 3261-6268 ', '----', 'luiz.saboia@fortaleza.ce.gov.br', '(085)89704079', '----'),
(246, 'Rafael Sousa', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '----', '----', 'rafael.sousa@fortaleza.ce.gov.br', '(085)88977182', '----'),
(247, 'Francisco Figueredo de Paula Pessoa Neto', 'SCSP', 'Secretaria de Conservação e Serviços Públicos', 'Rua São José,01 - Centro ', '----', '----', 'fcofigueredo@hotmail.com', '(85)9996-1805\n(85)8708-3004', 'Assessor Jurídico'),
(248, 'Sergio A. de Morais', 'SCSP', 'Secretaria de Conservação e Serviços Públicos', 'Rua São José,01 - Centro ', '(85)3452-7274', '----', 'sergio.moraes@fortaleza.ce.gov.br', '(85)8898-3494', 'Gerente Administrativo'),
(249, 'Ítalo Alves de Andrade', 'SCSP', 'Secretaria de Conservação e Serviços Públicos', 'Rua São José,01 - Centro ', '----', '----', 'italo.andrade@fortaleza.ce.gov.br', '(85)8970-2062\n(85)9992-7295', 'Coordenador Administrativo Financeiro'),
(250, 'Jó ', 'SDE', 'Secretaria Municipal de desenvolvimento Econômico ', 'Av.Aguanambi ,1770-Fátima', '(085 )3105-1519', '----', 'joyce.oliveira@fortaleza.ce.gov.br', '----', '----'),
(251, 'Marcelo Davi Santos', 'SDE', 'Secretaria Municipal de Desenvolvimento Econômico', 'Av.Aguanambi ,1770-Fátima', '(85) 3452-6239 ', '----', 'davi.santos@fortaleza.ce.gov.br', '(85) 8501-6618', 'Assessor de Desenvolvimento Econômico e Projeto'),
(252, 'Robinson Passos de Castro e Silva', 'SDE', 'Secretaria Municipal de desenvolvimento Econômico ', 'Av.Aguanambi ,1770-Fátima', '(085)3105-1573', '1574', 'robinson.castro@fortaleza.ce.gov.br', '----', 'Secretário '),
(253, 'Karlo Meireles Kardozo', 'SDH', 'Secretaria De Direitos Humanos de Fortaleza ', 'Pedro I,s/n centro Fortaleza ce', '(085) 3452-2320 ', '----', 'karlo.kardozo@fortaleza.ce.gov.br  ', '085-8970-2222', '----'),
(254, 'Edna Martins', 'SECEL', 'Secretaria Municipal de Esporte e Lazer de Fortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085)32545848', '----', 'edna.cleyane@fortaleza.ce.gov.br', '----', 'SECRETARIO/MARCIO LOPES'),
(255, 'Marcio Eduardo de Lima Lopes ', 'SECEL', 'Secretaria Municipal de Esporte e Lazer deFortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085)3105-1309', '3254-5848', 'marcio.lopes@fortaleza.ce.gov.br', '----', 'Secretário'),
(256, 'Rosiane Sousa', 'SECEL', 'Secretaria Municipal de Esporte e Lazer deFortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085) 3105-1309      ', '----', 'rosiane.sousa@fortaleza.ce.gov.br', '(085)8898 9922', '----'),
(257, 'Sandra - Secretaria', 'SECEL', 'Secretaria Municipal de Esporte e Lazer deFortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085)3105-1350', '3105-1309', 'sandra.marrocos@fortaleza.ce.gov.br', '----', '----'),
(258, 'Domingos Gomes de Aguiar Neto ', 'SECOPAFOR', 'Secretaria Municipal Extraordinária da Copa ', 'Rua Tibúrcio Cavalcante ,900-Aldeota ', '(085)3105-2721', '-', 'domingosaguiarneto@gmail.com', '----', 'Secretário ');
INSERT INTO `contatos` (`idcontatos`, `nomecontatos`, `siglacontatos`, `orgaocontatos`, `enderecoorgao`, `telefone`, `ramalfone`, `emailcontato`, `celcontato`, `cargocontato`) VALUES
(259, 'Domingos Neto ', 'SECOPAFOR', 'Secretaria Municipal Extraordinária da Copa ', 'Rua Tibúrcio Cavalcante ,900-Aldeota ', '(085)3105-2710', '2711', 'domingosaguiarrneto@gmail.com', '085-9707-0033', '----'),
(260, 'Juliana  ', 'SECOT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '----', '----', '----', '(085)8814-8208', '----'),
(261, 'Marlon Carvalho Cambraia ', 'SECOT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '(085)3452-6776', '----', 'marlon.cambraia@fortaleza.ce.gov.br', '----', 'Secretário '),
(262, 'Wilfrido Tiradentes Da Rocha Neto', 'SECOT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '(085)34526768', '----', 'rocha.neto@fortaleza.ce.gov.br', '----', '----'),
(263, 'Jessica Cordeiro Lucas', 'SECOT', '----', '-', '(058)3452-6778', '-', 'jeissa.lucas@fortaleza.ce.gov.br', '(85)8970-6144', '-'),
(264, 'Francisco Geraldo de Magela Lima Filho', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1146', '----', 'secultfor.fortaleza@gmail.com', '----', 'Secretário'),
(265, 'Inácio Coelho', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1146             ', '----', 'inacio.coelho@fortaleza.ce.gov.br', '(085)8970 4530 / 9994 1963', '----'),
(266, 'Magela Lima', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1146', '----', 'secultfor.fortaleza@gmail.com ', '(085)-8970-2020', '----'),
(267, 'Silvana', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1294', '3105-1146', 'secultfor.fortaleza@gmail.com', '----', '----'),
(268, 'ABGELA', 'SEDUC', 'Secretaria de Educação do Estado', ' Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)31016710', '-', '----', '----', 'MAJOR'),
(269, 'Adriano Sousa', 'SEDUC', 'Secretaria de Educação do Estado', ' Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)3101-3969', '-', 'adrianos@seduc.ce.gov.br', '----', '-'),
(270, 'Giovani  Campelo', 'SEDUC', 'Secretaria de Educação do Estado', 'Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)3101-3963', '3969', 'giovani@seduc.ce.gov.br', '----', 'Gerente'),
(271, 'João Paulo Seduc', 'SEDUC', 'Secretaria de Educação do Estado', 'Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)3101-3969', '----', 'joao.paulo@seduc.ce.gov.br', '----', '----'),
(272, 'Carla Danure', 'SEFAZ', 'Secretaria da Fazenda', 'Av. Pessoa Anta, 274 - Centro', '(85) 3101-9071', '----', '----', '----', '----'),
(273, 'Tales Matos', 'SEFAZ', 'Secretaria da Fazenda', 'Av. Pessoa Anta, 274 - Centro', '(85) 3101-9420', '----', '----', '----', '----'),
(274, 'Eveline Campos', 'SEFIN', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85)3452-5773', '----', 'eveline.campos@sefin.fortaleza.ce.gov.br', '(85) 8757-5057', 'Gerente Técnico em BI'),
(275, 'Clovis', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3495', '----', '----', '----', '----'),
(276, 'Francisco Ricardo Ribeiro', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3495', '----', 'fcoricardovribeiro@hotmail.com/ricardo.ribeiro@sefin.fortaleza.ce.gov.br', '(85)9718-4400', '----'),
(277, 'Helcio', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1118', '----', 'helcio.nascimento@sefin.fortaleza.ce.gov.br', '(085)8888-8669', 'Geografo'),
(278, 'Heloisa Aragão', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'heloisa.aragao@sefin.fortaleza.ce.gov.br', '----', '-'),
(279, 'Jaime Cavalcante', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)31051241', '----', 'jaime.cavalcante@fortaleza.ce.gov.br', '----', '----'),
(280, 'José Jesus Lédio', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3477', '----', 'joseldealencar@yahoo.com.br', '(85)9133-9580', 'Pregoeiro'),
(281, 'Jurandir Gurgel Gondim Filho ', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085) 3105-1238 ', '/39', 'jurandir.gurgel@fortaleza.ce.gov.br ', '085-8970-2892', 'Secretaria'),
(282, 'Liane Carneiro', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3105-2041', '----', '----', '----', 'Setor de TI'),
(283, 'Mariangela Bezerra', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1263', '----', 'mariangela.bezerra@sefin.fortaleza.ce.gov.br', '----', '----'),
(284, 'Paulo Aguiar', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1263', '----', 'paulo.aguiar@sefin.fortaleza.ce.gov.br', '----', '----'),
(285, 'Camila ', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85)3105-1247', '---', '-', '-', '-'),
(286, 'Sara', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3105-1247', '----', 'sarah.correia@sefin.fortaleza.ce.gov.br', '----', '----'),
(287, 'Vanessa Simonassi', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3495 / 3105-1240', '----', 'vanessa.simonassi@sefin.fortaleza.ce.gov.br', '(85) 9164-2994', '----'),
(288, 'Zuilto', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3105-1247', '----', '----', '----', '----'),
(289, 'Verônica Oliveira', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'veronica.oliveira@sefin.fortaleza.ce.gov.br', '(85)9954-0186\n(85)3105-1267', 'Gestora de Projetos'),
(290, ' Clóvis Soares', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'clovis.soares@sefin.fortaleza.ce.gov.br', '(85)3452-3495', 'Assessor de Planejamento'),
(291, 'Zuilton Mendonça', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'zuilton.mendonca@sefin.fortaleza.ce.gov.br', '(85)9760-5069', 'Assessor Jurídico'),
(292, 'João Fernando Santa Cruz m. Neto', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85)3105-1233', '----', 'joao.fernando@sefim.fortaleza.ce.gov.br', '(85)9920-5555\n(85)8888-0076', 'Assessor Jurídico - COAF'),
(293, 'Eliane Montenegro', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3218-6523', '-', 'elianemtg@hotmail.com', '(85)9936-6587', '-'),
(294, 'Silvia Bezerra da Silva', 'SEFIN', 'Secretaria de Finanças', '-', '-', '-', 'c', '(85)9902-1532', '-'),
(295, 'Fco Ricardo Vieira Ribeiro', 'SEFIN', 'Secretaria de Finanças', '-', '(85)3452-3495', '-', 'ricardo.ribeiro@sefin.fortaleza.ce.gov.br', '(85)8879-9097', '-'),
(296, 'Paulo Martins', 'SEFIN ', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)31312100', '----', '----', '----', '----'),
(297, 'Ticiana Mota Sales', 'SEGOV', 'Secretaria de Governo', 'Rua São José ,01- centro', '----', '----', 'ticianamotas@gmail.com', ' (85)8970-6138 / 8671-4000', 'Acessora SEGOV'),
(298, 'Camile Mesquita ', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085)3105-1434', '----', 'camille.mesquita@fortaleza.ce.gov.br', '----', '----'),
(299, 'Crístian/laudélio', 'SEGOV', 'Secretaria Municipal de Governo', 'Rua São josé ,01-Centro', '(085)3105-1438', '1437', '-', '----', '----'),
(300, 'Laudélio Antônio De Oliveira Bastos ', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085) 3105-1434', '----', 'laudelio.bastos@fortaleza.ce.gov.br', '085-8970-3039', '----'),
(301, 'Prisco Rodrigues Bezerra ', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085)3105-1434', '-', 'priscobezerra@yahoo.com.br', '----', 'Secretário   '),
(302, 'Camille', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085)3105-1440', '3105-1434', 'camille.mesquita@fortaleza.ce.gov.br', '----', '----'),
(303, 'Breno Carvalho Coe', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)3105-1077', '----', 'breno.coe@fortaleza.ce.gov.br', '----', '----'),
(304, 'Eduardo Freitas', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85) 3105-1077 ', '----', 'eduardo.freitas@fortaleza.ce.gov.br', '(85) 8878-7781', 'Gestor de TI'),
(305, 'Elani ', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)31051080 ', '/ 1079', '----', '----', 'SECRETARIA DO GABINETE'),
(306, 'Gisele', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)3105-1082', '3105-1089', 'giselle.mafra@fortaleza.ce.gov.br', '----', '----'),
(307, 'Moacir Casemiro', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085) 3105 -1089     ', '----', 'moacir.casemiro@fortaleza.ce.gov.br', '(085)9679-6000', '----'),
(308, 'Moacir Casemiro', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085) 3105 -1089     ', '----', 'moacir.casemiro@fortaleza.ce.gov.br', '(085)9679-6000', '----'),
(309, 'Samuel Antônio Silva Dias ', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085) 3105 -1089     ', '----', 'samuel.dias@fortaleza.ce.gov.br', '(085)-8970-2956', '----'),
(310, 'Samuel Antônio Silva Dias ', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)3105-1079', '1080/1089', 'samuel.dias@fortaleza.ce.gov.br', '----', 'Secretário'),
(311, 'Thiago Mafra', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85)3105-1073', '-----', 'thiago.mafra@arcadislogos.com.br', '-----', '-----'),
(312, 'Fernanda Gabriela Maia', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '----', '----', 'gabriela.maia@fortaleza.ce.gov.br', '(85)9925-2332', '-'),
(313, 'Manuelito Cavalcante', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85)3105-1109', '----', 'manuelito.cavalcante@fortaleza.ce.gov.br', '(85)9994-1200', '-'),
(314, 'João Fernando Menescal', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85) 3452-5255', '-', 'joao.menescal@fortaleza.ce.gov.br', '(85) 8970-3804', 'Coordenador de Gerenciamento de Projetos'),
(315, 'Águeda Muniz ', 'SEMAM', 'Secretaria Meio Ambiente  e Controle Urbano', 'Av. Dep. Paulino Rocha, 1343  - Cajazeiras              ', '(085) 3452-6901 ', '/  6903                       ', 'agueda.muniz@fortaleza.ce.gov.br', '085-8970-2424', '-'),
(316, 'Claúdio Ricardo Gomes De Lima', 'SEMAS', 'Secretaria Municipal de Assistencia Social', 'Av. da Universidade, 3305, Benfica.', ' (085) 3105.3711', '----', '----', '085-8970-3032', '----'),
(317, 'Pedro José Alves Capibaribe', 'SEPLAN', 'Secretaria do planejamento e coordenação do Ceará', 'Av Gal Afonso Albuquerque Lima , 1 , Cambeba, Fortaleza  -  CE', '(085)3101-4457', '3101 4427', 'pedro.capibaribe@cidades/', '----', '-'),
(318, 'Ana Luiza /irenise ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3272-5053', '3433-3644', 'ana.luisa@fortaleza.ce.gov.br', '----', '----'),
(319, 'Ana Socorro Pereira Carvalho ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3779', '----', 'ANA.CARVALHO@FORTALEZA.CE.GOV.BR', '(085)8956-3779', '----'),
(320, 'Gaudino', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3433-3749', '-', '-', '-', '-'),
(321, 'Aparecida Façanha ( Paita)', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-4728', '1941', 'aparecida.facanha@fortaleza.ce.gov.br', '(085)8970 4060 / 8606-9677', '----'),
(322, 'Bene (Benedito)', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-4570', '----', '----', '----', '----'),
(323, 'Cleide', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-1941', '----', 'cleide.madeiro@fortaleza.ce.gov.br', '(085) 8754 9950', '----'),
(324, 'Cristiane Deusdará ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085) 3433-3644 ', '----', 'CRISTIANE.DEUSDARA@FORTALEZA.CE.GOV.BR', '----', '----'),
(325, 'Fatima Falcão', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)31014525', '----', '----', '----', '----'),
(326, 'Haroldo Maranhão ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085) 3433-3644 ', '----', 'haroldo.maranhao@fortaleza.ce.gov.br', '085-8970-3033', 'Coode.TI'),
(327, 'Isabel', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85) 3433-3653', '----', '----', '----', '----'),
(328, 'Isabela', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3433-3749', '----', '----', '----', '----'),
(329, 'João Paulo Neto ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)99560737', '----', 'paulo.neto@fortaleza.ce.gov.br', '----', '----'),
(330, 'Jorge Alberto C. Alcoforado', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-4570', '----', 'jorge.alcoforado@fortaleza.ce.gov.br/jalcoforado@gmail.com', '(085)88029144', '----'),
(331, 'Lucineide Alves da Silva', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85) 3252-4833 / 3101-2186', '----', 'lucineide.silva@fortaleza.ce.gov.br', '----', 'Assessora de Técnica da Assessoria de Planejamento e Desenvolvimento Institucional'),
(332, 'Lúcio Junior', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'lucio.junior@fortaleza.ce.gov.br / luciocimm@yahoo.com.br', '(85) 8614-0440', '-'),
(333, 'Miguel', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', '----', '(85) 8807-8003 / 9612-5917', 'Chefe Programadores'),
(334, 'Neuza  - Secretaria ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3637', '----', '----', '----', '----'),
(335, 'Philipe Theophilo Notthingham', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3644', '3637', 'philipe@fortaleza.ce.gov.br', '----', 'Secretário '),
(336, 'Marcos Cavalcante', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'marcos.cavalcante@fortaleza.ce.gov.br', '(85)8868-9784', '-'),
(337, 'Maria Karoline Cavalcante', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'karolilne.cavalcante@fortaleza.ce.gov.br', '(85)8890-9943', 'Gerente'),
(338, 'Denise Fernandes', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'denise.albuquerque@fortaleza.ce.gov.br', '(85)8678-8115', 'COGEC'),
(339, 'Desiree Mota', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3101-2186', '----', 'desiree.mota@fortaleza.ce.gov.br ', '(85)8563-3726\n \n', 'Assessora de desenvolv. Institucional'),
(340, 'Verene Barbosa', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3433-3656', '----', 'verene.barbosa@fortaleza.ce.gov.br', '(85)8899-8084', 'Gerente'),
(341, 'Aline Lopes Barbosa', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '(85)3433-3624', '-', 'aline.barbosa@fortaleza.ce.gov.br', '-', '-'),
(342, 'Martha Maria de Souza Barroso', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '(85)3433-36651', '-', 'marthasouzaa@hotmail.com', '(85)8850-2154', '-'),
(343, 'Sonja Trigueiroda Silveira Nunes', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '(85)3433-3670', '-', 'cleirtonnune@hotmail.com', '(85)8898-9747', '-'),
(344, 'Rudênia Noberto Maia', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '-', '-', 'ridenia.maia@fortaleza.ce.gov.br', '(85)8814-3430', '-'),
(345, 'Anúsia', 'SER', 'Secretaria Executiva da Regional III', ' Avenida Jovita Feitosa, 1264 - Parquelândia, Fortaleza - CE', '085-3433-2507', '----', 'anusia.holanda@fortaleza.ce.gov.br', '----', '----'),
(346, 'Maria De Fátima Vasconcelos Canuto ', 'SER', 'Secretaria Executiva da Regional III', ' Avenida Jovita Feitosa, 1264 - Parquelândia, Fortaleza - CE', '(085) 3433 -6883 ', '----', 'fatima.canuto@fortaleza.ce.gov.br', '085-8970-3024', '-'),
(347, 'Guilherme Teles Gouveia Neto ', 'SER', 'Secretaria executiva Regional I', ' Rua Dom Jeronomo, 20 - Otávio Bomfim, CE', '(085) 3433-6894 ', '6856', 'guilherme.gouveia@fortaleza.ce.gov.br', '085-8970-3025', '----'),
(348, 'Jéssica', 'SER', 'Secretaria Executiva da Regional VI', 'Av.Dedê Brasil,3770-Serrinha', '(085)3488-3104', '----', 'jessica.barbosa@fortaleza.ce.gov.br', '----', '----'),
(349, 'Julio Ramon Soares Oliveira ', 'SER ', 'Secretaria Executiva da Regional V', 'Av.Augusto dos Anjos,2466- Siqueira ', '(085)3433-2917', '2916/2919/7285', 'julio.ramon@fortaleza.ce.gov.br', '----', 'Secretário '),
(350, 'Francisco Airton Morais Mourão ', 'SER ', 'Secretaria Executiva da Regional  IV', 'Av.Dedê Brasil,3770-Serrinha', '(085) 3232-6021', '----', 'fan.morao@fort.ce.gov.br', '085-8970-3019', '----'),
(351, 'Francisco Airton Morais Mourão ', 'SER ', 'Secretaria Executiva da Regional IV', 'Av.Dedê Brasil,3770-Serrinha', '(085)3232-6021', '3433-2802', 'gabineteregional4@hotmail.com', '----', 'Secretário'),
(352, 'Maria de Fátima Vasconcelos Canuto', 'SER ', 'Secretaria Executiva da Regional III', 'Av.Jovita Feitosa ,1264-Parquelândia ', '(085)3433-6883', '----', 'fatimacanuto@yahoo.com.br', '----', 'Secretária '),
(353, 'Claúdia', 'SER ', 'Secretaria Executiva da Regional V', 'Avenida Augusto do Anjos, 2466 - Siqueira.', '(085)3433-2918', '3433-2916/2916/2919', 'Claudia_ribeiro@hotmail.com ', '----', '----'),
(354, 'Renato César Pereira Lima', 'SER ', 'Secretaria Executiva da Regional VI', 'Rua Padre Pedro de Alencar ,798- Messejana', '(085)3488-3116', '3170', 'renato.lima@fortaleza.ce.gov.br', '----', 'Secretário '),
(355, 'Claúdio Nelson Araújo Brandão ', 'SER ', 'Secretaria Executiva da Regional II ', 'Rua Professor Juraci de Oliveira ,01-Edson Queiroz ', '(085)3241-4755', '----', 'claudio.nelson@fortaleza.ce.gov.br', '----', 'Secretário '),
(356, 'Aldeniza', 'SER  ', 'Secretaria  Executiva da Regional  IV', 'Av.Dedê Brasil,3770-Serrinha', '(085) 3232-6021', '3232-6021/3433-2802', 'anisia_2005@hotmail.com', '----', '-'),
(357, 'Ricardo Sales', 'SER C', 'Secretaria Regional Centro', '-', '----', '---', 'ricardo.sales@fortaleza.ce.gov.br/ricardopsales@gmail.com', '(85)8682-2164', '-'),
(358, 'Sâmia Maria Pontes do Nascimento Cavalcante', 'SER Centro', 'Secretaria Regional Centro', '-----', '(85) 3105-1323', '----', 'samia.cavalcante@fortaleza.ce.gov.br', '(85) 8697-3100', 'Coordenadora Administrativa-Financeira'),
(359, 'Jackeline Facó Tavares', 'SER I', 'Secretaria Regional I', '-', '(85)3433-6894', '---', 'jackelinefaco@hotmail.com', '(85)8898-4499', '-'),
(360, 'Giselle Ribeiro de Alencar Alves', 'SER I', 'Secretaria Regional I', '-', '(85) 3433-6864', '---', 'giselle.alencar@fortaleza.ce.gov.br/gi1fidio9@gmail.com', '(85)9924-8901', '-'),
(361, 'Tereza Neumam Girão Saraiva', 'SER II', 'Secretaria Regional II', '-----', '(85) 3241-4794 ', '(85)3241-4754', 'teresa.saraiva@fortaleza.ce.gov.br', '(85) 8970-2068/9614-9038', 'Coordenadora da Assessoria de Planejamento'),
(362, 'Davi Teixeira', 'SER II', 'Secretaria Regional II', 'Rua Professor Juraci de Oliveira, 01 - Edson Queiroz.', '(85)3241-4868', '----', 'davi.teixeira@fortaleza.ce.gov.br', '(85)8723-0810', 'Chefe da infraestrutura'),
(363, 'Guto Azevedo', 'SER II', 'Secretaria Regional II', 'Rua Professor Juraci de Oliveira, 01 - Edson Queiroz.', '----', '----', 'guto.azevedo@fortaleza.ce.gov.br', '(85)9624-3512', '----'),
(364, 'José Rubson Augusto Mendes', 'SER II', 'Secretaria Regional II', '-', '---', '---', 'rubson@bol.com.br', '(85)8970-2065', '-'),
(365, 'Maria Verbenia Pontes Cavalcante', 'SER III', 'Secretaria Regional III', '-', '(85) 3433-2520', '-', 'verbeniapontes@yahoo.com.br', '(85)9997-3143', '-'),
(366, 'Icaro Regis Batista', 'SER III', 'Secretaria Regional III', '-', '(85) 3433-2520', '---', 'icaroregis@yahoo.com.br', '(85) 8689-2878', '-'),
(367, 'José Wellington Guerreiro', 'SER III', 'Secretaria Regional III', '-', '(85) 3433-2548', '-', 'jwellington.guerreiro@hotmail.com/jose.guerreiro@fortaleza.ce.gov.br', '(85) 9983-9755', '-'),
(368, 'Neide Lacerda', 'SER IV', 'Secretaria Regional IV', '-----', '(85) 3433-2860', '----', 'neide.lacerda@fortaleza.ce.gov.br', '----', 'Coordenadora do Administrativo Financeiro'),
(369, 'Isaac Anderson Barbosa', 'SER IV', 'Secretaria Regional IV', '-', '---', '---', 'isaac.barbosa@fortaleza', '(85)9723-3068', '-'),
(370, 'Adriano Aguiar Câmara', 'SER IV', 'Secretaria Regional IV', '-', '(85)3433-2807', '---', 'infraestruturaserIV@gmail.com', '(85) 8814-8058', '-'),
(371, 'Emanuella de Medeiros Santos', 'SER V', 'Secretaria Regional V', '-', '-', '-', 'Emannuellamedeiros@hotmail.com', '(85) 9905-7591', '-'),
(372, 'Maria das Graças Rodrigues', 'SER V', 'Secretaria Regional V', '-', '(85)3433-2902', '-', 'graça.rodrigues@fortaleza.ce.gov.br', '(85) 8570-2709', '-'),
(373, 'João Helder', 'SER VI', 'Secretaria Regional IV', '-', '(85) 3488-3101', '-', 'jhamoren2013@gmail.com', '(85) 8591-2150', '-'),
(374, 'Carlos Queioz Filho', 'SER VI', 'Secretaria Regional IV', '-', '(85) 3452-1936', '-', 'carlospqf@hotmail.com/carlos.filho@fortaleza.ce.gov.br', '(85) 8603-1020/8970-3486', '-'),
(375, 'Francisco Regis Cavalcante Dias ', 'SERCEFOR', 'Secretaria da Regional do Centro de Fortaleza ', 'Rua Guilherme Rocha,175- Centro', '(085)3242-3081', '----', 'regis.dias@fortaleza.ce.gov.br', '----', 'Secretário'),
(376, 'Otavia /renan', 'SERCEFOR', 'Secretaria da Regional do Centro de Fortaleza ', 'Rua Guilherme Rocha,175- Centro', '(085)3252-3081', '----', '----', '----', '----'),
(377, 'Andre Souza', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-8804', '----', 'andresouzagmf@gmail.com', '(085)8865-2007', '----'),
(378, 'Armando Vidal', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085) 3281-8151    ', '----', 'armandovidal26@hotmail.com', '(085)8531-9363', '----'),
(379, 'Flavia ', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281 8151', '(085)32818804', '----', '----', '----'),
(380, 'Flavia - Assistente', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281- 8151', '3281-8804', '----', '----', '----'),
(381, 'Francisco José Veras de Albuquerque', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-8804', '----', 'fcoveras@gmail.com', '----', 'Secretário'),
(382, 'Franklin Teógenis Brandão de Souza', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '----', '----', 'teogenis.souza@fortaleza.ce.gov.br', '(85) 8750-3556', 'Gerente da Célula de Análise e de Sistemas'),
(383, 'Valeria - Secretaria', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281- 8804', '----', 'valcorpo@yahoo.com.br', '----', '----'),
(384, 'Jeane Peixoto', 'SESEC/GMF', '-------', '-', '(85)3281-2570', '-', 'jeane.sampaio@fortaleza.ce.gov.br', '(85)8869-0679', '-'),
(385, 'João Salmito Filho', 'SETFOR', 'Secretaria Municipal de Turismo de Fortaleza', 'Rua Leonardo Mota ,2700- Aldeota ', '(085)3105-1514', '1535', 'salmitofilho@yahoo.com.br', '----', 'Secretário'),
(386, 'Sonia /luiza ', 'SETFOR', 'Secretaria Municipal de Turismo de Fortaleza', 'Rua Leonardo Mota ,2700- Aldeota ', '(085)3105-1513', '(085)3105-1514', 'sonia.almeida@fortaleza.ce.gov.br', '----', '----'),
(387, 'Larissa Almeida Morais ', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '----', '----', 'larissamorais@hotmail.com', '(085)87151197', '----'),
(388, 'Lidiane Rios ', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(085)31053442', '----', 'lidiana.farias@fortaleza.ce.gov.br', '(085)89703506', '----'),
(389, 'Renata Azevedo ', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '----', '----', 'renata.azevedo@fortaleza.ce.gov.br', '(085)86006059', '----'),
(390, 'Robson Andrade', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(85)3105-3445', '----', 'robsongandrade@hotmail.com', '(85)8203-1510', 'TI'),
(391, 'Robson Bandeira', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '-', '-', 'robson.bandeira@fortaleza.ce.gov.br', '(85)9630-9342/(85) 8970-4614', 'Diretor de Desenvolvimento da Setra'),
(392, 'Renata Custodio', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(85)3105-3416', '-', 'renata_custodio@yahoo.com.br', '(85)8600-6059', '----'),
(393, 'Raimundo Ferreira', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '-', '-', 'rdofilho@gmail.com', '(85)8970-3548', '----'),
(394, 'Claúdio Ricardo Gomes de Lima', 'SETRA ', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(085)3105-3708', '3711', 'claudio.lima@fortaleza.com.br', '----', 'Secretário '),
(395, 'Dinha  - Secretaria', 'SETRA ', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(085)3105-3440', '3105-3708/3711/3445', 'dinhafeijo@hotmail.com', '----', '----'),
(396, 'Alfredo Miranda ', 'SEUMA', 'Secretaria Municipal de Urbanismo e Meio Ambiente ', 'Av.Dep.Paulino Rocha ,1343- Cajazeiras ', '(085) 3452-6924', '/  6903                       ', 'alfredocmf@gmail.com', '(085)88471120', 'Gerente de TI'),
(397, 'Cilene/kelvia', 'SEUMA', 'Secretaria Municipal de Urbanismo e Meio Ambiente ', 'Av.Dep.Paulino Rocha ,1343- Cajazeiras ', '(085)3253-3911', '3452-6901/6903', 'cilene.fernandes@fortaleza.ce.gov.br', '----', '----'),
(398, 'Maria Águeda Pontes Caminha Muniz', 'SEUMA', 'Secretaria Municipal de Urbanismo e Meio Ambiente ', 'Av.Dep.Paulino Rocha ,1343- Cajazeiras ', '(085)3452-6901', '6903', 'seuma.fortaleza@gmail.com', '----', 'Secretária '),
(399, 'Carlos Assis', 'SME', 'Secretaria Municipal da Educação', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5590', '----', '----', '----', '----'),
(400, 'Delis Carvalho', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5904', '----', 'delis.carvalho@sme.fortaleza.ce.gov.br', '----', '----'),
(401, 'Glaumer', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459- 5902', '----', '----', '----', 'Geografo'),
(402, 'Iran Maia Nobre ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085) 3459-5915', '/ 5993 / 5941     ', 'IRANNOBRE@YAHOO.COM.BR', '(085) 8943 6146/8732-1286/9717-2632', '----'),
(403, 'Ivo Ferreira Gomes ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5933', '5993-5941', 'ivo23456@uol.com.br', '----', 'Secretário'),
(404, 'João Lúcio De Alcântra ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3454-5960', '/ 5993 / 5941     ', '----', '(085)8970-2045', '----'),
(405, 'Lamartine', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3454-5960', '----', '----', '(085)8834-6934', '----'),
(406, 'Lú ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '----', '----', '----', '----', '----'),
(407, 'Paulo Sarmento', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3454-5960', '----', 'paulocvs@sme.fortaleza.ce.gov.br', '(085)8723-3280', '----'),
(408, 'Ana Luisa Macedo Trindade ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(85)3459-6761', '-', 'analuisa@sme.fortaleza.ce.gov.br', '(85)9955-9120\n', 'Gerente da célula de processos licitatórios'),
(409, 'Jeovah Carvalho Lima Pereira', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(85)3433-3588\n', '-', 'jeovah.carvalho@sme.fortaleza.ce.gov.br', '(85)8543-4787\n', 'Chefe do Setor de Compras\n'),
(410, 'Sônia  De Almeida Araujo', 'SME', 'Secretaria Municipal De Educação', 'Secretaria Municipal de Educação ', '----', '----', 'sonialmeidaraujo@gmail.com', '----', '----'),
(411, 'Alcides Oliveira Alcoforado', 'SME ', 'Secretaria Municipal da Educação', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5984', '-', 'alcides@sme.fortaleza.ce.gov.br', ' (085) 8970 -2102', '-'),
(412, 'André', 'SME ', 'Secretaria Municipal de Educação ', 'Rua do Rosário ,283,2ºe 3º.Andar - Centro ', '(085)3459 5916', '----', '----', '----', '----'),
(413, 'Luiza Brilhante', 'SME ', 'Secretaria Municipal de Educação ', 'Rua do Rosário ,283,2ºe 3º.Andar - Centro ', '(85)3459 5927', '----', '----', '----', '----'),
(414, 'Alexandre', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6611', '-', '-', '----', '-'),
(415, 'Eduardo Cabral Maia', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085) 3452-6954', '/6604 ', 'eduardocm@sms.fortaleza.ce.gov.br', '(085)9983-0304/ (85)8970-3273', 'Técnico da Área'),
(416, 'Fabiana', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', '----', '(085)8690-7644', '----'),
(417, 'Fernanda Aparecida', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6992', '3452-6604/6605', '----', '----', '----'),
(418, 'Gesiel Sousa', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6992', '3452-6604/6605', 'gsousa@sms.fortaleza.ce.gov.br', '(085)9989-8421', '----'),
(419, 'Igor Girão Barbosa', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6992', '3452-6604/6605/6611', 'igirao@sms.fortaleza.ce.gov.br', '(085) 8807-8123', '----'),
(420, 'Marcos Oliveira', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-2357/(85)3105-1493', '----', 'moliveira@sms.fortaleza.ce.gov.br', '----', '----'),
(421, 'Osmar Jose do Nascimento', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)34526954', '----', 'osmarjnascimento@gmail.com', '(085)86234245', '----'),
(422, 'Rosalivia', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3452-2357', '----', '----', '9925-9506', '----'),
(423, 'Suzani Costa', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-2357', '----', 'colegiadocotec@sms.fortaleza.ce.gov.br', '----', '----'),
(424, 'Francisco José Santos de Almeida', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(85) 3452-6984', '----', 'fjalmeida@sms.fortaleza.ce.gov.br', '(85) 8970-4627', 'Coordenador de Infaestrutura'),
(425, 'Aline Bárbara Rosa de Almeida ', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'alinebarbarar@hotmail.com', '(85)8699-7339\n(85)8970-3556', 'Gestora de Compras e licitações'),
(426, 'Jamilli Honorato Alburquerque', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3452-6600', '6602', 'jhonorato@sms.fortaleza.ce.gov.br/jamillihonorato@gmail.com', '(85)8859-5407', 'Assistente de Compras e Licitações'),
(427, 'Márcia Chrisostomo', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'mchrisostomo@uol.com.br', '(85)8864-6196', 'Gerente de material e patrimônio'),
(428, 'Antônia Itamárcia Carneiro', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'antonia.itamarcia@fortaleza.ce.gov.br', '(85)9969-7349', 'Diretora'),
(429, 'Maria Auxiliadora', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'auxiliadora123@yahoo.com.br', '(85)8844-1600', 'Coor. Ass. Planejamento'),
(430, 'Lorena Gomes Moura', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'lorenagmoura@gmail.com', '(85)8800-5420', 'Gerente Administrativa'),
(431, 'Cristianne', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'cristianneamoris@gmail.com', '(85)8970-4074/8680-5901', 'Assistente da Ticiana Mota'),
(432, 'Bianca Moreira Coêlho', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85) 3452-3535', '-', 'biancacoelho@oi.com.br', '(85) 8822-7212', '-'),
(433, 'Humberto Vitorino', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'humberto.vd@hotmail.com', '(85)8563-2627', '-'),
(434, 'Antônia Adeny Leite', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3255-5053', '-', 'adeny.leite@yahoo.com.br', '(85)9611-9133', '-'),
(435, 'Oselita', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'oselita_gondim@yahoo.com.br', '(85)8789-1889', '-'),
(436, 'Hilda Ponciano Lima', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3255-5042', '-', 'poncianohilda@hotmail.com', '(85)9954-1964', '-'),
(437, 'Lúcia Cidrão', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'lucia.cidao@sms.fortaleza.ce.gov.br', '(85)8906-2139', '-'),
(438, 'Thiala Josino', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'josino.thiala@gmail.com', '(85)8771-7325', '-'),
(439, 'Alexandre Pinto', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'alpinto@sms.fortaleza.ce.gov.br/ alexpinto2@gmail.com', '(85) 8588 8486/(85) 9731 7329', '-'),
(440, 'Andrea Couto', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'acouto@sms.fortaleza.ce.gov.br', '(85) 8537-0739', 'Anaslista de Infraestrutura'),
(441, 'Selma Nunes', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'sellnunes@hotmail.com', '(85) 8652-8052', '-'),
(442, 'Dr. André Bomfim', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452.23789', '-', 'andrebbomfim@gmail.com', '(085)8827-2903', '-'),
(443, 'Maria Do Perpetuo Socorro Martins Breckenfeld', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário, n° 283, 03 andar, no centro, em frente a praça da Policia Militar.', '(085)3452-6605', '6604/1786', 'socorrohm@gmail.com', '----', 'Secretária '),
(444, 'André Bomfim', 'SMS', '------', '-', '(085)3488.6966 / 6973   ', '----', ' andrebbomfim@gmail.com', '(085)8827-2903', '-'),
(445, 'Major Aguiar', 'SSPDS', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(85) 3101-6561 ', '----', '----', '(85) 8841-0332 / 8749-0118', 'Major da Polícia Militar'),
(446, 'Major Tetuliano', 'SSPDS', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(85) 3101-6512', '----', '----', '----', '----'),
(447, 'AGUIAR', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)31016561', '-', '-', '(085)88410332/87490118', '-'),
(448, 'Dr. Fernando', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)31016551', '----', '----', '----', 'COORDENADOR OPERACIONAL'),
(449, 'Fernando Menezes', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)3101 6544', '----', '----', '----', '----'),
(450, 'Franklin', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)31016576', '----', 'franklin.torres@sspds.ce.gov.br', '----', '----'),
(451, 'Carlos de Paula', 'TABLEAU', 'Tableau Software', '-----', '-----', '----', '----', '(21) 982588285', 'Gerente Regional de Vendas'),
(452, 'André França', 'TI Gabinete', '---------', '-', '(85)3105-1450', '-', '-', '-', '-'),
(453, 'Jorzerlei', 'Unidade de Patrimonio', '-----', '-----', '(085)3452-1987', '----', '----', '----', '----'),
(454, 'Edna  Bento/Damião/Fabio', 'Unidade Financeiro ', '-----', '-----', '(085)3105-1457', '----', 'edna.bento@fortaleza.ce.gov.br', '----', '----'),
(455, 'Tatiana', 'Vice-prefeitura', 'Vice-Prefeitura Municipal', '-----', '(085)3452-1653', '----', 'tatiana.gomes@fortaleza.ce.gov.br', '----', '----'),
(456, 'Gaudencio Gonçalves de Lucena ', 'VICE-PREFEITURA', 'Vice-Prefeito Municipal', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1652', '----', 'gaudenciolucena@gmail.com', '----', 'Vice-Prefeitura'),
(457, 'Ricardo Fontenele', 'VTI', 'Tecnologia  da Informação', 'R. Tibúrcio Cavalcante n 1573 Aldeota- Ed.VTI', '(085)40095290', '----', '----', '(085)9728-8889', '----'),
(458, 'Wagner Moura', 'VTI', 'Soluções Integradas a Gestões Inteligentes', 'Rua Tibúrcio Cavalcante, 1573 – Aldeota ', '(85) 4009-5290', '----', 'wagnermoura@vti.com.br', '(85) 9728-8889', 'Gerente de Negocios'),
(459, 'Marcelo Marcony', 'VTI', 'VTI', 'Rua Tiburcio Cavalcante, 1573, Aldeota.', '(85)4009-5290', '----', 'marcony@vti.com.br', '(85)9728-9394', 'Gerente Executivo - Tecnologia'),
(460, 'Marcelo Soares', 'VTI', 'VTI', 'Rua Tiburcio Cavalcante, 1573, Aldeota.', '(85)4009-5291', '----', 'marcelo@vti.com.br', '(85) 9986-8522', 'Executivo de negocios.'),
(461, 'Luiz Pedrette', 'VTI', 'VTI', 'Rua Tiburcio Cavalcante, 1573, Aldeota.', '(85)4009-5292', '----', 'luizpedrette@vti.com.br', '(85)9943-2839', 'Gerente de Negocios'),
(462, 'Reginaldo Mesquita Dos Anjos', '-----', '-----', '----', '------', '----', 'reginaldomesquitacontas@hotmail.com', '----', '----'),
(463, 'Joacy leite ', '------', '-------', '-------', '------', '----', '------', '(85)9998-9438', '-----'),
(464, 'Dorinha', '------', '------', '-----', '-----', '----', '-----', '(85)9757-6981', '-----'),
(468, 'Nome Editado', 'Orgão Editado', NULL, NULL, '(99) 9999-9999 1', '9999/1111', 'email@editado.com', '(99) 9999-9999 1', 'Cargo Editado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ligacoes`
--

CREATE TABLE IF NOT EXISTS `ligacoes` (
  `id_ligacao` int(5) NOT NULL AUTO_INCREMENT,
  `membro` varchar(255) NOT NULL,
  `destinatario` varchar(255) NOT NULL,
  `assunto` varchar(255) NOT NULL,
  `data_hora` datetime NOT NULL,
  `status_ligacao` enum('Realizado','Remarcado','Pendente','Cancelado') NOT NULL,
  PRIMARY KEY (`id_ligacao`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Extraindo dados da tabela `ligacoes`
--

INSERT INTO `ligacoes` (`id_ligacao`, `membro`, `destinatario`, `assunto`, `data_hora`, `status_ligacao`) VALUES
(5, 'Responsável', 'Destinatário', 'Assunto novo', '2014-11-17 14:47:36', 'Realizado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ligacoes_log`
--

CREATE TABLE IF NOT EXISTS `ligacoes_log` (
  `id_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_ligacao` int(11) NOT NULL,
  `data_log` datetime NOT NULL,
  `duracao` varchar(255) NOT NULL,
  `nota` varchar(255) NOT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `ligacoes_log`
--

INSERT INTO `ligacoes_log` (`id_log`, `id_ligacao`, `data_log`, `duracao`, `nota`) VALUES
(1, 5, '2014-11-16 07:25:37', '10:00', 'Uma anotação sobre a ligação'),
(2, 5, '2014-11-17 05:20:30', '15:00', 'outra anotação'),
(3, 5, '2014-11-16 23:54:38', '15:00', '123456');

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_users`
--

CREATE TABLE IF NOT EXISTS `log_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `datahora` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Extraindo dados da tabela `log_users`
--

INSERT INTO `log_users` (`id`, `id_user`, `descricao`, `datahora`) VALUES
(1, 1, 'Descricao', '2014-06-17 05:15:25'),
(2, 1, 'editou UNIDADE ORÇAMENTÁRIA &quot;01101&quot; para &quot;C&Acirc;MARA MUNICIPAL DE FORTALEZA&quot;', '2014-06-17 23:03:34'),
(3, 1, 'editou UNIDADE ORÇAMENTÁRIA &quot;01101&quot; para &quot;C&Acirc;MARA MUNICIPAL DE FORTALEZA&quot;', '2014-06-24 18:53:43'),
(4, 1, 'editou USUÁRIO &quot;Marcio Seabra&quot; tipo &quot;A&quot;', '2014-06-24 21:49:14'),
(5, 4, 'editou AÇÃO &quot;24&quot; para &quot;&quot;', '2014-06-24 22:03:54'),
(6, 4, 'editou META FÍSICA &quot;24&quot;', '2014-06-24 22:06:48'),
(7, 1, 'editou EIXO &quot;001&quot; para &quot;MELHORIA DA QUALIDADE DE VIDA E JUSTI&Ccedil;A SOCIAL&quot;', '2014-06-25 09:01:38'),
(8, 1, 'editou EIXO &quot;001&quot; para &quot;MELHORIA DA QUALIDADE DE VIDA E JUSTI&Ccedil;A SOCIAL 1&quot;', '2014-06-25 09:01:49'),
(9, 1, 'editou EIXO &quot;001&quot; para &quot;MELHORIA DA QUALIDADE DE VIDA E JUSTI&Ccedil;A SOCIAL&quot;', '2014-06-25 09:01:56'),
(10, 1, 'editou USUÁRIO &quot;Usu&aacute;rio Editor&quot; tipo &quot;U&quot;', '2014-06-27 16:03:29'),
(11, 1, 'editou META FÍSICA &quot;15&quot;', '2014-06-30 15:34:50'),
(12, 1, 'editou META FÍSICA &quot;16&quot;', '2014-06-30 15:35:02'),
(13, 1, 'editou META FÍSICA &quot;17&quot;', '2014-06-30 15:35:10'),
(14, 1, 'editou META FÍSICA &quot;18&quot;', '2014-06-30 15:35:20'),
(15, 1, 'editou META FÍSICA &quot;15&quot;', '2014-06-30 15:36:58'),
(16, 1, 'editou META FÍSICA &quot;16&quot;', '2014-06-30 15:37:06'),
(17, 1, 'editou META FÍSICA &quot;17&quot;', '2014-06-30 15:37:15'),
(18, 1, 'editou META FÍSICA &quot;18&quot;', '2014-06-30 15:37:24'),
(19, 1, 'editou META FÍSICA &quot;19&quot;', '2014-06-30 15:37:34'),
(20, 1, 'editou META FÍSICA &quot;24&quot;', '2014-06-30 15:37:53'),
(21, 1, 'editou META FÍSICA &quot;15&quot;', '2014-06-30 15:39:11'),
(22, 1, 'editou META FÍSICA &quot;16&quot;', '2014-06-30 15:39:22'),
(23, 1, 'editou META FÍSICA &quot;17&quot;', '2014-06-30 15:39:28'),
(24, 1, 'editou META FÍSICA &quot;18&quot;', '2014-06-30 15:39:37'),
(25, 1, 'editou META FÍSICA &quot;19&quot;', '2014-06-30 15:39:45'),
(26, 1, 'editou META FÍSICA &quot;24&quot;', '2014-06-30 15:40:12'),
(27, 1, 'adicionou META FÍSICA para o projeto &quot;1&quot;', '2014-07-05 21:53:21'),
(28, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:31:12'),
(29, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:42:45'),
(30, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:42:50'),
(31, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:42:59'),
(32, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:43:25'),
(33, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 14:10:15'),
(34, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 14:10:28'),
(35, 1, 'editou META FÍSICA &quot;3&quot;', '2014-07-23 14:21:23'),
(36, 1, 'editou USUÁRIO &quot;Marcio Seabra&quot; tipo &quot;A&quot;', '2014-08-14 10:35:50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `orgao`
--

CREATE TABLE IF NOT EXISTS `orgao` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `orgao` varchar(2) DEFAULT NULL,
  `orgaoSefin` varchar(2) DEFAULT NULL,
  `unorc` varchar(5) DEFAULT NULL,
  `gestor` varchar(2) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `sigla` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Extraindo dados da tabela `orgao`
--

INSERT INTO `orgao` (`codigo`, `orgao`, `orgaoSefin`, `unorc`, `gestor`, `descricao`, `sigla`) VALUES
(1, '01', '01', '01101', '01', 'C&Acirc;MARA MUNICIPAL DE FORTALEZA', NULL),
(2, NULL, '53', '01901', '01', 'FUNDO ESPECIAL DA CÂMARA MUNICIPAL DE FORTALEZA', NULL),
(3, '11', '11', '11101', '11', 'GABINETE DO PREFEITO', NULL),
(4, NULL, '78', '11202', '11', 'INSTITUTO DE PLANEJAMENTO DE FORTALEZA', NULL),
(5, NULL, '84', '11203', '11', 'FUNDAÇÃO DE DESENVOLVIMENTO HABITACIONAL DE FORTALEZA', NULL),
(6, NULL, '82', '11901', '11', 'FUNDO MUNICIPAL DE JUVENTUDE DE FORTALEZA', NULL),
(7, '12', '12', '12101', '12', 'GABINETE DO VICE-PREFEITO', NULL),
(8, '13', '13', '13101', '13', 'PROCURADORIA GERAL DO MUNICÍPIO', NULL),
(9, NULL, '88', '13201', '13', 'AUTARQUIA DE REGULAÇÃO, FISCALIZAÇÃO E CONTROLE DOS SERVIÇOS PÚBLICOS DE SANEAMENTO AMBIENTAL', NULL),
(10, NULL, '89', '13901', '13', 'FUNDO DE APERFEIÇOAMENTO DA PROCURADORIA GERAL DO MUNICÍPIO', NULL),
(11, '15', '15', '15101', '15', 'SECRETARIA MUNICIPAL DE GOVERNO', NULL),
(12, '16', '16', '16101', '16', 'SECRETARIA DA CONTROLADORIA E TRANSPARÊNCIA', NULL),
(13, '17', '17', '17101', '17', 'SECRETARIA MUNICIPAL DE SEGURANÇA CIDADÃ', NULL),
(14, NULL, '97', '17102', '17', 'GUARDA MUNICIPAL DE FORTALEZA', NULL),
(15, '18', '18', '18101', '18', 'SECRETARIA MUNICIPAL DE PLANEJAMENTO, ORÇAMENTO  E GESTÃO', NULL),
(16, NULL, '62', '18201', '18', 'INSTITUTO MUNICIPAL DE PESQUISAS, ADMINISTRAÇÃO E RECURSOS HUMANOS', NULL),
(17, NULL, '67', '18202', '18', 'INSTITUTO DE PREVIDÊNCIA DO MUNICÍPIO - PREVFOR', NULL),
(18, NULL, '68', '18203', '18', 'INSTITUTO DE PREVIDÊNCIA DO MUNICÍPIO - SAÚDE', NULL),
(19, '19', '19', '19101', '19', 'SECRETARIA MUNICIPAL DE CONSERVAÇÃO E SERVIÇOS PÚBLICOS', NULL),
(20, NULL, '63', '19201', '19', 'AUTARQUIA MUNICIPAL DE TRÂNSITO, SERVIÇOS PÚBLICOS E CIDADANIA DE FORTALEZA', NULL),
(21, NULL, '69', '19202', '19', 'EMPRESA MUNICIPAL DE LIMPEZA E URBANIZAÇÃO', NULL),
(22, NULL, '87', '19203', '19', 'INSTITUTO DE PESOS E MEDIDAS DE FORTALEZA', NULL),
(25, NULL, '70', '19901', '19', 'FUNDO MUNICIPAL DE LIMPEZA URBANA', NULL),
(26, '23', '23', '23101', '23', 'SECRETARIA MUNICIPAL DE FINANÇAS', NULL),
(27, NULL, '37', '24901', '24', 'FUNDO MUNICIPAL DE EDUCAÇÃO', NULL),
(28, NULL, '36', '25201', '25', 'INSTITUTO DR. JOSÉ FROTA', NULL),
(29, NULL, '72', '25901', '25', 'FUNDO MUNICIPAL DE SAÚDE - ADMINISTRAÇÃO GERAL', NULL),
(30, NULL, '05', '25908', '25', 'HOSPITAL DISTRITAL GONZAGA MOTA/BARRA DO CEARÁ', NULL),
(31, NULL, '10', '25909', '25', 'CENTRO DE ESPECIALIZAÇÕES MÉDICAS JOSÉ DE ALENCAR', NULL),
(32, NULL, '02', '25910', '25', 'HOSPITAL DISTRITAL EVANDRO AYRES DE MOURA', NULL),
(33, NULL, '03', '25911', '25', 'HOSPITAL DISTRITAL  MARIA JOSÉ BARROSO', NULL),
(34, NULL, '08', '25912', '25', 'HOSPITAL LÚCIA DE FÁTIMA/CROA', NULL),
(35, NULL, '06', '25913', '25', 'HOSPITAL DISTRITAL GONZAGA MOTA/JOSÉ WALTER', NULL),
(36, NULL, '07', '25914', '25', 'HOSPITAL DISTRITAL NOSSA SENHORA DA CONCEIÇÃO', NULL),
(37, NULL, '04', '25915', '25', 'HOSPITAL DISTRITAL GONZAGA MOTA/MESSEJANA', NULL),
(38, NULL, '09', '25916', '25', 'HOSPITAL DISTRITAL EDMILSON BARROS DE OLIVEIRA', NULL),
(39, NULL, '86', '25918', '25', 'HOSPITAL DA MULHER', NULL),
(40, '26', '26', '26101', '26', 'SECRETARIA MUNICIPAL DE DESENVOLVIMENTO ECONÔMICO', NULL),
(41, NULL, '64', '26201', '26', 'FUNDAÇÃO DE CULTURA, ESPORTE E TURISMO DE FORTALEZA', NULL),
(42, NULL, '46', '26901', '26', 'FUNDO MUNICIPAL DE DESENVOLVIMENTO SOCIOECONÔMICO', NULL),
(43, NULL, '47', '26902', '26', 'FUNDO MUNICIPAL DE FINANCIAMENTO DO PROGRAMA CREDJOVEM', NULL),
(44, '27', '27', '27101', '27', 'SECRETARIA MUNICIPAL DE INFRAESTRUTURA', NULL),
(45, '28', '28', '28101', '28', 'SECRETARIA MUNICIPAL DE URBANISMO E MEIO AMBIENTE', NULL),
(46, NULL, '74', '28901', '28', 'FUNDO DE DEFESA DO MEIO AMBIENTE', NULL),
(47, '29', '29', '29101', '29', 'SECRETARIA MUNICIPAL DE ESPORTE E LAZER', NULL),
(48, '30', '30', '30101', '30', 'SECRETARIA MUNICIPAL DE TURISMO DE FORTALEZA', NULL),
(49, '31', '31', '31101', '31', 'SECRETARIA MUNICIPAL DE TRABALHO, DESENVOLVIMENTO SOCIAL E COMBATE A FOME', NULL),
(50, NULL, '59', '31901', '31', 'FUNDO MUNICIPAL DE ASSISTÊNCIA SOCIAL', NULL),
(51, '32', '32', '32101', '32', 'SECRETARIA MUNICIPAL DE CULTURA DE FORTALEZA', NULL),
(52, NULL, '49', '32901', '32', 'FUNDO MUNICIPAL DE CULTURA', NULL),
(53, '35', '35', '35101', '35', 'SECRETARIA MUNICIPAL DE CIDADANIA E DIREITOS HUMANOS', NULL),
(54, NULL, '71', '35201', '35', 'FUNDAÇÃO DA CRIANÇA E DA FAMÍLIA CIDADÃ', NULL),
(55, NULL, '76', '35901', '35', 'FUNDO MUNICIPAL DE DEFESA DOS DIREITOS DIFUSOS', NULL),
(56, NULL, '77', '35902', '35', 'FUNDO MUNICIPAL DE DEFESA DOS DIREITOS DA CRIANÇA E DO ADOLESCENTE', NULL),
(57, NULL, '39', '39101', '39', 'SECRETARIA REGIONAL DO CENTRO', NULL),
(58, '40', '40', '40101', '40', 'SECRETARIA REGIONAL I', NULL),
(59, '41', '41', '41101', '41', 'SECRETARIA REGIONAL II', NULL),
(60, '42', '42', '42101', '42', 'SECRETARIA REGIONAL III', NULL),
(61, '43', '43', '43101', '43', 'SECRETARIA REGIONAL IV', NULL),
(62, '44', '44', '44101', '44', 'SECRETARIA REGIONAL V', NULL),
(63, '45', '45', '45101', '45', 'SECRETARIA REGIONAL VI', NULL),
(64, '52', '52', '52101', '52', 'SECRETARIA MUNICIPAL EXTRAORDINÁRIA DA COPA 2014', NULL),
(65, '', '95', '80101', '80', 'RECURSOS SOB A SUPERVISÃO DA SECRETARIA MUNICIPAL DE FINANÇAS', NULL),
(66, NULL, '96', '80102', '80', 'RECURSOS SOB A SUPERVISÃO DA SECRETARIA MUNICIPAL DE PLANEJAMENTO, ORÇAMENTO E GESTÃO', NULL),
(67, '90', '90', '90101', '90', 'RESERVA DE CONTINGÊNCIA', NULL),
(68, '24', '24', '24101', '24', 'SECRETARIA MUNICIPAL DE EDUCAÇÃO', NULL),
(69, '25', '25', '25101', '25', 'SECRETARIA MUNICIPAL DE SAÚDE', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(45) NOT NULL COMMENT 'Action dos módulos',
  `resource_id` int(10) unsigned NOT NULL COMMENT 'ID do controller/módulo',
  `n_amigavel` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

--
-- Extraindo dados da tabela `permission`
--

INSERT INTO `permission` (`id`, `permission_name`, `resource_id`, `n_amigavel`) VALUES
(81, 'get-agenda', 4, 'Lista Agenda'),
(82, 'get-ligacoes', 4, 'Lista Ligações'),
(83, 'index', 4, 'Index'),
(84, 'home', 4, 'Home'),
(85, 'get-agenda', 5, 'Get Json'),
(86, 'list-agenda', 5, 'Lista Agenda'),
(87, 'addedit-agenda', 5, 'Crud Agenda'),
(88, 'index', 5, 'Agenda'),
(89, 'get-contatos', 6, 'Get Contatos'),
(90, 'listacontatos', 6, 'Lista Contatos'),
(91, 'add', 6, 'Cadastro'),
(92, 'edit', 6, 'Editar'),
(93, 'del', 6, 'Excluir'),
(94, 'index', 6, 'Principal'),
(95, 'index', 7, 'Principal'),
(96, 'get-grupos', 7, 'get Grupos'),
(97, 'get-modulos', 7, 'Get Modulos'),
(98, 'grupos', 7, 'Grupos'),
(99, 'grupo-add', 7, 'Adicionar Grupo'),
(100, 'grupo-edit', 7, 'Editar Grupo'),
(101, 'grupo-del', 7, 'Excluir Grupo'),
(102, 'modulos', 7, 'Modulos'),
(103, 'modulo-add', 7, 'Adicionar Modulo'),
(104, 'modulo-edit', 7, 'Editar Modulo'),
(105, 'modulo-del', 7, 'Excluir Modulo'),
(109, 'get-ligacoes', 8, 'Get Ligacoes'),
(110, 'listaligacoes', 8, 'Lista Ligações'),
(111, 'add', 8, 'Adicionar Ligação'),
(112, 'edit', 8, 'Editar Ligação'),
(113, 'del', 8, 'Excluir Ligação'),
(114, 'anotacoes', 8, 'Anotações'),
(115, 'view', 8, 'Detalhes'),
(116, 'index', 8, 'Principal'),
(127, 'index', 9, 'Principal'),
(128, 'change-password', 9, 'Alterar Senha'),
(129, 'forgot-password', 9, 'Recuperar Senha'),
(130, 'reset-password', 9, 'Resetar Senha'),
(131, 'password-reset-confirmation', 9, 'Confirmação de Reset'),
(132, 'logout', 9, 'Sair'),
(133, 'usuarios', 9, 'Principal'),
(134, 'user-add', 9, 'Adicionar Usuário'),
(135, 'user-edit', 9, 'Editar Usuário'),
(136, 'user-del', 9, 'Excluir Usuário'),
(137, 'home', 9, 'Principal'),
(138, 'users', 9, 'Users'),
(139, 'user', 9, 'User');

-- --------------------------------------------------------

--
-- Estrutura da tabela `resource`
--

CREATE TABLE IF NOT EXISTS `resource` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(50) NOT NULL COMMENT 'Controller do módulo',
  `n_amigavel` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `resource`
--

INSERT INTO `resource` (`id`, `resource_name`, `n_amigavel`) VALUES
(4, 'Home\\Controller\\Index', 'Home Page'),
(5, 'Agenda\\Controller\\Index', 'Agenda'),
(6, 'Contatos\\Controller\\Index', 'Contatos'),
(7, 'Grupos\\Controller\\Index', 'Grupos'),
(8, 'Ligacoes\\Controller\\Index', 'Ligações'),
(9, 'Users\\Controller\\User', 'Usuários');

-- --------------------------------------------------------

--
-- Estrutura da tabela `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(45) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `role`
--

INSERT INTO `role` (`rid`, `role_name`, `status`) VALUES
(1, 'Super Admin', 'Active'),
(2, 'teste', 'Active');

-- --------------------------------------------------------

--
-- Estrutura da tabela `role_permission`
--

CREATE TABLE IF NOT EXISTS `role_permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL COMMENT 'id grupo/papel',
  `permission_nome` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=272 ;

--
-- Extraindo dados da tabela `role_permission`
--

INSERT INTO `role_permission` (`id`, `role_id`, `permission_nome`) VALUES
(140, 2, 'get-agenda'),
(141, 2, 'get-ligacoes'),
(142, 2, 'index'),
(143, 2, 'home'),
(144, 2, 'get-agenda'),
(145, 2, 'list-agenda'),
(146, 2, 'addedit-agenda'),
(147, 2, 'index'),
(148, 2, 'get-contatos'),
(149, 2, 'listacontatos'),
(150, 2, 'add'),
(151, 2, 'edit'),
(152, 2, 'del'),
(153, 2, 'index'),
(154, 2, 'index'),
(155, 2, 'get-grupos'),
(156, 2, 'get-modulos'),
(157, 2, 'grupos'),
(158, 2, 'grupo-add'),
(159, 2, 'grupo-edit'),
(160, 2, 'grupo-del'),
(161, 2, 'modulos'),
(162, 2, 'modulo-add'),
(163, 2, 'modulo-edit'),
(164, 2, 'modulo-del'),
(165, 2, 'get-ligacoes'),
(166, 2, 'listaligacoes'),
(167, 2, 'add'),
(168, 2, 'edit'),
(169, 2, 'del'),
(170, 2, 'anotacoes'),
(171, 2, 'view'),
(172, 2, 'index'),
(173, 2, 'index'),
(174, 2, 'change-password'),
(175, 2, 'forgot-password'),
(176, 2, 'reset-password'),
(177, 2, 'password-reset-confirmation'),
(178, 2, 'logout'),
(179, 2, 'usuarios'),
(180, 2, 'user-add'),
(181, 2, 'user-edit'),
(182, 2, 'user-ddel'),
(226, 1, 'get-agenda'),
(227, 1, 'get-ligacoes'),
(228, 1, 'index'),
(229, 1, 'home'),
(230, 1, 'get-agenda'),
(231, 1, 'list-agenda'),
(232, 1, 'addedit-agenda'),
(233, 1, 'index'),
(234, 1, 'get-contatos'),
(235, 1, 'listacontatos'),
(236, 1, 'add'),
(237, 1, 'edit'),
(238, 1, 'del'),
(239, 1, 'index'),
(240, 1, 'index'),
(241, 1, 'get-grupos'),
(242, 1, 'get-modulos'),
(243, 1, 'grupos'),
(244, 1, 'grupo-add'),
(245, 1, 'grupo-edit'),
(246, 1, 'grupo-del'),
(247, 1, 'modulos'),
(248, 1, 'modulo-add'),
(249, 1, 'modulo-edit'),
(250, 1, 'modulo-del'),
(251, 1, 'get-ligacoes'),
(252, 1, 'listaligacoes'),
(253, 1, 'add'),
(254, 1, 'edit'),
(255, 1, 'del'),
(256, 1, 'anotacoes'),
(257, 1, 'view'),
(258, 1, 'index'),
(259, 1, 'index'),
(260, 1, 'change-password'),
(261, 1, 'forgot-password'),
(262, 1, 'reset-password'),
(263, 1, 'password-reset-confirmation'),
(264, 1, 'logout'),
(265, 1, 'usuarios'),
(266, 1, 'user-add'),
(267, 1, 'user-edit'),
(268, 1, 'user-del'),
(269, 1, 'home'),
(270, 1, 'users'),
(271, 1, 'user');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(101) NOT NULL,
  `password` varchar(45) NOT NULL,
  `login_attempts` int(11) NOT NULL DEFAULT '0',
  `login_attempt_time` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `orgaos` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `last_signed_in` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `login_attempts`, `login_attempt_time`, `first_name`, `last_name`, `orgaos`, `status`, `last_signed_in`) VALUES
(1, 'mscriacoes@gmail.com', 'd7d833534a39afbac08ec536bed7ae9eeac45638', 0, 0, 'Marcio', 'Seabra', '01101,01901', 'Active', '2014-08-29 13:38:48');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT 'ID usuario',
  `role_id` int(10) unsigned NOT NULL COMMENT 'ID regra/grupo/tipo',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `user_role`
--

INSERT INTO `user_role` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
