-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jan-2015 às 19:58
-- Versão do servidor: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sisdma`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

CREATE TABLE IF NOT EXISTS `agenda` (
`id_agenda` int(9) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `text` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `convidados` text NOT NULL,
  `event_location` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Extraindo dados da tabela `agenda`
--

INSERT INTO `agenda` (`id_agenda`, `start_date`, `end_date`, `text`, `details`, `convidados`, `event_location`) VALUES
(8, '2014-12-22 01:10:00', '2014-12-22 01:45:00', 'De novo', 'Descrição novo', '174,9,11,13,14', 'Rua São José, nº 01, Centro - Fortaleza-CE'),
(10, '2015-01-06 02:30:00', '2015-01-06 03:05:00', 'Evento de Janeiro', 'Descrição do Evento', '174,173,160', 'Rua São José, nº 01, Centro - Fortaleza-CE');

-- --------------------------------------------------------

--
-- Estrutura da tabela `arquivos`
--

CREATE TABLE IF NOT EXISTS `arquivos` (
`id_arquivo` int(11) NOT NULL,
  `id_comunicacao_log` int(11) DEFAULT NULL,
  `path_arquivo` varchar(255) DEFAULT NULL,
  `descricao_arquivo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comunicacoes`
--

CREATE TABLE IF NOT EXISTS `comunicacoes` (
`id_comunicacao` int(11) NOT NULL,
  `id_projeto` int(11) DEFAULT NULL,
  `id_etapa` int(11) DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  `tipo_comunicacao` int(11) DEFAULT NULL,
  `id_contato_rem` varchar(255) DEFAULT NULL,
  `id_contato_dest` varchar(255) DEFAULT NULL,
  `descricao` longtext,
  `status` enum('Realizado','Remarcado','Pendente','Cancelado') DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `comunicacoes`
--

INSERT INTO `comunicacoes` (`id_comunicacao`, `id_projeto`, `id_etapa`, `data`, `tipo_comunicacao`, `id_contato_rem`, `id_contato_dest`, `descricao`, `status`) VALUES
(13, 3, 0, '2014-12-26 17:00:36', 1, '174', '7,13', 'Editado', 'Realizado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `comunicacoes_log`
--

CREATE TABLE IF NOT EXISTS `comunicacoes_log` (
`id_log` int(11) NOT NULL,
  `id_comunicacao` int(11) DEFAULT NULL,
  `data_log` datetime DEFAULT NULL,
  `duracao` varchar(45) DEFAULT NULL,
  `nota` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos`
--

CREATE TABLE IF NOT EXISTS `contatos` (
`idcontatos` int(11) NOT NULL,
  `nomecontatos` varchar(255) NOT NULL,
  `siglacontatos` varchar(255) DEFAULT NULL,
  `orgaocontatos` varchar(255) DEFAULT NULL,
  `enderecoorgao` varchar(255) DEFAULT NULL,
  `telefone` varchar(255) DEFAULT NULL,
  `ramalfone` varchar(255) DEFAULT NULL,
  `emailcontato` varchar(255) DEFAULT NULL,
  `emailsec` varchar(255) NOT NULL,
  `celcontato` varchar(255) DEFAULT NULL,
  `cargocontato` varchar(255) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Tabela de Contatos	' AUTO_INCREMENT=469 ;

--
-- Extraindo dados da tabela `contatos`
--

INSERT INTO `contatos` (`idcontatos`, `nomecontatos`, `siglacontatos`, `orgaocontatos`, `enderecoorgao`, `telefone`, `ramalfone`, `emailcontato`, `emailsec`, `celcontato`, `cargocontato`) VALUES
(1, 'Fabricio Mendes', '----', 'Projeto Pirambu Digital', '----', '(85)3236-0541', '----', 'fabricio.mendes.ti@gmail.com', '', '(85)9981-7163', 'Presidente'),
(2, 'Ronaldo Ramos', '----', 'Craff Tecnologia', '----', '----', '----', 'ronaldo.ramos@gmail.com', '', '(85) 8821-5525', '-'),
(3, 'Alexandre Neto ', '-----', '----', '----', '----', '----', '----', '', '----', '----'),
(4, 'Annia Saboya ', '-----', '----', '----', '(85)3105-1356', '----', 'annia.saboya@fortaleza.ce.gov.br', '', '(85)8970-4549', '----'),
(5, 'Chico Mauro', '-----', 'Craff Tecnologia', '----', '----', '----', 'chmauro@fortalnet.com.br', '', '(85)99840577', '----'),
(6, 'Ayrton', '-----', '-----', '-----', '-----', '----', 'ayrton@nucleo.infor.com.br', '', '----', '----'),
(7, 'Dr. Francisco Carlos Moraes (Chiquinho)', '-----', '-----', '-----', '(085)3466-4880', '4881', '----', '', '----', '-'),
(8, 'Eduardo Fontenele', '-----', '-----', '-----', '(85) 3452 4562', '----', 'eduardo.fontenele@fortaleza.ce.gov.br', '', '(85)8895 5682', 'Assessor '),
(9, 'Fatima Aragão', '-----', '-----', '-----', '-', '----', 'fatima.aragao@fortaleza.ce.gov.br', '', '----', '----'),
(10, 'Reubem Azevedo Damasceno Gabriel', '-----', 'Gabinete do Vice-Prefeito', '-----', '(85) 3452-4659', '----', 'reubem.azevedo@fortaleza.ce.gov.br', '', '----', 'Coordenador técnico Financeiro'),
(11, 'Socorro Aranha/Cleneide', '-----', '-----', '-----', '(085)3105-1446', '(085)3105-1447', '----', '', '----', 'Assessoras'),
(12, 'Livia Regueira', '-----', '-----', '-----', '(85) 3105-1378', '-----', '-----', '', '-----', '-'),
(13, 'Ednelda', '-----', 'Escola Papa João XXIII', 'Rua 13 de Abril, 595 - Vila União', '(85) 3131-7712', '----', '-', '', '----', 'Diretora'),
(14, 'Margarete', '-----', 'Escola Papa João XXIII', 'Rua 13 de Abril, 595 - Vila União', '(85) 3131-7712', '----', '----', '', '----', 'Secretaria'),
(15, 'Cristiane Mourão Carvalhedo', '-----', 'UAPS CLODOALDO PINTO', 'Rua Banward Bezerra, nº 100 - Padre Andrade', '----', '----', 'crismcarvalhedo@hotmail.com', '', '(85)9991-9718', 'Gestor do posto de saúde'),
(16, 'Juliana Noronha', '-----', 'UAPS WALDO PESSOA - SER VI', 'RUA CAPITAO HUGO BEZERRA – BARROSO', '----', '----', 'julianacnmedeiros@hotmail.com', '', '(85)8730-2148', 'Gestor do posto de saúde'),
(17, 'Carlos Eduardo de Sousa Praxedes', '-----', 'UAPS MESSEJANA - SER VI', 'Rua Coronel Guilherme Alencar, s/ nº – Messejana', '-', '-', 'cpraxedes@sms.fortaleza.ce.gov.br/sousa praxedes@ig.com.br', '', '(85)9197-3602', 'Gestor do posto de saúde'),
(18, 'Carla Eduvia Viana Vasconcelos', '-----', 'Posto de Saúde Anísio Teixeira', 'Rua Guarani, 355. Messejana. Fica próximo a BR 116', '-----', '----', 'carlaeduvia@gmail.com', '', ' (85) 88865132', 'Coordenadora'),
(19, 'Minuchy Mendes Carneiro Alves', '-----', 'UAPS HUMBERTO BEZERRA - SER III ', 'Rua Hugo Victor, 51 - Antonio Bezerra', '----', '----', 'minuchy.mendes@hotmail.com', '', '(85)9998-9893/ (85)8833-0682', 'Gestor do posto de saúde'),
(20, 'Draurio Pinho', '-----', '-----', 'Rua Pinto Madeira 535 Sl-29/30, Centro', '(085)3253 1546', '----', '----', '', '----', '----'),
(21, 'Maria Isabel Litwak Nascimento', '-----', 'UAPS ARGEU HERBSTER - SER V', 'Rua Coronel João Corrêia,728, Bom Jardim', '----', '----', 'isalit22@yahoo.com.br', '', '----', 'Gestor do posto de saúde'),
(22, 'Talita Melo', ' Assessoria Jurídica ', ' Assessoria Jurídica ', '-----', '----', '----', 'talita.melo@fortaleza.ce.gov.br', '', '----', 'secretaria '),
(23, 'Fabio Braga Nunes', 'ABACUS', 'Empresa de solftwer', 'Rua Osvaldo Cruz, 1614 – Sala 2', '----', '---', 'fabio@abacus.net.br', '', '(85) 9181-3223', '----'),
(24, 'Leon Gardeon', 'ABACUS', 'Empresa de solftwer', 'Rua Osvaldo Cruz, 1614 – Sala 2', '(085)3244-1531', '----', 'leongardel@gmail.com', '', '96935300', '----'),
(25, 'Homero Carls Silva', 'ACFORA', 'Autarquia de Regulação ,Fiscalização e Controle dos Serviços Públicos de Saneamento Ambiental', 'Av.Antonio Sales,1885- Sobre loja ', '(085)3433-2789', '----', 'maribarreirasoares@gmail.com', '', '----', 'Presidente'),
(26, 'Jorge Cunha', 'Alberflex', 'Alberflex', '----', '----', '----', '----', '', '(85) 9900-2688', '----'),
(27, 'andre lira', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3488-5733', '----', 'andre.lira@fortaleza.ce.gov.br', '', '----', '----'),
(28, 'André Lira', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(85) 3488-5737', '----', 'andre.lira@fortaleza.ce.gov.br', '', '----', 'Gestro de TI'),
(29, 'DR. ROMULO', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3488 3201 ', '/02', 'romulo.montezuma@fortaleza.ce.gov.br', '', '----', 'COORDENADOR '),
(30, 'Nazaré ', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3433-9717', '(085)3433-9734', '----', '', '----', '----'),
(31, 'Rosina ', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(85) 3488-5724 ', '----', 'gpa.amc@gmail.com', '', '----', 'Gerente de Planejamento e Análise'),
(32, 'Vitor Cosmo Ciasca Neto ', 'AMC', 'Autarquia Municipal de Trânsito', 'Av.Aguanambi,90- Centro ', '(085)3433-9734', '9732', 'vitor.ciasca@fortaleza.ce.gov.br', '', '----', 'Presidente '),
(33, 'André Garcia Xerez ', 'Assessor Juridico ', 'Assessor Juridico ', '-----', '085-3105-1367', '----', 'andre.xerez@fortaleza.ce.gov.br', '', '----', '----'),
(34, 'Evilene', 'ATENÇÃO BASICA', 'Atenção Básica  a familia ', 'Rua do Rosário ,283,2ºe 3º.Andar - Centro ', '(085)3452-6966', '----', '----', '', '----', '----'),
(35, 'Chico', 'Atlantico', 'Instituto atlântico', '---', '(85)3216-7967/3216-7976', '-', 'chicos@atlantico.com.br', '', '(85)9603-8001', '-'),
(36, 'Cilis', 'Atlantico', 'Instituto atlântico', '-', '(85)3276-7836', '-', 'cilis.benevides@gmail.com', '', '(85)8802-8529', '-'),
(37, 'Emanuela Jordânia', 'Atlantico', 'Instituto atlântico', '-', '(85)3276-7836', '----', 'emanuelajord@gmail.com / emanuela.costa@fortaleza.ce.gov.br', '', '(85) 8703-7831', 'Analista de Sistema'),
(38, 'Asier Ansorena', 'Banco Palmas', '-----', '-----', '(85) 3459-4848 ', '----', 'asier@bancopalmas.org.br', '', '(85) 8916-4876', '----'),
(39, 'Sol', 'Banco Palmas', '-----', '-----', '(85) 3459-4848 ', '----', '----', '', '(85) 8772-1419', '----'),
(40, 'Ayrton Saboia', 'BNB', '-', '-', '(85)3251-7177', '-', 'airtonjr@bnb.gov.br', '', '(85)8838-4420', '-'),
(41, 'Uchoa', 'CADIC', 'Cadic Brasil', ' Rua Marcos Macêdo, 1333 - Aldeota', '(85) 3268-3639', '----', 'uchoa@cadicbrasil.com.br', '', '----', '----'),
(42, 'Lucirene Araújo Maciel', 'CÉLULA DE JORNALISMO', 'Célula de Jornalismo ', 'Rua São José,01 - Centro ', '(085)3105-1441', '1446', 'lucirenemaciel@gmail.com', '', '----', 'Célula de Jornalismo'),
(43, 'Eduardo Martins da Silva', 'Central de Licitações', '----', '----', '----', '----', 'eduardo.martins@fortaleza.ce.gov.br/dumartinsm@yahoo.com.br', '', '(85)9206-3297', 'Assistente Técnico - pregoeiro'),
(44, 'Francisco Fábio Santiago', 'Central de Licitações', '----', '----', '(85)3105-1157', '----', 'fabio.santiago@fortaleza.ce.gov.br/santiago.fabio@hotmail.com', '', '(85)9175-3703', 'Assessor de Banco de Dados'),
(45, 'Camila Freitas', 'Central de Licitações', '----', '----', '(85)3452-3474', '----', 'camilahollanda@hotmail.com.br', '', '(85)9749-0401', 'Assessor Técnico'),
(46, 'Benedita Lino', 'Central de Licitações', '----', '----', '(85)3105-1157', '----', 'licita.comprafortaleza@hotmail.com', '', '(85)3105-1157', '-'),
(47, 'Samuel Alexandre', 'Central de Licitações', '----', '----', '(85)3452-3474', '----', 'samuelallexandre@hotmail.com', '', '(85)9932-3876', 'Assistente Pregoeiro'),
(48, 'Fernanda Fernandes', 'CEPPJ', 'COORDENADORIA ESPECIAL DE POLÍTICAS PÚBLICAS PARA JUVENTUDE', 'Av. Luciano Carneiro, 2235 – Vila União', '(85) 3452-4657', '----', 'fernanda.fernandes@fortaleza.ce.gov.br / fernandaassisfernandes@hotmail.com', '', '(85) 8868-7070', 'Assessora Jurídica'),
(49, 'Dora - Secretaria', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '(85) 3452-6181', '----', 'dora.bessa@fortaleza.ce.gov.br', '', '89704864', '----'),
(50, 'Professor Vasco', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '(85) 3452-6181', '----', 'furtado.vasco@fortaleza.ce.gov.br/furtado.vasco@gmail.com', '', '99978951', '----'),
(51, 'Tarcisio Pequeno ', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '(85) 3452-6181', '----', 'tarcisiopequeno@gmail.com', '', '----', 'Coordenador '),
(52, 'Professora Wládia', 'CITINOVA', 'Coordenadoria de Ciência ,Tecnologia e Inovação ', 'Av.Aguanambi,1770- Fátima (SDE)', '-', '-', '-', '', '(85) 9994-5287', '-'),
(53, 'Erick Medrado', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3452-3472', '----', 'erick.medrado@fortaleza.ce.gov.br', '', '(085) 8898-5353', '----'),
(54, 'Haroldo Albuquerque Maranhão de Oliveira ', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'haroldo.maranhao@fortaleza.ce.gov.br', '', '(085)8970-3033', 'Coordenador geral'),
(55, 'Igor Leite', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3452-3430', '-', 'igor.leite@fortaleza.ce.gov.br', '', '(85)8970-6139', '-'),
(56, 'Hermes Lima De Oliveira', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'hermes.oliveira@fortaleza.ce.gov.br', '', '(085) 8970 4071/9996 3221', '-'),
(57, 'Jonas Cavalcanti Neto', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'jonascavalcantineto@gmail.com / jonas.neto@fortaleza.ce.gov.br', '', '(85) 8687-2577', 'Desenvolvedor'),
(58, 'Luiz Carlos A Maia', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3472', '----', 'luiz.maia@fortaleza.ce.gov.br', '', '(085) 97251730', '----'),
(59, 'Mikaely Greggio', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(85) 3452.3430', '----', 'mikaely.greggio@fortaleza.ce.gov.bR', '', '(85) 8970-3494', '----'),
(60, 'Bruno Tinoco', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3433-3430', '----', 'bruno.tinoco@fortaleza.ce.gov.br', '', '(85) 86303442', '----'),
(61, 'Verônica Aguiar', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(85) 3452-3430', '(85) 3452-3472', 'veronica.aguiar@fortaleza.ce.gov.br', '', '----', '----'),
(62, 'Italo Alencar', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '-', '-', 'italo.alencar@fortaleza.ce.gov.br', '', '(85) 8970-3726/(85) 8949-0845', '-'),
(63, 'Max Chagas', 'COGECT', 'Coordenadoria de Gestão Corporativa de Tecnologia', 'Rua do Rosário, 77 , Sobreloja - Centro - Fortaleza, CE', '(085)3452-3472', '----', 'maxlane.chagas@fortaleza.ce.gov.br', '', '-', '-'),
(64, 'Sullivan Estrela ', 'COGECT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '(085)3452 - 6773 / 6777', '----', 'sullivan.estrela@fortaleza.ce.gov.br', '', '(085)86072191/9813-2814', '----'),
(65, 'Sergio Gomes Cavalcante ', 'COID', 'Coordenadoria Especial do Idoso ', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3452-2344', '----', 'relacoespublicas@hotmail.com', '', '----', 'Coordenador'),
(66, 'Lucas Gurgel', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av. Luciano Carneiro, 2235 – Vila União                 ', '(085)3254-5376', '----', 'LUCAS.GURGEL@FORTALEZA.CE.GOV.BR', '', '(085)8819-1153', '----'),
(67, 'Marina Guedes', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av. Luciano Carneiro, 2235 – Vila União                 ', '(085)3452-5376', '----', 'MARINABUA@GMAIL.COM', '', '(085)8965-4460', '----'),
(68, 'Fabiana', 'COORDENADORIA', 'Coord.especial Participação Popular ', 'Av. Luciano Carneiro, 2235 –Vila União', '-', '----', '----', '', '----', '----'),
(69, 'Jade Afonso Romero ', 'COORDENADORIA', 'Coordenadora da Coordenadoria Especial de Participação Popular', 'Av. Luciano Carneiro, 2235 –Vila União', '(085)3105-1569', '----', 'jaderomero@gmail.com/jade.romero@fortaleza.ce.gov.br/sabigsb@gmail.com', '', '----', '----'),
(70, 'José Élcio Batista ', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '(085)3452-2118', '----', 'elcioelcioelcio@gmail.com', '', '----', 'Coordenador'),
(71, 'Juliana Formiga ', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '----', '----', 'JULIANAFORMIGA@GMAIL.COM', '', '(085)8840-7777', '----'),
(72, 'Verônia', 'Coordenadoria', 'Coord.de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '----', '----', '----', '', '----', '----'),
(73, 'Camila Silveira', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas de Juventude ', 'Av.Luciano Carneiro,2235-vila União', '(85)3452-5373', '5371', 'camilasilveirace@gmail.com', '', '-', '-'),
(74, 'Larissa Maria Fernandes Gaspar Da Costa ', 'COORDENADORIA', 'Coordenadora de Politica Para as Mulheres', 'Rua  Pedro l, s/ n – Cidade da Criança - Centro ', '(085)3105-1398', '----', 'coordenadoriadamulherfor@yahoo.com.br', '', '----', '----'),
(75, 'Francisco Cristiano Ferrer', 'COORDENADORIA', 'Coordenadoria Municipal de Proteção e Defesa Civil', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-7132', '/6229', 'fc_ferrer@hotmail.com', '', '----', 'Coordenador Especial '),
(76, 'Julio Cals de Alencar', 'COORDENADORIA', 'Coordenadoria para Promoção da Cidadania e Direitos Humanos', 'Rua Pedro I,461-Cidade da Criança - Centro', '(085)3452-2364', '----', 'julio.cals@fortaleza.ce.gov.br', '', '----', 'Coordenador'),
(77, 'Andréa Rossati', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas para Diversidade Sexual', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3452-2349', '2345', 'andrearossati40@hotmail.com', '', '----', 'Coordenadora'),
(78, 'Larissa Maria Fernades Gaspar da Costa ', 'COORDENADORIA', 'Coordenadoria Especial de Políticas Públicas para as Mulheres', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1398', '----', 'coordenadoriamulherfor@yahoo.com.br', '', '----', 'Coordenadora '),
(79, 'João Batista Uchuôa ', 'COORDENADORIA', 'Coordenadoria de Publicidade e Marketing', 'Rua São José ,01- Centro', '(085)3105-1448', '3452-7299', 'joao.uchuoa@fortaleza.ce.gov.br', '', '----', 'Coordenador'),
(80, 'Norma Zélia Moreira Pinheiro de Andrade', 'COORDENADORIA', 'Coordenadoria de Ceremonial ', 'Rua São José ,01- centro Paço Municipal', '(085)3105-1364', '1365/1366', 'nzandrade@gmail.com', '', '----', 'Coordenadoria de Cerimonial'),
(81, 'Lúcio  Bruno', 'Coordenadoria', 'Coord.especial Articulação Política ', 'Rua São José ,01-Centro', '(085)3105-1371', '----', 'lucio.bruno@fortaleza.ce.gov.br', '', '----', '----'),
(82, 'Lúcio Alburquerque Bruno Figueiredo ', 'COORDENADORIA', 'Coordenadoria Especial de Articulação Política', 'Rua São José ,01-Centro', '(085)3105-1371', '1013', 'lucio-bruno@ig.com.br', '', '----', 'Coordenador '),
(83, 'ED. Lúcio Oliveira ', 'COORDENADORIA', 'Coordenadoria de Eventos', 'Rua São José 01-Centro', '(085)3105-1447', '----', 'ed.lucio@fortaleza', '', '----', 'Coordenador '),
(84, 'Moacir Maia Dos Santos ', 'COORDENADORIA', 'Coordenadoria de Comunicação Social ', 'Rua São José 01-Centro', '(085)3105-1442', '1446', 'jornalistamoacirmaia@gmail.com', '', '----', 'Coordenador '),
(85, 'Hermann Hesse Feitosa Alexandrino', 'COORDENADORIA', 'Coordenadoria de Comunicação Institucional ', 'Rua São José.01 -Centro', '(085)3452-1655', '----', 'hermann.hesse@fortaleza.ce.gov.br ', '', '----', 'Coordenador '),
(86, 'José Elcio Batista ', 'COORDENADORIA ', 'Coordenadora Especial De Politicas Públicas De Juventude ', 'Av. Luciano Carneiro, 2235 – Vila União                 ', '(085) 3452-4657', '----', 'elcioelcioelcio@gmail.com', '', '085-8970-3031', '----'),
(87, 'Thauser ', 'COPEDEF ', 'Coordenadoria de Pessoas com Deficiência', '-----', '----', '----', '----', '', '(85)8808-1158', '----'),
(88, 'Francisco Thauzer Coelho Fonteles', 'COPEDEF ', 'Coordenadoria Especial da Pessoa com Deficiência ', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3252-3436', '----', 'prof.thauzer@gmail.com', '', '----', 'Coordenador'),
(89, 'Cristiano Lima ', 'COPPIR', 'Coordenadoria Especial de Políticas Públicas de Promoção de Igualdade Racial', 'Rua Pedro l s/n, Cidade da Criança', '(085)3452-7747', '-', ' josecoopir@fortaleza.ce.gov.br / coopir.scdh@fortaleza.ce.gov.br', '', '----', 'Coordenador Especial'),
(90, 'Ricardo (Ponto Web)', 'COTEC', 'Celula de tecnologia', 'Rua Julio Siqueira, 1101- Joaquim Távora', '----', '----', '----', '', '(85) 8794-1119', '----'),
(91, 'Rodolfo Sikora', 'COTEC', 'Celula de tecnologia', 'Rua Julio Siqueira, 1101- Joaquim Távora', '(85) 3433-3635', '-', 'rodolfo.sikora@fortaleza.ce.gov.br', '', '(085)8888-0103', '----'),
(92, 'Juliana Mara de Freitas Sena Mota', 'CPDROGAS', 'Coordenadoria de Políticas sobre drogas', 'Av.Luciano Carneiro ,99- Villa União ', '(085)3452-7296', '7283', 'mjulianasena@gmail.com', '', '----', 'Coordenadora'),
(93, 'Maria Lourdes dos Santos', 'CPDROGAS', 'Coordenadoria de Políticas sobre drogas', 'Av.Luciano Carneiro ,99- Villa União ', '(85) 3452-7296', '----', 'mlourdes7@yahoo.com.br', '', '----', 'Coordenadora do Núcleo de Pesquisa'),
(94, 'Raul ', 'CPDROGAS', 'Coordenadoria de Políticas sobre drogas', 'Av.Luciano Carneiro ,99- Villa União ', '----', '----', '----', '', '----', '----'),
(95, 'Cristiane', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3105-1150', '----', 'crislicitacaofortaleza@gmail.com', '', ' (85)8890 9945', '----'),
(96, 'Geovania  Machado ', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3252-1630', '3452-3477', 'geovania4@hotmail.com ', '', '----', '-'),
(97, 'Geovania Sabino Machado ', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3452-3477', '----', 'geovania4@hotmail.com', '', '----', 'Presidente'),
(98, 'Giovania', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3452 3477', '----', '----', '', '----', '----'),
(99, 'Vera Lucia', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(085)3452-3480', '----', 'vera.lucia@fortaleza.ce.gov.br', '', '----', '----'),
(100, 'Joias', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(85)3452-3473', '-', '---', '', '(85) 8657-4243', '-'),
(101, 'Vanusa', 'CPL', 'Comissão Permanente de Licitação', 'Rua do Rosário ,77- Centro ', '(85) 3452-3482', '-', '-', '', '-', '-'),
(102, 'Jade Afonso Romero ', 'CPP', 'Coordenadoria Especial de Participação Popular', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-6780', '----', 'jaderomero@gmail.com', '', '----', 'Coordenadora'),
(103, 'Rafaelle Reis ', 'CPP', 'Coordenadoria Especial de Participação Popular', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-6792', '----', 'RAFAELLEREIS@YAHOO.COM.BR', '', '(085)8818-5791', '----'),
(104, 'Carlos Alberto Alves de Sousa', 'CTC', 'Companhia de Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '(085)3433-9670', '----', 'c.alberto.alves@hotmail.com', '', '----', 'Presidente'),
(105, 'Carlos Alberto Alves de Sousa', 'CTC', ' Companhia De Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '(085)3433-9670', '----', 'c.alberto.alves@hotmail.com', '', '----', 'Presidente'),
(106, 'Carlos Alberto Alves De Sousa ', 'CTC', 'Companhia de Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '(085)3433-9670', '----', 'c.alberto.alves@hotmail.com/anicecampos@bol.com.br', '', '----', '----'),
(107, 'Nice ', 'CTC', 'Companhia de Transporte Coletivo ', 'Rua Desembargador Gonzaga,1630-Cidade dos Funcionarios', '----', '----', '----', '', '----', '----'),
(108, 'Sergio Henrique  Lima Miranda ', 'CTIS', 'Centro deTecnologia', '-----', '(085) 3047-5449', '----', 'sergio.miranda@ctis.com.br', '', '----', 'Representante Comercial '),
(109, 'Rafael Fonseca', 'CTIS IT Services', 'CTIS Tecnologia S.A', 'SCN Q. 04, BL. B, sala 204, 2º andar, Centro Empresarial Varig Brasilia-DF, Cep : 70714-900', '(61)3426-9406', '----', 'rafaelc@ctis.com.br', '', '(61)9276-8364', 'Diretor de Partner Solutions'),
(110, 'Fernanda', 'CUCA', '--------', '-------', '(85)3452-4658', '-', '------', '', '(85)8868-7070', 'Acessora Juridica.'),
(111, 'Filizolina De Souza ', 'DAF', 'Departamento Administrativo Financeiro', 'Rua São José ,01- centro', '(085)3105-1456', '----', 'filizolina.sousa@fortaleza.ce.gov.br', '', '----', '----'),
(112, 'Paulo Afonso Cavalcante Júnior ', 'DAF', 'Departamento Administrativo Financeiro', 'Rua São José ,01- centro', '(085)3105-1456', '1472', 'paulo.afonso@fortaleza.ce.gov.br', '', '----', 'Diretor   '),
(113, 'Valéria Borges', 'DAF', 'Departamento Administrativo Financeiro', 'Rua São José ,01- centro', '(085)3105-1472', '----', 'valeria.borges@fortaleza.ce.gov.br', '', '----', '----'),
(114, 'Cristiano Ferrer', 'DEFESA CIVIL', 'Coordenadoria Municipal de Proteção e Defesa Civil', 'Rua  Delmiro de Farias, 1900 – Rodolfo Teófilo', '(085)3281-7132', '6229', 'cristiano.ferrer@fortaleza.ce.gov.br', '', ' (085)8713 4300', 'Diretor'),
(115, 'EDIRAN', 'DIEESE', 'Departamento Intersindical de Estátisca e Estudos Socioeconômicos', '-----', '(085)32533962', '----', '----', '', '----', '----'),
(116, 'Sâmia Cristina de C. Fernandes', 'DIPRE', 'Divisão de Proteção ao Estudante', '-----', '----', '----', '----', '', '----', 'Chefe da divisão de Tecnologia da Informação'),
(117, 'Otavio Gondim', 'DNOCS', 'Departamento Nacional de Obras Contras a Secas', 'Av.Duque de Caxias,1700', '(085)3391-5103', '----', 'otavio.gondim@dnocs.gov.br', '', '----', '----'),
(118, 'José Ronaldo Rocha Nogueira ', 'EMLURB', 'Empresa Municipal de Limpeza Urbana', 'Rua Marechal Deodoro ,1501- Benfica', '(085)3131-7619', '7604', 'ronaldonogueirapmf@gmail.com', '', '----', 'Presidente '),
(119, 'Kelma/Vera ', 'EMLURB', 'Empresa Municipal de Limpeza Urbana', 'Rua Marechal Deodoro ,1501- Benfica', '----', '----', '----', '', '----', '----'),
(120, 'Osmar Jose do Nascimento', 'Epidemiologia/Dengue', '-', '-', '-', '-', '-', '', '-', '-'),
(121, 'Antonio Ferreira', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '(085)3452 9333', '----', '----', '', '----', 'Diretor  Técnico'),
(122, 'Antônio Ferreira', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '-----', '----', '----', '', '----', 'Diretor técnico'),
(123, 'Caroline Pinheiro ', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '(085)3452-9299', '3452-9322/9252', 'carolpinheiro84@hotmail.com', '', '----', '----'),
(124, 'Rogerio de Alencar Araripe Pinheiro', 'ETUFOR', 'Empresa de Transporte Urbano de Fortaleza ', 'Av.dos Expedicionários 5677-Vila União', '(085)3452-9322', '9252/9205', 'rogerio@etufor.ce.gov.br', '', '----', 'Presidente'),
(125, 'Adriana Furtado ', 'FMDS', '-------', '-', '(085)3433-3742', '3433-3748', '-', '', '-', '-'),
(126, 'Narcélio Giordanny Conrado Napolião', 'FUNCET', 'Fundação de Cultura ,Esporte e Turismo ', 'Rua meton Alencar ,1040- Casa 4- Centro', '(085)3105-1360', '----', 'giordanny.napolião@gmail.com', '', '----', 'Presidente'),
(127, 'Noemi ', 'FUNCET', 'Fundação de Cultura ,Esporte e Turismo ', 'Rua meton Alencar ,1040- Casa 4- Centro', '----', '----', 'Noemi.fonseca@fortaleza.ce.gov.br', '', '----', '----'),
(128, 'Francisco Arquimedes Rodrigues Pinheiro', 'FUNCI', 'Fundação da Criança e Familia Cidadã/Coordenadoria da Criança e do Adolescente', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1316', '----', 'arquimedespinheiro@hotmail.com', '', '----', 'Coordenador '),
(129, 'Luciene Araújo ', 'FUNCI', 'Fundação da Criança e Familia Cidadã/Coordenadoria da Criança e do Adolescente', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1316', '----', '----', '', '----', '----'),
(130, 'Tânia Gurgel', 'FUNCI', 'Fundação da Criança e Familia Cidadã/Coordenadoria da Criança e do Adolescente', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3105-1316', '----', 'tania.gurgel@fortaleza.ce.gov.br', '', '----', '----'),
(131, 'Carolina Cunha  Bezerra ', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1651', '2116/2112', 'carol.bezerra@fortaleza.ce.gov.br', '', '----', 'Primeira Dama do Municipio'),
(132, 'Célia/andreia/livia/débora', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1651', '3452-1656', 'celia.medeiros@fortaleza.ce.gov.br', '', '----', '----'),
(133, 'Cristiana Ferreira', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1651', '----', 'silva_ferreira_cristiana@yahoo.com.br', '', '(085)8543-5484', '----'),
(134, 'Maria Letícia Mota Moreira', 'GABINETE DA 1 º DAMA ', 'Gabinete da 1º Dama  ', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-7276', '----', 'leticiamm4@gmail.com', '', '(85) 8768-8997', '----'),
(135, 'Gilmar', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', '-----', '----', '----', 'gilmar.soares@fortaleza.ce.gov.br', '', '(85) 8890-9944', 'Prefeito do Gabinete do Prefeito'),
(136, 'Edna Brasil/nágela', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1373', '(085)3105-1374', 'edna.brasil@fortaleza.ce.gov.b', '', '----', '----'),
(137, 'Eliane Leão', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1369', '(085)3105-1369', 'eliane.leao@fortaleza.ce.gov.br', '', '----', 'Assessora Do Chefe De Gabinete'),
(138, 'Glaucia Diogo ', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1369', '----', 'glaucia.diogo@fortaleza.ce.gov.br', '', '----', 'Assessora Do Chefe De Gabinete '),
(139, 'Anelize / Elizabete / Ueila / Uiara', 'GABINETE DO PREFEITO', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(85) 3105-1165', '-', '-', '', '-', '-'),
(140, 'Evanildo Nascimento (Pipoca)', 'GABINETE DO PREFEITO', 'Gabiente do Prefeito', 'Rua São josé ,01-Centro', '----', '-', 'evanildorpipoca@hotmail.com', '', '(85)8710-7196/(85)8863-4308/ (85)9764-9333', 'Supervisor Industrial'),
(141, 'Alfredo Lopes', 'GABINETE DO PREFEITO', 'Gabiente do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1169', '----', '----', '', '-', 'Assessor Técnico'),
(142, 'Danúsio Magalhães ', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1460', '----', '----', '', '----', '----'),
(143, 'Danúsio/sr Raimundo/sr.matos/cesar/francisco', 'GABINETE DO PREFEITO', 'Gabiente do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1460', '----', '----', '', '----', '----'),
(144, 'Diana Carvalho ', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1002', '----', 'diana.carvalho@fortaleza.ce.gov.br', '', '----', '----'),
(145, 'Elizabete/liduina /ana Lúcia Nádja/conceição/ricardo', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1366', '1365', '----', '', '----', '----'),
(146, 'Francisco José Queiroz Maia Filho', 'GABINETE DO PREFEITO', 'Chefia de Gabinete do Prefeito ', 'Rua São josé ,01-Centro', '(085)3105-1378', '----', 'queiroz.maia@fortaleza.ce.gov.br', '', '----', 'Secretário Chefe de Gabinete do Prefeito'),
(147, 'Francisco José Queiroz Maia Filho', 'GABINETE DO PREFEITO', 'Gabinete do Prefeito', 'Rua São josé ,01-Centro', '(085)3105-1378', '1167', 'QUEIROZ.MAIA@FORTALEZA.CE.GOV.BR/QUEIROZMAIA@HOTMAIL.COM.COM.BR', '', '----', '----'),
(148, 'Ivanilda/neuza/fátima/fred/colombo ', 'GABINETE DO PREFEITO', 'Redação - Gabinete do prefeito', 'Rua São josé ,01-Centro', '(085)3452-6798', '----', '----', '', '----', '----'),
(149, 'Manuela /Ariane/Carla', 'Gabinete do prefeito', 'GABINETE DO PREFEITO', 'Rua São José ,01-Centro', '----', '----', '----', '', '----', 'Secretarias Do Prefeito '),
(150, 'Roberto Claúdio Rodrigues Bezerra', 'GABINETE DO PREFEITO', 'Gabinete  do Prefeito ', 'Rua São josé ,01-Centro', '(085)3105-1099', '----', 'robertoclaudio@gabpref.fortaleza.ce.gov.br', '', '----', 'Prefeito Municipal'),
(151, 'Capitão Bastos/Major Sousa', 'Gabinete do Prefeito ', 'Seguranças Do Prefeito', 'Rua São José ,01- centro', '(085)3105-1461', '----', 'laudelio.bastos@fortaleza.ce.gov.br', '', '----', '----'),
(152, 'Gerardo ', 'Gabinete do Prefeito ', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '----', '----', 'gerardo.junior@fortaleza.ce.gov.br', '', '(85) 8888-2601', 'Gerente de TI'),
(153, 'Mazim', 'Gabinete Prefeito ', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3105-1022', '----', '----', '', '----', 'Assessor Do Prefeito '),
(154, 'Holanda', 'GB', 'Gabinete do Prefeito', 'Rua São José,01 - Centro ', '(85) 3105-1165', '-', '-', '', '(85) 8788-1927', 'Chefe de Segurança'),
(155, 'Ana Leticia ', 'GMF', 'Guarda Municipal de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085) 3281-1672', '3281-9937', '----', '', '----', '----'),
(156, 'Antonio Azevedo Vieira Filho', 'GMF', 'Guarda Municipal  de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-8804', '8151', 'gabinete.sesec@gmail.com', '', '----', 'Diretor geral da Guarda Municipal e Sec. Executivo'),
(157, 'Inspetor Adson', 'GMF', 'Guarda Municipal  de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '-', '----', '-', '', '(85) 8867-9277', 'Coordenador de Tecnologia'),
(158, 'Inspetora Arilza', 'GMF', 'Guarda Municipal  de Fortaleza', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '-', '-', 'subinspetorarilza@yahoo.com.br', '', '(85) 8879-7623', '-'),
(159, 'Cibele/Juciana', 'HABITAFOR', 'fundação De Desenvolvimento Habitacional De Fortaleza ', 'Rua Nogueira Acioly,1400,1ºAndar - Centro', '(085)3488-3377', '(085) 3488-3376', 'juciana.ribeiro@fortaleza.ce.gov.br', '', '----', '----'),
(160, 'Francisca Eliana Gomes Dos Santos ', 'HABITAFOR', 'fundação De Desenvolvimento Habitacional De Fortaleza ', 'Rua Nogueira Acioly,1400,1ºAndar - Centro', '(085)3488-3377', '----', 'presidenciahabitafor@fortaleza.ce.gov.br/belecoelho@gmail.com', '', '----', '----'),
(161, 'Anaxágoras Girão ', 'IFCE', 'Instituto Federal de educação ,ciênciae e tecnologia do ceará', 'Avenida Treze de Maio, 2081 - Benfica, Fortaleza - CE', '(085) 3105 1355', '----', 'anaxa2006@gmail.com', '', '(085)8105-8070', '----'),
(162, 'Rodrigo Carvalho Sousa Costa', 'IFCE', 'Instituto Federal do Ceará', 'Avenida Treze de Maio, 2081 - Benfica, Fortaleza - CE', '(085)3455-9006', '----', 'rodccosta@gmail.com', '', '(085)81022854', '----'),
(163, 'Romulo Ferrer Lima Carneiroa', 'IFCE', 'Instituto Federal do Ceará', 'Avenida Treze de Maio, 2081 - Benfica, Fortaleza - CE', '(085) 3105 1355', '----', 'romulo.ferrer@gmail.com', '', '(085) 99703890 / 81627874', '----'),
(164, 'Anaxágoras', 'IFCE', 'Instituto Federal do Ceará', '-', '-', '----', 'anaxa2006@gmail.com', '', '(085)81508070', '----'),
(165, 'Ângela Deyse Jucá Oliveira', 'IJF', 'Instituto Dr.José Frota ', 'Rua Barão do Rio  Branco ,1816 - Centro', '(85) 3255-5180 / 3255-5081 ', '----', 'adeysejs@hotmail.com.br', '', '(85) 9996-4447', 'Gerente de TI'),
(166, 'Francisco Walter Frota de Paiva', 'IJF', 'Instituto Dr.José Frota ', 'Rua Barão do Rio  Branco ,1816 - Centro', '(085)3255-5205', '5206/3255', 'walterfrota@hotmail.com', '', '----', 'Superintendente'),
(167, 'Sergio Costa ', 'Imagem Segurança', '-----', '-----', '(085)32531546', '----', '----', '', '(85)8728 0863', '----'),
(168, 'André Ramos Silva', 'IMPARH', 'Instituto  Muncipal de Pesquisas e Administração e recursos humanos', 'Av. João Pessoa- 5609  Bairro Damas', '(085)3243-2960', '2961', 'ANDRE.SILVA8@GMAIL.COM.BR/VIRGINIAVJMARCIO@GMAIL.COM', '', '----', '----'),
(169, 'Virginia ', 'IMPARH', 'Instituto  Muncipal de Pesquisas e Administração e recursos humanos', 'Av. João Pessoa- 5609  Bairro Damas', '(085)3467-6704', '----', 'virginia.oliveira@fortaleza.ce.gov.br', '', '----', '----'),
(170, 'Robson Pessoa', 'Informática', '-----', '-----', '(61) 3426-9402', '----', 'robson.pessoa@ctis.com.br', '', '(61) 8406-8667', '----'),
(171, 'Romero Antunes', 'Informática', 'Solution Architect', 'SBS Quadra 02 - Bloco E - Sala 206, Ed. Prime Business Convenience, 70070-120 Brasilia, DF.', '(61)3041-9599', '----', 'rantunes@informatica.com', '', '(61)9929-9701', '----'),
(172, 'Jaime Araujo', 'Intelletto', 'Intelletto Soluções', 'SHN Quadra 2 Bloco F Sala 1004 Brasília, DF 70702-906 Brasil', '----', '----', 'jaime@intelletto.com.br', '', '(61)99435472 / (61)9233.5472 / 82036161 ', '----'),
(173, 'Berger', 'IPCE', '------', '-', '(85)3101-3512', '-', '-', '', '-', '-'),
(174, 'Roberta', 'IPCE', '--------', '-', '(85)3101-3521', '-', '-', '', '-', 'Secretária do Ataliba'),
(175, 'Eugenio Paceli', 'IPCE', '-------', '-', '(85)3101-3505', '-', '-', '', '-', '-'),
(176, 'Adriano Sarquis ', 'IPECE', 'Instituto de Pesquisa e Estratégia Econômica do Ceará', 'Cambeba, Fortaleza - CE', '(085)3105 3496', '-', '-', '', '-', 'Diretor'),
(177, 'Cleiber', 'IPECE', '-------', '-', '3101-3523', '3101 3518', 'cleyber.medeiros@ipece.ce.gov.br', '', '-', 'Analista Estatistico '),
(178, 'Arthur Kubernat', 'IPEM', 'Instituto de Pesquisa e Medidas', '-----', '(85)  3131-4003', '----', 'arthur.ipem@fortaleza.ce.gov.br / cti.ipem@fortaleza.ce.gov.br', '', '(85) 9624-4608', 'Gestor de TI'),
(179, 'Fernando Rossas Freire ', 'IPEM', 'Instituto de Pesos e Medidas', 'Av.Luciano Carneiro ,1320-Vila União', '(085)3256-7044', '2390', 'superintendencia.ipm@fortaleza.ce.gov.br', '', '----', 'Superintendente'),
(180, 'Marcia Sampaio ', 'IPEM', 'Instituto de Pesos e Medidas', 'Av.Luciano Carneiro ,1320-Vila União', '(085)3256-7044', '2390', ' marciacidrack@hotmail.com', '', '----', '----'),
(181, 'Professor Inácio Bessa', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José ,01- centro', '(85) 3253-2221', '----', 'bessainacio@gmail.com', '', '(85)9983-2400 / 8814-1229', '----'),
(182, 'Rodrigo Petry', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '32320645', 'rodrigors.petry@gmail.com', '', '(085)96278697', '----'),
(183, 'Alexandrino Diogenes', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '----', '----', 'alexandrino.diogenes@fortaleza.ce.gov.br', '', '----', '----'),
(184, 'Joacy Da Silva Leite', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'joacyleite@gmail.com', '', '(085)9998 9438', '----'),
(185, 'Jorge Washigton Laffitte', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'laffittejorge@gmail.com', '', '(085) 96353556', '----'),
(186, 'Luiz Santos', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'luiz.santos@fortaleza.ce.gov.br/siul.sant@gmail.com', '', '(085) 9621 7016', 'Gerente da Sala Situacional'),
(187, 'Marcos Mendes ', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '3105 1355', 'marcosmendes938@gmail.com', '', '(085) 88151976', '----'),
(188, 'Mariana', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '----', '----', '----', '', '(085)88113338', 'Assistente'),
(189, 'Sergio Horacio Lopes B De Menezes', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'sergio.menezes@fortaleza.com', '', '(085) 89704354', '----'),
(190, 'Vaninha Rocha ', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '----', '----', 'vaninha.rocha@fortaleza.ce.gov.br', '', '----', '----'),
(191, 'Volia Rocha', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1314', '----', 'VOLIA.ROCHA@FORTALEZA.CE.GOV.BR', '', '(085)9938-8369', '----'),
(192, 'Conceição Cidrakc', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1354', '----', 'conceicao.cidrack@fortaleza.ce.gov.br', '', '----', '----'),
(193, 'Eudoro Walter de Santana ', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1354', '----', 'eudorosantana@gmail.com', '', '----', 'Presidente '),
(194, 'Fabio Weydson', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1354', '----', ' fabioweydson@gmail.com', '', '(85) 9799-9991 / 9766-3119', '----'),
(195, 'Felipe Teles', 'IPLANFOR', 'Diretoria De Monitoramento E Avaliação', 'Rua São josé ,01-Centro- Paço Municipal', ' (085)3105-1355', '----', 'felipejteles@gmail.com', '', '(085) 9136-9382 / 8970-4618', '----'),
(196, 'Luiza Perdigão', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(85) 3105-1357', '----', 'luizaperdigao@gmail.com / luiza.perdigao@fortaleza.ce.gov.br', '', '(85) 8970-3818', '----'),
(197, 'Thais Abreu Magalhães', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São josé ,01-Centro- Paço Municipal', '(085)3105-1355', '----', 'thaisabreumagalhaes@gmail.com', '', '(85) 9748-7345', '----'),
(198, 'Marcio Seabra', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José,01 - Centro ', '(85) 3105-1355', '----', 'marcio.seabra@fortaleza.ce.gov.br', '', '(85) 9927-5721', 'Programador'),
(199, 'Raquel Honório', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José,01 - Centro ', '(85)3105-1355', '----', 'raquel.honorio@fortaleza.ce.gov.br / raquelshonorio@gmail.com', '', '(85) 87417219 / (85) 9901-9793', '----'),
(200, 'Tamile Solon', 'IPLANFOR', 'Instituto de Planejamento de Fortaleza ', 'Rua São José,01 - Centro ', '(085)3105-1354', '----', 'tamile.solon@fortaleza.ce.gov.br', '', '----', 'Assessora '),
(201, 'Rodrigo Pordeus', 'IPLANFOR', '-------', '-', '(085)3105-1354', '-', ' rodrigo.pordeus@fortaleza.ce.gov.br', '', '(85) 88057378 / (85) 89704619', '-'),
(202, 'Lia Parente', 'IPLANFOR', '--------', '-', '-', '-', 'lia.parente@fortaleza.ce.gov.br', '', '(85)8897-0581', '-'),
(203, 'IPLANFOR - Anexo', 'IPLANFOR - Anexo', 'Instituto de Planejamento de Fortaleza - Anexo', ' Rua 25 de Março, nº 268 – Centro', '(85) 3105-1285', '----', '----', '', '----', '----'),
(204, 'Aline', 'IPM', 'Instituto de Previdência do Município ', 'Rua Major Facundo ,1361- Centro', '(085)3105-1393', '3252-1797/1776', 'aline@ipmfor.ce.gov.br', '', '----', '----'),
(205, 'Fernando Rossas Freire ', 'IPM', 'Instituto de Previdência do Município ', 'Rua Major Facundo ,1361- Centro', '(085)3256-7044', '2390', 'superintendencia.ipem@fortaleza.ce.gov.br', '', '----', '----'),
(206, 'José Barbosa Porto ', 'IPM', 'Instituto de Previdência do Município ', 'Rua Major Facundo ,1361- Centro', '(085)3252-1797', '1776', 'dr.porto@ipmfor.ce.gov.br', '', '----', 'Superintendente'),
(207, 'André', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '-----', '-----', '-----', '', '(85)8619-0958 (85)9939-6881', 'Suport Tecnico'),
(208, 'Camila ', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '-----', '----', '----', '', '(85) 8970-7740 / 8970-7780', '----'),
(209, 'Cristiane', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '----', '----', 'cristianneamoris@gmail.com', '', '(85) 8970-4074 / 8680-5901', '----'),
(210, 'Help Desk (ISGH)', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '(85) 3195-2727', '-', '----', '', '----', '-'),
(211, 'Humberto', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '----', '----', '----', '', '(85) 8970-1892', '----'),
(212, 'Sergio Oliveira', 'ISGH', 'Instituto de Saúde e Gestão Hospitalar', 'Rua Socorro Gomes, 190 - Guajiru, CE', '----', '----', 'sergiooliveira@isgh.org.br', '', '(85) 8628-6016', '----'),
(213, 'Edgy Paiva', 'IVIA', '-----', 'Av. Washington 909, loja 97 - Shopping Salinas', '(85) 3305-4747 / 3305-4749', '----', 'edgy.paiva@ivia.com.br', '', '(85) 9982-3893', '----'),
(214, 'Camila ', 'JURIDICO', '-----', '-----', '(085)3105 1247', '----', '----', '', '----', '----'),
(215, 'Paulo Carvalho', 'KONPAX', 'KONPAX do Brasil', 'Rua Tibúrcio Cavalcante, 1573 – Aldeota ', '(85)4009-5293', '-', 'paulo@konpax.com', '', '(85) 8122-1100', 'Diretor Executivo'),
(216, 'Cristiane Eleutério Carvalho Deusdara', 'MAPFOR-SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3749', '----', 'cristiane.deusdara@fortaleza.ce.gov.br ', '', '(85)89703492', '----'),
(217, 'Augusto Martelo', 'N5Tecnologia', 'N5Tecnologia', '-', '-', '-', 'augusto@n5tecnologia.com.br', '', '(85) 8675-0182', 'Assistente Técnico'),
(218, 'Paulo Elan', 'Núcleo Imagem', 'Núcleo Imagem', 'Rua Barão de Aratanha, 1300 - Fátima', '(085)3455-2702', '2700', 'elan@nucleoinfo.com.br', '', '(085)88020175', 'Gerente de Negócios'),
(219, 'Pedro Monteiro', 'Núcleo Imagem', 'Núcleo Imagem', '-', '(85)3455-2716', '-', 'monteiro@nucleoinfo.com.br', '', '(85) 8804-0876', 'Supervisor de Pré venda'),
(220, 'Ribeiro', 'Núcleo Informatica', '------', '-', '-', '-', '-', '', '(85)8906-5957/(85)99504273', '-'),
(221, 'Liliane Da Silveira Araújo ', 'OGM', 'Ouvidoria Geral  do Municipio', 'Rua Meton de Alencar ,1791- Centro', '(085)3105-1501', '----', 'lilianemptceara@hotmail.com', '', '----', 'Ouvidoria Geral'),
(222, 'Gonsalves', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '----', '----', '----', '', '(85) 8664-9574 / 9993-0222', '----'),
(223, 'Pedro Alcantra', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '(85) 3226-9818', '----', 'pedro@omegagrupo.com.br', '', '(85) 8820-9278 / (19) 99766-2513', 'Coordenador'),
(224, 'Valdenor ', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '(85) 3226-9818', '----', 'valdenor@omegagrupo.com.br', '', '(19) 96192051 / (85) 9669 7302', '----'),
(225, 'Valmir Ferreira', 'OMEGA ', 'Omega Construções', 'Rua João Cordeiro, 2459 - Aldeota, Fortaleza - CE', '(19) 3246-0100', '----', 'valmir@omegagrupo.com.br', '', '(19) 99604-8446', '----'),
(226, 'Claudia Regina', 'OMEGA ', '-------', '-', '(85)3246-0100', '----', 'claudia.rh@omegagrup.com.br', '', '-', '-'),
(227, 'Eliete ', 'PGM', 'Procuradoria Geral do Municipio', 'Av.Santos Dumont,5335,11ºAndar -Aldeota', '(085)3234-5422', '-', 'eliete.castro@fortaleza.ce.gov.br', '', '----', '----'),
(228, 'João Paulo', 'PGM', 'Procuradoria Geral do Municipio', 'Av.Santos Dumont,5335,11ºAndar -Aldeota', '(085)3265-2238', '----', '----', '', '----', '----'),
(229, 'José Leite Jucá Filho', 'PGM', 'Procuradoria Geral do Municipio', 'Av.Santos Dumont,5335,11ºAndar -Aldeota', '(085)3265-5114', '3265-5977', 'joseleite@gmail.com', '', '----', 'Procurador Geral '),
(230, 'José Leite Jucá Filho', 'PGM', 'Procuradoria Geral do Municipio', '-', '(085)3265-5114', '----', 'JOSELEITE@GMAIL.COM', '', '----', '-'),
(231, 'Claudia Freitas', 'PLANEJAMENTO SMS', '--------', '-', '(85)3452-6999', '-', 'cacaulima2@hotmail.com/acessoriaplanejamento@sms.fortaleza.ce.gov.br', '', '(85)8657-2291', 'Acessora de Planejamento'),
(232, 'Andre Ramos', 'PNAFM', 'PROGRAMA NACIONAL DE APOIO À MODERNIZAÇÃO ADMINISTRATIVA E FISCAL', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1237', '----', 'andre.ramos@sefin.fortaleza.ce.gov.br', '', '(085) 8843 2409', '----'),
(233, 'Marta Goes', 'PNAFM', 'PROGRAMA NACIONAL DE APOIO À MODERNIZAÇÃO ADMINISTRATIVA E FISCAL', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1237', '----', 'marta.goes@sefin.fortaleza.ce.gov.br', '', '-', '-'),
(234, 'Verônica', 'POP FOR', 'Pré-Vestibular Popular de Fortaleza', '-----', '(085)3452-7281', '----', '----', '', '----', '----'),
(235, 'Sônia Maria Pedrosa Cavalcante', 'PROCON', 'Coordenadoria Especialde Defesa do Consumidor - PROCON', '-----', '(85) 3452-2197 ', '----', 'spcavalcante@gmail.com', '', '(85) 9989-5091', 'Contadora'),
(236, 'George Lopes Valentim ', 'PROCON', 'Coordenadoria da Defesa do Consumidor ', 'Rua major Facundo ,869- centro', '(085)3105-1136', '1296', 'georgelopesvalentim@hotmail.com', '', '----', 'Coordenador geral'),
(237, 'Rejane Oliveira ', 'PROCON', 'Coordenadoria da Defesa do Consumidor ', 'Rua major Facundo ,869- centro', '(085)3105-1188', '3105-1296/1136', 'regioliveira.80@gmail.com', '', '----', '----'),
(238, 'Sara', 'Recepção Prefeito ', 'GABINETE DO PREFEITO', 'Rua São José ,01- centro', '(085)3452-1651', '----', '----', '', '----', '----'),
(239, 'Marcos Frota', 'RNP-UFC', 'GIGAFOR', '----', '(85)3287-4314', '----', '----', '', '----', '----'),
(240, 'IPLANFOR - Sala da Diretoria', 'Sala da Diretoria', 'Instituto de Planejamento de Fortaleza - Anexo', ' Rua 25 de Março, nº 268 – Centro', '(85)3488-9248/ (85)3105-1355', '----', '----', '', '----', '-'),
(241, 'Karlo Meireles Kardozo', 'SCDH', 'Secretaria Municipal de Cidadania  e Direitos Humanos ', 'Rua Pedro I,s/n -Cidade da Criança - Centro ', '(085)3452-2320', '----', 'karlo.kardozo@fortaleza.ce.gov.br', '', '----', 'Secretário'),
(242, 'Jaciane', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '(85) 3272-4861', '----', '----', '', '(85) 8519-1386/(85)8970-4079', 'Secretaria Luiz Saboia'),
(243, 'João de Aguiar Pupo', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '(085)3261-6268', '----', 'joao_pupo@hotmail.com', '', '----', 'Secretário'),
(244, 'Lena - Secretaria', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '(085)3452-7275', '3261-6268', 'jlenassa@hotmail.com  ', '', '----', '----'),
(245, 'Luis Alberto Sabóia', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '085) 3261-6268 ', '----', 'luiz.saboia@fortaleza.ce.gov.br', '', '(085)89704079', '----'),
(246, 'Rafael Sousa', 'SCSP', 'Secretaria Municipal de Conservação e Serviços Públicos ', 'Av.Pontes Vieira ,2391-Dionísio Torres ', '----', '----', 'rafael.sousa@fortaleza.ce.gov.br', '', '(085)88977182', '----'),
(247, 'Francisco Figueredo de Paula Pessoa Neto', 'SCSP', 'Secretaria de Conservação e Serviços Públicos', 'Rua São José,01 - Centro ', '----', '----', 'fcofigueredo@hotmail.com', '', '(85)9996-1805\n(85)8708-3004', 'Assessor Jurídico'),
(248, 'Sergio A. de Morais', 'SCSP', 'Secretaria de Conservação e Serviços Públicos', 'Rua São José,01 - Centro ', '(85)3452-7274', '----', 'sergio.moraes@fortaleza.ce.gov.br', '', '(85)8898-3494', 'Gerente Administrativo'),
(249, 'Ítalo Alves de Andrade', 'SCSP', 'Secretaria de Conservação e Serviços Públicos', 'Rua São José,01 - Centro ', '----', '----', 'italo.andrade@fortaleza.ce.gov.br', '', '(85)8970-2062\n(85)9992-7295', 'Coordenador Administrativo Financeiro'),
(250, 'Jó ', 'SDE', 'Secretaria Municipal de desenvolvimento Econômico ', 'Av.Aguanambi ,1770-Fátima', '(085 )3105-1519', '----', 'joyce.oliveira@fortaleza.ce.gov.br', '', '----', '----'),
(251, 'Marcelo Davi Santos', 'SDE', 'Secretaria Municipal de Desenvolvimento Econômico', 'Av.Aguanambi ,1770-Fátima', '(85) 3452-6239 ', '----', 'davi.santos@fortaleza.ce.gov.br', '', '(85) 8501-6618', 'Assessor de Desenvolvimento Econômico e Projeto'),
(252, 'Robinson Passos de Castro e Silva', 'SDE', 'Secretaria Municipal de desenvolvimento Econômico ', 'Av.Aguanambi ,1770-Fátima', '(085)3105-1573', '1574', 'robinson.castro@fortaleza.ce.gov.br', '', '----', 'Secretário '),
(253, 'Karlo Meireles Kardozo', 'SDH', 'Secretaria De Direitos Humanos de Fortaleza ', 'Pedro I,s/n centro Fortaleza ce', '(085) 3452-2320 ', '----', 'karlo.kardozo@fortaleza.ce.gov.br  ', '', '085-8970-2222', '----'),
(254, 'Edna Martins', 'SECEL', 'Secretaria Municipal de Esporte e Lazer de Fortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085)32545848', '----', 'edna.cleyane@fortaleza.ce.gov.br', '', '----', 'SECRETARIO/MARCIO LOPES');
INSERT INTO `contatos` (`idcontatos`, `nomecontatos`, `siglacontatos`, `orgaocontatos`, `enderecoorgao`, `telefone`, `ramalfone`, `emailcontato`, `emailsec`, `celcontato`, `cargocontato`) VALUES
(255, 'Marcio Eduardo de Lima Lopes ', 'SECEL', 'Secretaria Municipal de Esporte e Lazer deFortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085)3105-1309', '3254-5848', 'marcio.lopes@fortaleza.ce.gov.br', '', '----', 'Secretário'),
(256, 'Rosiane Sousa', 'SECEL', 'Secretaria Municipal de Esporte e Lazer deFortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085) 3105-1309      ', '----', 'rosiane.sousa@fortaleza.ce.gov.br', '', '(085)8898 9922', '----'),
(257, 'Sandra - Secretaria', 'SECEL', 'Secretaria Municipal de Esporte e Lazer deFortaleza', 'Rua lldefonso Albano,2050- Joaquim Távora (Ginásio Paulo Sarasate)', '(085)3105-1350', '3105-1309', 'sandra.marrocos@fortaleza.ce.gov.br', '', '----', '----'),
(258, 'Domingos Gomes de Aguiar Neto ', 'SECOPAFOR', 'Secretaria Municipal Extraordinária da Copa ', 'Rua Tibúrcio Cavalcante ,900-Aldeota ', '(085)3105-2721', '-', 'domingosaguiarneto@gmail.com', '', '----', 'Secretário '),
(259, 'Domingos Neto ', 'SECOPAFOR', 'Secretaria Municipal Extraordinária da Copa ', 'Rua Tibúrcio Cavalcante ,900-Aldeota ', '(085)3105-2710', '2711', 'domingosaguiarrneto@gmail.com', '', '085-9707-0033', '----'),
(260, 'Juliana  ', 'SECOT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '----', '----', '----', '', '(085)8814-8208', '----'),
(261, 'Marlon Carvalho Cambraia ', 'SECOT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '(085)3452-6776', '----', 'marlon.cambraia@fortaleza.ce.gov.br', '', '----', 'Secretário '),
(262, 'Wilfrido Tiradentes Da Rocha Neto', 'SECOT', 'Secretaria da Controladoria e Transparência ', 'Rua Meton de Alencar ,1791- Centro', '(085)34526768', '----', 'rocha.neto@fortaleza.ce.gov.br', '', '----', '----'),
(263, 'Jessica Cordeiro Lucas', 'SECOT', '----', '-', '(058)3452-6778', '-', 'jeissa.lucas@fortaleza.ce.gov.br', '', '(85)8970-6144', '-'),
(264, 'Francisco Geraldo de Magela Lima Filho', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1146', '----', 'secultfor.fortaleza@gmail.com', '', '----', 'Secretário'),
(265, 'Inácio Coelho', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1146             ', '----', 'inacio.coelho@fortaleza.ce.gov.br', '', '(085)8970 4530 / 9994 1963', '----'),
(266, 'Magela Lima', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1146', '----', 'secultfor.fortaleza@gmail.com ', '', '(085)-8970-2020', '----'),
(267, 'Silvana', 'SECULTFOR', 'Secretaria Municipal de Cultura de Fortaleza', 'Rua Pereira Filgueiras ,04- Centro ', '(085)3105-1294', '3105-1146', 'secultfor.fortaleza@gmail.com', '', '----', '----'),
(268, 'ABGELA', 'SEDUC', 'Secretaria de Educação do Estado', ' Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)31016710', '-', '----', '', '----', 'MAJOR'),
(269, 'Adriano Sousa', 'SEDUC', 'Secretaria de Educação do Estado', ' Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)3101-3969', '-', 'adrianos@seduc.ce.gov.br', '', '----', '-'),
(270, 'Giovani  Campelo', 'SEDUC', 'Secretaria de Educação do Estado', 'Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)3101-3963', '3969', 'giovani@seduc.ce.gov.br', '', '----', 'Gerente'),
(271, 'João Paulo Seduc', 'SEDUC', 'Secretaria de Educação do Estado', 'Av. Gal Afonso Albuquerque Lima, 1 - Cambeba, Fortaleza', '(085)3101-3969', '----', 'joao.paulo@seduc.ce.gov.br', '', '----', '----'),
(272, 'Carla Danure', 'SEFAZ', 'Secretaria da Fazenda', 'Av. Pessoa Anta, 274 - Centro', '(85) 3101-9071', '----', '----', '', '----', '----'),
(273, 'Tales Matos', 'SEFAZ', 'Secretaria da Fazenda', 'Av. Pessoa Anta, 274 - Centro', '(85) 3101-9420', '----', '----', '', '----', '----'),
(274, 'Eveline Campos', 'SEFIN', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85)3452-5773', '----', 'eveline.campos@sefin.fortaleza.ce.gov.br', '', '(85) 8757-5057', 'Gerente Técnico em BI'),
(275, 'Clovis', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3495', '----', '----', '', '----', '----'),
(276, 'Francisco Ricardo Ribeiro', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3495', '----', 'fcoricardovribeiro@hotmail.com/ricardo.ribeiro@sefin.fortaleza.ce.gov.br', '', '(85)9718-4400', '----'),
(277, 'Helcio', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1118', '----', 'helcio.nascimento@sefin.fortaleza.ce.gov.br', '', '(085)8888-8669', 'Geografo'),
(278, 'Heloisa Aragão', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'heloisa.aragao@sefin.fortaleza.ce.gov.br', '', '----', '-'),
(279, 'Jaime Cavalcante', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)31051241', '----', 'jaime.cavalcante@fortaleza.ce.gov.br', '', '----', '----'),
(280, 'José Jesus Lédio', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3477', '----', 'joseldealencar@yahoo.com.br', '', '(85)9133-9580', 'Pregoeiro'),
(281, 'Jurandir Gurgel Gondim Filho ', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085) 3105-1238 ', '/39', 'jurandir.gurgel@fortaleza.ce.gov.br ', '', '085-8970-2892', 'Secretaria'),
(282, 'Liane Carneiro', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3105-2041', '----', '----', '', '----', 'Setor de TI'),
(283, 'Mariangela Bezerra', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1263', '----', 'mariangela.bezerra@sefin.fortaleza.ce.gov.br', '', '----', '----'),
(284, 'Paulo Aguiar', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)3105-1263', '----', 'paulo.aguiar@sefin.fortaleza.ce.gov.br', '', '----', '----'),
(285, 'Camila ', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85)3105-1247', '---', '-', '', '-', '-'),
(286, 'Sara', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3105-1247', '----', 'sarah.correia@sefin.fortaleza.ce.gov.br', '', '----', '----'),
(287, 'Vanessa Simonassi', 'SEFIN', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3452-3495 / 3105-1240', '----', 'vanessa.simonassi@sefin.fortaleza.ce.gov.br', '', '(85) 9164-2994', '----'),
(288, 'Zuilto', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3105-1247', '----', '----', '', '----', '----'),
(289, 'Verônica Oliveira', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'veronica.oliveira@sefin.fortaleza.ce.gov.br', '', '(85)9954-0186\n(85)3105-1267', 'Gestora de Projetos'),
(290, ' Clóvis Soares', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'clovis.soares@sefin.fortaleza.ce.gov.br', '', '(85)3452-3495', 'Assessor de Planejamento'),
(291, 'Zuilton Mendonça', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '----', '----', 'zuilton.mendonca@sefin.fortaleza.ce.gov.br', '', '(85)9760-5069', 'Assessor Jurídico'),
(292, 'João Fernando Santa Cruz m. Neto', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85)3105-1233', '----', 'joao.fernando@sefim.fortaleza.ce.gov.br', '', '(85)9920-5555\n(85)8888-0076', 'Assessor Jurídico - COAF'),
(293, 'Eliane Montenegro', 'SEFIN', 'Secretaria de Finanças Do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(85) 3218-6523', '-', 'elianemtg@hotmail.com', '', '(85)9936-6587', '-'),
(294, 'Silvia Bezerra da Silva', 'SEFIN', 'Secretaria de Finanças', '-', '-', '-', 'c', '', '(85)9902-1532', '-'),
(295, 'Fco Ricardo Vieira Ribeiro', 'SEFIN', 'Secretaria de Finanças', '-', '(85)3452-3495', '-', 'ricardo.ribeiro@sefin.fortaleza.ce.gov.br', '', '(85)8879-9097', '-'),
(296, 'Paulo Martins', 'SEFIN ', 'Secretaria de Finanças do Municipio', 'Rua General Bezerril, 755 - Centro                                 ', '(085)31312100', '----', '----', '', '----', '----'),
(297, 'Ticiana Mota Sales', 'SEGOV', 'Secretaria de Governo', 'Rua São José ,01- centro', '----', '----', 'ticianamotas@gmail.com', '', ' (85)8970-6138 / 8671-4000', 'Acessora SEGOV'),
(298, 'Camile Mesquita ', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085)3105-1434', '----', 'camille.mesquita@fortaleza.ce.gov.br', '', '----', '----'),
(299, 'Crístian/laudélio', 'SEGOV', 'Secretaria Municipal de Governo', 'Rua São josé ,01-Centro', '(085)3105-1438', '1437', '-', '', '----', '----'),
(300, 'Laudélio Antônio De Oliveira Bastos ', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085) 3105-1434', '----', 'laudelio.bastos@fortaleza.ce.gov.br', '', '085-8970-3039', '----'),
(301, 'Prisco Rodrigues Bezerra ', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085)3105-1434', '-', 'priscobezerra@yahoo.com.br', '', '----', 'Secretário   '),
(302, 'Camille', 'SEGOV', 'Secretaria Municipal de Governo ', 'Rua São josé ,01-Centro', '(085)3105-1440', '3105-1434', 'camille.mesquita@fortaleza.ce.gov.br', '', '----', '----'),
(303, 'Breno Carvalho Coe', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)3105-1077', '----', 'breno.coe@fortaleza.ce.gov.br', '', '----', '----'),
(304, 'Eduardo Freitas', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85) 3105-1077 ', '----', 'eduardo.freitas@fortaleza.ce.gov.br', '', '(85) 8878-7781', 'Gestor de TI'),
(305, 'Elani ', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)31051080 ', '/ 1079', '----', '', '----', 'SECRETARIA DO GABINETE'),
(306, 'Gisele', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)3105-1082', '3105-1089', 'giselle.mafra@fortaleza.ce.gov.br', '', '----', '----'),
(307, 'Moacir Casemiro', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085) 3105 -1089     ', '----', 'moacir.casemiro@fortaleza.ce.gov.br', '', '(085)9679-6000', '----'),
(308, 'Moacir Casemiro', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085) 3105 -1089     ', '----', 'moacir.casemiro@fortaleza.ce.gov.br', '', '(085)9679-6000', '----'),
(309, 'Samuel Antônio Silva Dias ', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085) 3105 -1089     ', '----', 'samuel.dias@fortaleza.ce.gov.br', '', '(085)-8970-2956', '----'),
(310, 'Samuel Antônio Silva Dias ', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(085)3105-1079', '1080/1089', 'samuel.dias@fortaleza.ce.gov.br', '', '----', 'Secretário'),
(311, 'Thiago Mafra', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85)3105-1073', '-----', 'thiago.mafra@arcadislogos.com.br', '', '-----', '-----'),
(312, 'Fernanda Gabriela Maia', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '----', '----', 'gabriela.maia@fortaleza.ce.gov.br', '', '(85)9925-2332', '-'),
(313, 'Manuelito Cavalcante', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85)3105-1109', '----', 'manuelito.cavalcante@fortaleza.ce.gov.br', '', '(85)9994-1200', '-'),
(314, 'João Fernando Menescal', 'SEINF', 'Secretaria Municipal de Infraestrutura ', 'Av.Deputado Paulino Rocha ,1343-Cajazeiras ', '(85) 3452-5255', '-', 'joao.menescal@fortaleza.ce.gov.br', '', '(85) 8970-3804', 'Coordenador de Gerenciamento de Projetos'),
(315, 'Águeda Muniz ', 'SEMAM', 'Secretaria Meio Ambiente  e Controle Urbano', 'Av. Dep. Paulino Rocha, 1343  - Cajazeiras              ', '(085) 3452-6901 ', '/  6903                       ', 'agueda.muniz@fortaleza.ce.gov.br', '', '085-8970-2424', '-'),
(316, 'Claúdio Ricardo Gomes De Lima', 'SEMAS', 'Secretaria Municipal de Assistencia Social', 'Av. da Universidade, 3305, Benfica.', ' (085) 3105.3711', '----', '----', '', '085-8970-3032', '----'),
(317, 'Pedro José Alves Capibaribe', 'SEPLAN', 'Secretaria do planejamento e coordenação do Ceará', 'Av Gal Afonso Albuquerque Lima , 1 , Cambeba, Fortaleza  -  CE', '(085)3101-4457', '3101 4427', 'pedro.capibaribe@cidades/', '', '----', '-'),
(318, 'Ana Luiza /irenise ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3272-5053', '3433-3644', 'ana.luisa@fortaleza.ce.gov.br', '', '----', '----'),
(319, 'Ana Socorro Pereira Carvalho ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3779', '----', 'ANA.CARVALHO@FORTALEZA.CE.GOV.BR', '', '(085)8956-3779', '----'),
(320, 'Gaudino', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3433-3749', '-', '-', '', '-', '-'),
(321, 'Aparecida Façanha ( Paita)', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-4728', '1941', 'aparecida.facanha@fortaleza.ce.gov.br', '', '(085)8970 4060 / 8606-9677', '----'),
(322, 'Bene (Benedito)', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-4570', '----', '----', '', '----', '----'),
(323, 'Cleide', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-1941', '----', 'cleide.madeiro@fortaleza.ce.gov.br', '', '(085) 8754 9950', '----'),
(324, 'Cristiane Deusdará ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085) 3433-3644 ', '----', 'CRISTIANE.DEUSDARA@FORTALEZA.CE.GOV.BR', '', '----', '----'),
(325, 'Fatima Falcão', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)31014525', '----', '----', '', '----', '----'),
(326, 'Haroldo Maranhão ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085) 3433-3644 ', '----', 'haroldo.maranhao@fortaleza.ce.gov.br', '', '085-8970-3033', 'Coode.TI'),
(327, 'Isabel', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85) 3433-3653', '----', '----', '', '----', '----'),
(328, 'Isabela', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3433-3749', '----', '----', '', '----', '----'),
(329, 'João Paulo Neto ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)99560737', '----', 'paulo.neto@fortaleza.ce.gov.br', '', '----', '----'),
(330, 'Jorge Alberto C. Alcoforado', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-4570', '----', 'jorge.alcoforado@fortaleza.ce.gov.br/jalcoforado@gmail.com', '', '(085)88029144', '----'),
(331, 'Lucineide Alves da Silva', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85) 3252-4833 / 3101-2186', '----', 'lucineide.silva@fortaleza.ce.gov.br', '', '----', 'Assessora de Técnica da Assessoria de Planejamento e Desenvolvimento Institucional'),
(332, 'Lúcio Junior', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'lucio.junior@fortaleza.ce.gov.br / luciocimm@yahoo.com.br', '', '(85) 8614-0440', '-'),
(333, 'Miguel', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', '----', '', '(85) 8807-8003 / 9612-5917', 'Chefe Programadores'),
(334, 'Neuza  - Secretaria ', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3637', '----', '----', '', '----', '----'),
(335, 'Philipe Theophilo Notthingham', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(085)3433-3644', '3637', 'philipe@fortaleza.ce.gov.br', '', '----', 'Secretário '),
(336, 'Marcos Cavalcante', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'marcos.cavalcante@fortaleza.ce.gov.br', '', '(85)8868-9784', '-'),
(337, 'Maria Karoline Cavalcante', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'karolilne.cavalcante@fortaleza.ce.gov.br', '', '(85)8890-9943', 'Gerente'),
(338, 'Denise Fernandes', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '----', '----', 'denise.albuquerque@fortaleza.ce.gov.br', '', '(85)8678-8115', 'COGEC'),
(339, 'Desiree Mota', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3101-2186', '----', 'desiree.mota@fortaleza.ce.gov.br ', '', '(85)8563-3726\n \n', 'Assessora de desenvolv. Institucional'),
(340, 'Verene Barbosa', 'SEPOG', 'Secretaria Municipal de Planejamento ,Orçamento e Gestão ', 'Av.Desembargador Moreira ,2875-Aldeota ', '(85)3433-3656', '----', 'verene.barbosa@fortaleza.ce.gov.br', '', '(85)8899-8084', 'Gerente'),
(341, 'Aline Lopes Barbosa', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '(85)3433-3624', '-', 'aline.barbosa@fortaleza.ce.gov.br', '', '-', '-'),
(342, 'Martha Maria de Souza Barroso', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '(85)3433-36651', '-', 'marthasouzaa@hotmail.com', '', '(85)8850-2154', '-'),
(343, 'Sonja Trigueiroda Silveira Nunes', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '(85)3433-3670', '-', 'cleirtonnune@hotmail.com', '', '(85)8898-9747', '-'),
(344, 'Rudênia Noberto Maia', 'SEPOG', 'Secretaria De Planejamento Orçamento E Gestão', '-', '-', '-', 'ridenia.maia@fortaleza.ce.gov.br', '', '(85)8814-3430', '-'),
(345, 'Anúsia', 'SER', 'Secretaria Executiva da Regional III', ' Avenida Jovita Feitosa, 1264 - Parquelândia, Fortaleza - CE', '085-3433-2507', '----', 'anusia.holanda@fortaleza.ce.gov.br', '', '----', '----'),
(346, 'Maria De Fátima Vasconcelos Canuto ', 'SER', 'Secretaria Executiva da Regional III', ' Avenida Jovita Feitosa, 1264 - Parquelândia, Fortaleza - CE', '(085) 3433 -6883 ', '----', 'fatima.canuto@fortaleza.ce.gov.br', '', '085-8970-3024', '-'),
(347, 'Guilherme Teles Gouveia Neto ', 'SER', 'Secretaria executiva Regional I', ' Rua Dom Jeronomo, 20 - Otávio Bomfim, CE', '(085) 3433-6894 ', '6856', 'guilherme.gouveia@fortaleza.ce.gov.br', '', '085-8970-3025', '----'),
(348, 'Jéssica', 'SER', 'Secretaria Executiva da Regional VI', 'Av.Dedê Brasil,3770-Serrinha', '(085)3488-3104', '----', 'jessica.barbosa@fortaleza.ce.gov.br', '', '----', '----'),
(349, 'Julio Ramon Soares Oliveira ', 'SER ', 'Secretaria Executiva da Regional V', 'Av.Augusto dos Anjos,2466- Siqueira ', '(085)3433-2917', '2916/2919/7285', 'julio.ramon@fortaleza.ce.gov.br', '', '----', 'Secretário '),
(350, 'Francisco Airton Morais Mourão ', 'SER ', 'Secretaria Executiva da Regional  IV', 'Av.Dedê Brasil,3770-Serrinha', '(085) 3232-6021', '----', 'fan.morao@fort.ce.gov.br', '', '085-8970-3019', '----'),
(351, 'Francisco Airton Morais Mourão ', 'SER ', 'Secretaria Executiva da Regional IV', 'Av.Dedê Brasil,3770-Serrinha', '(085)3232-6021', '3433-2802', 'gabineteregional4@hotmail.com', '', '----', 'Secretário'),
(352, 'Maria de Fátima Vasconcelos Canuto', 'SER ', 'Secretaria Executiva da Regional III', 'Av.Jovita Feitosa ,1264-Parquelândia ', '(085)3433-6883', '----', 'fatimacanuto@yahoo.com.br', '', '----', 'Secretária '),
(353, 'Claúdia', 'SER ', 'Secretaria Executiva da Regional V', 'Avenida Augusto do Anjos, 2466 - Siqueira.', '(085)3433-2918', '3433-2916/2916/2919', 'Claudia_ribeiro@hotmail.com ', '', '----', '----'),
(354, 'Renato César Pereira Lima', 'SER ', 'Secretaria Executiva da Regional VI', 'Rua Padre Pedro de Alencar ,798- Messejana', '(085)3488-3116', '3170', 'renato.lima@fortaleza.ce.gov.br', '', '----', 'Secretário '),
(355, 'Claúdio Nelson Araújo Brandão ', 'SER ', 'Secretaria Executiva da Regional II ', 'Rua Professor Juraci de Oliveira ,01-Edson Queiroz ', '(085)3241-4755', '----', 'claudio.nelson@fortaleza.ce.gov.br', '', '----', 'Secretário '),
(356, 'Aldeniza', 'SER  ', 'Secretaria  Executiva da Regional  IV', 'Av.Dedê Brasil,3770-Serrinha', '(085) 3232-6021', '3232-6021/3433-2802', 'anisia_2005@hotmail.com', '', '----', '-'),
(357, 'Ricardo Sales', 'SER C', 'Secretaria Regional Centro', '-', '----', '---', 'ricardo.sales@fortaleza.ce.gov.br/ricardopsales@gmail.com', '', '(85)8682-2164', '-'),
(358, 'Sâmia Maria Pontes do Nascimento Cavalcante', 'SER Centro', 'Secretaria Regional Centro', '-----', '(85) 3105-1323', '----', 'samia.cavalcante@fortaleza.ce.gov.br', '', '(85) 8697-3100', 'Coordenadora Administrativa-Financeira'),
(359, 'Jackeline Facó Tavares', 'SER I', 'Secretaria Regional I', '-', '(85)3433-6894', '---', 'jackelinefaco@hotmail.com', '', '(85)8898-4499', '-'),
(360, 'Giselle Ribeiro de Alencar Alves', 'SER I', 'Secretaria Regional I', '-', '(85) 3433-6864', '---', 'giselle.alencar@fortaleza.ce.gov.br/gi1fidio9@gmail.com', '', '(85)9924-8901', '-'),
(361, 'Tereza Neumam Girão Saraiva', 'SER II', 'Secretaria Regional II', '-----', '(85) 3241-4794 ', '(85)3241-4754', 'teresa.saraiva@fortaleza.ce.gov.br', '', '(85) 8970-2068/9614-9038', 'Coordenadora da Assessoria de Planejamento'),
(362, 'Davi Teixeira', 'SER II', 'Secretaria Regional II', 'Rua Professor Juraci de Oliveira, 01 - Edson Queiroz.', '(85)3241-4868', '----', 'davi.teixeira@fortaleza.ce.gov.br', '', '(85)8723-0810', 'Chefe da infraestrutura'),
(363, 'Guto Azevedo', 'SER II', 'Secretaria Regional II', 'Rua Professor Juraci de Oliveira, 01 - Edson Queiroz.', '----', '----', 'guto.azevedo@fortaleza.ce.gov.br', '', '(85)9624-3512', '----'),
(364, 'José Rubson Augusto Mendes', 'SER II', 'Secretaria Regional II', '-', '---', '---', 'rubson@bol.com.br', '', '(85)8970-2065', '-'),
(365, 'Maria Verbenia Pontes Cavalcante', 'SER III', 'Secretaria Regional III', '-', '(85) 3433-2520', '-', 'verbeniapontes@yahoo.com.br', '', '(85)9997-3143', '-'),
(366, 'Icaro Regis Batista', 'SER III', 'Secretaria Regional III', '-', '(85) 3433-2520', '---', 'icaroregis@yahoo.com.br', '', '(85) 8689-2878', '-'),
(367, 'José Wellington Guerreiro', 'SER III', 'Secretaria Regional III', '-', '(85) 3433-2548', '-', 'jwellington.guerreiro@hotmail.com/jose.guerreiro@fortaleza.ce.gov.br', '', '(85) 9983-9755', '-'),
(368, 'Neide Lacerda', 'SER IV', 'Secretaria Regional IV', '-----', '(85) 3433-2860', '----', 'neide.lacerda@fortaleza.ce.gov.br', '', '----', 'Coordenadora do Administrativo Financeiro'),
(369, 'Isaac Anderson Barbosa', 'SER IV', 'Secretaria Regional IV', '-', '---', '---', 'isaac.barbosa@fortaleza', '', '(85)9723-3068', '-'),
(370, 'Adriano Aguiar Câmara', 'SER IV', 'Secretaria Regional IV', '-', '(85)3433-2807', '---', 'infraestruturaserIV@gmail.com', '', '(85) 8814-8058', '-'),
(371, 'Emanuella de Medeiros Santos', 'SER V', 'Secretaria Regional V', '-', '-', '-', 'Emannuellamedeiros@hotmail.com', '', '(85) 9905-7591', '-'),
(372, 'Maria das Graças Rodrigues', 'SER V', 'Secretaria Regional V', '-', '(85)3433-2902', '-', 'graça.rodrigues@fortaleza.ce.gov.br', '', '(85) 8570-2709', '-'),
(373, 'João Helder', 'SER VI', 'Secretaria Regional IV', '-', '(85) 3488-3101', '-', 'jhamoren2013@gmail.com', '', '(85) 8591-2150', '-'),
(374, 'Carlos Queioz Filho', 'SER VI', 'Secretaria Regional IV', '-', '(85) 3452-1936', '-', 'carlospqf@hotmail.com/carlos.filho@fortaleza.ce.gov.br', '', '(85) 8603-1020/8970-3486', '-'),
(375, 'Francisco Regis Cavalcante Dias ', 'SERCEFOR', 'Secretaria da Regional do Centro de Fortaleza ', 'Rua Guilherme Rocha,175- Centro', '(085)3242-3081', '----', 'regis.dias@fortaleza.ce.gov.br', '', '----', 'Secretário'),
(376, 'Otavia /renan', 'SERCEFOR', 'Secretaria da Regional do Centro de Fortaleza ', 'Rua Guilherme Rocha,175- Centro', '(085)3252-3081', '----', '----', '', '----', '----'),
(377, 'Andre Souza', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-8804', '----', 'andresouzagmf@gmail.com', '', '(085)8865-2007', '----'),
(378, 'Armando Vidal', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085) 3281-8151    ', '----', 'armandovidal26@hotmail.com', '', '(085)8531-9363', '----'),
(379, 'Flavia ', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281 8151', '(085)32818804', '----', '', '----', '----'),
(380, 'Flavia - Assistente', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281- 8151', '3281-8804', '----', '', '----', '----'),
(381, 'Francisco José Veras de Albuquerque', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281-8804', '----', 'fcoveras@gmail.com', '', '----', 'Secretário'),
(382, 'Franklin Teógenis Brandão de Souza', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '----', '----', 'teogenis.souza@fortaleza.ce.gov.br', '', '(85) 8750-3556', 'Gerente da Célula de Análise e de Sistemas'),
(383, 'Valeria - Secretaria', 'SESEC', 'Secretaria Municipal de Segurança Cidadã', 'Rua Delmiro de Farias ,1900-Rodolfo Teófilo', '(085)3281- 8804', '----', 'valcorpo@yahoo.com.br', '', '----', '----'),
(384, 'Jeane Peixoto', 'SESEC/GMF', '-------', '-', '(85)3281-2570', '-', 'jeane.sampaio@fortaleza.ce.gov.br', '', '(85)8869-0679', '-'),
(385, 'João Salmito Filho', 'SETFOR', 'Secretaria Municipal de Turismo de Fortaleza', 'Rua Leonardo Mota ,2700- Aldeota ', '(085)3105-1514', '1535', 'salmitofilho@yahoo.com.br', '', '----', 'Secretário'),
(386, 'Sonia /luiza ', 'SETFOR', 'Secretaria Municipal de Turismo de Fortaleza', 'Rua Leonardo Mota ,2700- Aldeota ', '(085)3105-1513', '(085)3105-1514', 'sonia.almeida@fortaleza.ce.gov.br', '', '----', '----'),
(387, 'Larissa Almeida Morais ', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '----', '----', 'larissamorais@hotmail.com', '', '(085)87151197', '----'),
(388, 'Lidiane Rios ', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(085)31053442', '----', 'lidiana.farias@fortaleza.ce.gov.br', '', '(085)89703506', '----'),
(389, 'Renata Azevedo ', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '----', '----', 'renata.azevedo@fortaleza.ce.gov.br', '', '(085)86006059', '----'),
(390, 'Robson Andrade', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(85)3105-3445', '----', 'robsongandrade@hotmail.com', '', '(85)8203-1510', 'TI'),
(391, 'Robson Bandeira', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '-', '-', 'robson.bandeira@fortaleza.ce.gov.br', '', '(85)9630-9342/(85) 8970-4614', 'Diretor de Desenvolvimento da Setra'),
(392, 'Renata Custodio', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(85)3105-3416', '-', 'renata_custodio@yahoo.com.br', '', '(85)8600-6059', '----'),
(393, 'Raimundo Ferreira', 'SETRA', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '-', '-', 'rdofilho@gmail.com', '', '(85)8970-3548', '----'),
(394, 'Claúdio Ricardo Gomes de Lima', 'SETRA ', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(085)3105-3708', '3711', 'claudio.lima@fortaleza.com.br', '', '----', 'Secretário '),
(395, 'Dinha  - Secretaria', 'SETRA ', 'Secretaria Municipal de Trabalho ,Desenvolvimento Social e Combate a Fome', 'Av.da Universidade ,3305-Benfica', '(085)3105-3440', '3105-3708/3711/3445', 'dinhafeijo@hotmail.com', '', '----', '----'),
(396, 'Alfredo Miranda ', 'SEUMA', 'Secretaria Municipal de Urbanismo e Meio Ambiente ', 'Av.Dep.Paulino Rocha ,1343- Cajazeiras ', '(085) 3452-6924', '/  6903                       ', 'alfredocmf@gmail.com', '', '(085)88471120', 'Gerente de TI'),
(397, 'Cilene/kelvia', 'SEUMA', 'Secretaria Municipal de Urbanismo e Meio Ambiente ', 'Av.Dep.Paulino Rocha ,1343- Cajazeiras ', '(085)3253-3911', '3452-6901/6903', 'cilene.fernandes@fortaleza.ce.gov.br', '', '----', '----'),
(398, 'Maria Águeda Pontes Caminha Muniz', 'SEUMA', 'Secretaria Municipal de Urbanismo e Meio Ambiente ', 'Av.Dep.Paulino Rocha ,1343- Cajazeiras ', '(085)3452-6901', '6903', 'seuma.fortaleza@gmail.com', '', '----', 'Secretária '),
(399, 'Carlos Assis', 'SME', 'Secretaria Municipal da Educação', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5590', '----', '----', '', '----', '----'),
(400, 'Delis Carvalho', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5904', '----', 'delis.carvalho@sme.fortaleza.ce.gov.br', '', '----', '----'),
(401, 'Glaumer', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459- 5902', '----', '----', '', '----', 'Geografo'),
(402, 'Iran Maia Nobre ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085) 3459-5915', '/ 5993 / 5941     ', 'IRANNOBRE@YAHOO.COM.BR', '', '(085) 8943 6146/8732-1286/9717-2632', '----'),
(403, 'Ivo Ferreira Gomes ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5933', '5993-5941', 'ivo23456@uol.com.br', '', '----', 'Secretário'),
(404, 'João Lúcio De Alcântra ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3454-5960', '/ 5993 / 5941     ', '----', '', '(085)8970-2045', '----'),
(405, 'Lamartine', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3454-5960', '----', '----', '', '(085)8834-6934', '----'),
(406, 'Lú ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '----', '----', '----', '', '----', '----'),
(407, 'Paulo Sarmento', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3454-5960', '----', 'paulocvs@sme.fortaleza.ce.gov.br', '', '(085)8723-3280', '----'),
(408, 'Ana Luisa Macedo Trindade ', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(85)3459-6761', '-', 'analuisa@sme.fortaleza.ce.gov.br', '', '(85)9955-9120\n', 'Gerente da célula de processos licitatórios'),
(409, 'Jeovah Carvalho Lima Pereira', 'SME', 'Secretaria Municipal de Educação ', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(85)3433-3588\n', '-', 'jeovah.carvalho@sme.fortaleza.ce.gov.br', '', '(85)8543-4787\n', 'Chefe do Setor de Compras\n'),
(410, 'Sônia  De Almeida Araujo', 'SME', 'Secretaria Municipal De Educação', 'Secretaria Municipal de Educação ', '----', '----', 'sonialmeidaraujo@gmail.com', '', '----', '----'),
(411, 'Alcides Oliveira Alcoforado', 'SME ', 'Secretaria Municipal da Educação', 'Av.Desembargador Moreira ,2875-Dionísio Torres', '(085)3459-5984', '-', 'alcides@sme.fortaleza.ce.gov.br', '', ' (085) 8970 -2102', '-'),
(412, 'André', 'SME ', 'Secretaria Municipal de Educação ', 'Rua do Rosário ,283,2ºe 3º.Andar - Centro ', '(085)3459 5916', '----', '----', '', '----', '----'),
(413, 'Luiza Brilhante', 'SME ', 'Secretaria Municipal de Educação ', 'Rua do Rosário ,283,2ºe 3º.Andar - Centro ', '(85)3459 5927', '----', '----', '', '----', '----'),
(414, 'Alexandre', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6611', '-', '-', '', '----', '-'),
(415, 'Eduardo Cabral Maia', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085) 3452-6954', '/6604 ', 'eduardocm@sms.fortaleza.ce.gov.br', '', '(085)9983-0304/ (85)8970-3273', 'Técnico da Área'),
(416, 'Fabiana', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', '----', '', '(085)8690-7644', '----'),
(417, 'Fernanda Aparecida', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6992', '3452-6604/6605', '----', '', '----', '----'),
(418, 'Gesiel Sousa', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6992', '3452-6604/6605', 'gsousa@sms.fortaleza.ce.gov.br', '', '(085)9989-8421', '----'),
(419, 'Igor Girão Barbosa', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-6992', '3452-6604/6605/6611', 'igirao@sms.fortaleza.ce.gov.br', '', '(085) 8807-8123', '----'),
(420, 'Marcos Oliveira', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-2357/(85)3105-1493', '----', 'moliveira@sms.fortaleza.ce.gov.br', '', '----', '----'),
(421, 'Osmar Jose do Nascimento', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)34526954', '----', 'osmarjnascimento@gmail.com', '', '(085)86234245', '----'),
(422, 'Rosalivia', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3452-2357', '----', '----', '', '9925-9506', '----'),
(423, 'Suzani Costa', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452-2357', '----', 'colegiadocotec@sms.fortaleza.ce.gov.br', '', '----', '----'),
(424, 'Francisco José Santos de Almeida', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário ,283 - Centro ', '(85) 3452-6984', '----', 'fjalmeida@sms.fortaleza.ce.gov.br', '', '(85) 8970-4627', 'Coordenador de Infaestrutura'),
(425, 'Aline Bárbara Rosa de Almeida ', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'alinebarbarar@hotmail.com', '', '(85)8699-7339\n(85)8970-3556', 'Gestora de Compras e licitações'),
(426, 'Jamilli Honorato Alburquerque', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3452-6600', '6602', 'jhonorato@sms.fortaleza.ce.gov.br/jamillihonorato@gmail.com', '', '(85)8859-5407', 'Assistente de Compras e Licitações'),
(427, 'Márcia Chrisostomo', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'mchrisostomo@uol.com.br', '', '(85)8864-6196', 'Gerente de material e patrimônio'),
(428, 'Antônia Itamárcia Carneiro', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'antonia.itamarcia@fortaleza.ce.gov.br', '', '(85)9969-7349', 'Diretora'),
(429, 'Maria Auxiliadora', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'auxiliadora123@yahoo.com.br', '', '(85)8844-1600', 'Coor. Ass. Planejamento'),
(430, 'Lorena Gomes Moura', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'lorenagmoura@gmail.com', '', '(85)8800-5420', 'Gerente Administrativa'),
(431, 'Cristianne', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '----', '----', 'cristianneamoris@gmail.com', '', '(85)8970-4074/8680-5901', 'Assistente da Ticiana Mota'),
(432, 'Bianca Moreira Coêlho', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85) 3452-3535', '-', 'biancacoelho@oi.com.br', '', '(85) 8822-7212', '-'),
(433, 'Humberto Vitorino', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'humberto.vd@hotmail.com', '', '(85)8563-2627', '-'),
(434, 'Antônia Adeny Leite', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3255-5053', '-', 'adeny.leite@yahoo.com.br', '', '(85)9611-9133', '-'),
(435, 'Oselita', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'oselita_gondim@yahoo.com.br', '', '(85)8789-1889', '-'),
(436, 'Hilda Ponciano Lima', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(85)3255-5042', '-', 'poncianohilda@hotmail.com', '', '(85)9954-1964', '-'),
(437, 'Lúcia Cidrão', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'lucia.cidao@sms.fortaleza.ce.gov.br', '', '(85)8906-2139', '-'),
(438, 'Thiala Josino', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'josino.thiala@gmail.com', '', '(85)8771-7325', '-'),
(439, 'Alexandre Pinto', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'alpinto@sms.fortaleza.ce.gov.br/ alexpinto2@gmail.com', '', '(85) 8588 8486/(85) 9731 7329', '-'),
(440, 'Andrea Couto', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'acouto@sms.fortaleza.ce.gov.br', '', '(85) 8537-0739', 'Anaslista de Infraestrutura'),
(441, 'Selma Nunes', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '-', '-', 'sellnunes@hotmail.com', '', '(85) 8652-8052', '-'),
(442, 'Dr. André Bomfim', 'SMS', 'Secretaria Municipal da saúde ', 'Rua do Rosário ,283 - Centro ', '(085)3452.23789', '-', 'andrebbomfim@gmail.com', '', '(085)8827-2903', '-'),
(443, 'Maria Do Perpetuo Socorro Martins Breckenfeld', 'SMS', 'Secretaria Municipal de Saúde ', 'Rua do Rosário, n° 283, 03 andar, no centro, em frente a praça da Policia Militar.', '(085)3452-6605', '6604/1786', 'socorrohm@gmail.com', '', '----', 'Secretária '),
(444, 'André Bomfim', 'SMS', '------', '-', '(085)3488.6966 / 6973   ', '----', ' andrebbomfim@gmail.com', '', '(085)8827-2903', '-'),
(445, 'Major Aguiar', 'SSPDS', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(85) 3101-6561 ', '----', '----', '', '(85) 8841-0332 / 8749-0118', 'Major da Polícia Militar'),
(446, 'Major Tetuliano', 'SSPDS', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(85) 3101-6512', '----', '----', '', '----', '----'),
(447, 'AGUIAR', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)31016561', '-', '-', '', '(085)88410332/87490118', '-'),
(448, 'Dr. Fernando', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)31016551', '----', '----', '', '----', 'COORDENADOR OPERACIONAL'),
(449, 'Fernando Menezes', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)3101 6544', '----', '----', '', '----', '----'),
(450, 'Franklin', 'SSPDS-COPOL', 'Secretaria de Segurança Pública do Estado do Ceará', 'Avenida Bezerra de Menezes, 581 - Parque Araxá', '(085)31016576', '----', 'franklin.torres@sspds.ce.gov.br', '', '----', '----'),
(451, 'Carlos de Paula', 'TABLEAU', 'Tableau Software', '-----', '-----', '----', '----', '', '(21) 982588285', 'Gerente Regional de Vendas'),
(452, 'André França', 'TI Gabinete', '---------', '-', '(85)3105-1450', '-', '-', '', '-', '-'),
(453, 'Jorzerlei', 'Unidade de Patrimonio', '-----', '-----', '(085)3452-1987', '----', '----', '', '----', '----'),
(454, 'Edna  Bento/Damião/Fabio', 'Unidade Financeiro ', '-----', '-----', '(085)3105-1457', '----', 'edna.bento@fortaleza.ce.gov.br', '', '----', '----'),
(455, 'Tatiana', 'Vice-prefeitura', 'Vice-Prefeitura Municipal', '-----', '(085)3452-1653', '----', 'tatiana.gomes@fortaleza.ce.gov.br', '', '----', '----'),
(456, 'Gaudencio Gonçalves de Lucena ', 'VICE-PREFEITURA', 'Vice-Prefeito Municipal', 'Av.Luciano Carneiro ,2235-Vila União ', '(085)3452-1652', '----', 'gaudenciolucena@gmail.com', '', '----', 'Vice-Prefeitura'),
(457, 'Ricardo Fontenele', 'VTI', 'Tecnologia  da Informação', 'R. Tibúrcio Cavalcante n 1573 Aldeota- Ed.VTI', '(085)40095290', '----', '----', '', '(085)9728-8889', '----'),
(458, 'Wagner Moura', 'VTI', 'Soluções Integradas a Gestões Inteligentes', 'Rua Tibúrcio Cavalcante, 1573 – Aldeota ', '(85) 4009-5290', '----', 'wagnermoura@vti.com.br', '', '(85) 9728-8889', 'Gerente de Negocios'),
(459, 'Marcelo Marcony', 'VTI', 'VTI', 'Rua Tiburcio Cavalcante, 1573, Aldeota.', '(85)4009-5290', '----', 'marcony@vti.com.br', '', '(85)9728-9394', 'Gerente Executivo - Tecnologia'),
(460, 'Marcelo Soares', 'VTI', 'VTI', 'Rua Tiburcio Cavalcante, 1573, Aldeota.', '(85)4009-5291', '----', 'marcelo@vti.com.br', '', '(85) 9986-8522', 'Executivo de negocios.'),
(461, 'Luiz Pedrette', 'VTI', 'VTI', 'Rua Tiburcio Cavalcante, 1573, Aldeota.', '(85)4009-5292', '----', 'luizpedrette@vti.com.br', '', '(85)9943-2839', 'Gerente de Negocios'),
(462, 'Reginaldo Mesquita Dos Anjos', '-----', '-----', '----', '------', '----', 'reginaldomesquitacontas@hotmail.com', '', '----', '----'),
(463, 'Joacy leite ', '------', '-------', '-------', '------', '----', '------', '', '(85)9998-9438', '-----'),
(464, 'Dorinha', '------', '------', '-----', '-----', '----', '-----', '', '(85)9757-6981', '-----'),
(468, 'Nome Editado', 'Orgão Editado', NULL, NULL, '(99) 9999-9999 1', '9999/1111', 'email@editado.com', '', '(99) 9999-9999 1', 'Cargo Editado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos_emails`
--

CREATE TABLE IF NOT EXISTS `contatos_emails` (
`id` int(11) NOT NULL,
  `id_contato` int(11) NOT NULL,
  `tipo_email` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=395 ;

--
-- Extraindo dados da tabela `contatos_emails`
--

INSERT INTO `contatos_emails` (`id`, `id_contato`, `tipo_email`, `email`) VALUES
(7, 1, '', 'fabricio.mendes.ti@gmail.com'),
(8, 2, '', 'ronaldo.ramos@gmail.com'),
(9, 4, '', 'annia.saboya@fortaleza.ce.gov.br'),
(10, 5, '', 'chmauro@fortalnet.com.br'),
(11, 6, '', 'ayrton@nucleo.infor.com.br'),
(12, 8, '', 'eduardo.fontenele@fortaleza.ce.gov.br'),
(13, 9, '', 'fatima.aragao@fortaleza.ce.gov.br'),
(14, 10, '', 'reubem.azevedo@fortaleza.ce.gov.br'),
(15, 15, '', 'crismcarvalhedo@hotmail.com'),
(16, 16, '', 'julianacnmedeiros@hotmail.com'),
(17, 17, '', 'cpraxedes@sms.fortaleza.ce.gov.br'),
(18, 17, '', 'sousa praxedes@ig.com.br'),
(19, 18, '', 'carlaeduvia@gmail.com'),
(20, 19, '', 'minuchy.mendes@hotmail.com'),
(21, 21, '', 'isalit22@yahoo.com.br'),
(22, 22, '', 'talita.melo@fortaleza.ce.gov.br'),
(23, 23, '', 'fabio@abacus.net.br'),
(24, 24, '', 'leongardel@gmail.com'),
(25, 25, '', 'maribarreirasoares@gmail.com'),
(26, 27, '', 'andre.lira@fortaleza.ce.gov.br'),
(27, 28, '', 'andre.lira@fortaleza.ce.gov.br'),
(28, 29, '', 'romulo.montezuma@fortaleza.ce.gov.br'),
(29, 31, '', 'gpa.amc@gmail.com'),
(30, 32, '', 'vitor.ciasca@fortaleza.ce.gov.br'),
(31, 33, '', 'andre.xerez@fortaleza.ce.gov.br'),
(32, 35, '', 'chicos@atlantico.com.br'),
(33, 36, '', 'cilis.benevides@gmail.com'),
(34, 37, '', 'emanuelajord@gmail.com'),
(35, 37, '', 'emanuela.costa@fortaleza.ce.gov.br'),
(36, 38, '', 'asier@bancopalmas.org.br'),
(37, 40, '', 'airtonjr@bnb.gov.br'),
(38, 41, '', 'uchoa@cadicbrasil.com.br'),
(39, 42, '', 'lucirenemaciel@gmail.com'),
(40, 43, '', 'eduardo.martins@fortaleza.ce.gov.br'),
(41, 43, '', 'dumartinsm@yahoo.com.br'),
(42, 44, '', 'fabio.santiago@fortaleza.ce.gov.br'),
(43, 44, '', 'santiago.fabio@hotmail.com'),
(44, 45, '', 'camilahollanda@hotmail.com.br'),
(45, 46, '', 'licita.comprafortaleza@hotmail.com'),
(46, 47, '', 'samuelallexandre@hotmail.com'),
(47, 48, '', 'fernanda.fernandes@fortaleza.ce.gov.br'),
(48, 48, '', 'fernandaassisfernandes@hotmail.com'),
(49, 49, '', 'dora.bessa@fortaleza.ce.gov.br'),
(50, 50, '', 'furtado.vasco@fortaleza.ce.gov.br'),
(51, 50, '', 'furtado.vasco@gmail.com'),
(52, 51, '', 'tarcisiopequeno@gmail.com'),
(53, 53, '', 'erick.medrado@fortaleza.ce.gov.br'),
(54, 54, '', 'haroldo.maranhao@fortaleza.ce.gov.br'),
(55, 55, '', 'igor.leite@fortaleza.ce.gov.br'),
(56, 56, '', 'hermes.oliveira@fortaleza.ce.gov.br'),
(57, 57, '', 'jonascavalcantineto@gmail.com'),
(58, 57, '', 'jonas.neto@fortaleza.ce.gov.br'),
(59, 58, '', 'luiz.maia@fortaleza.ce.gov.br'),
(60, 59, '', 'mikaely.greggio@fortaleza.ce.gov.br'),
(61, 60, '', 'bruno.tinoco@fortaleza.ce.gov.br'),
(62, 61, '', 'veronica.aguiar@fortaleza.ce.gov.br'),
(63, 62, '', 'italo.alencar@fortaleza.ce.gov.br'),
(64, 63, '', 'maxlane.chagas@fortaleza.ce.gov.br'),
(65, 64, '', 'sullivan.estrela@fortaleza.ce.gov.br'),
(66, 65, '', 'relacoespublicas@hotmail.com'),
(67, 66, '', 'lucas.gurgel@fortaleza.ce.gov.br'),
(68, 67, '', 'marinabua@gmail.com'),
(69, 69, '', 'jaderomero@gmail.com'),
(70, 69, '', 'jade.romero@fortaleza.ce.gov.br'),
(71, 69, '', 'sabigsb@gmail.com'),
(72, 70, '', 'elcioelcioelcio@gmail.com'),
(73, 71, '', 'julianaformiga@gmail.com'),
(74, 73, '', 'camilasilveirace@gmail.com'),
(75, 74, '', 'coordenadoriadamulherfor@yahoo.com.br'),
(76, 75, '', 'fc_ferrer@hotmail.com'),
(77, 76, '', 'julio.cals@fortaleza.ce.gov.br'),
(78, 77, '', 'andrearossati40@hotmail.com'),
(79, 78, '', 'coordenadoriamulherfor@yahoo.com.br'),
(80, 79, '', 'joao.uchuoa@fortaleza.ce.gov.br'),
(81, 80, '', 'nzandrade@gmail.com'),
(82, 81, '', 'lucio.bruno@fortaleza.ce.gov.br'),
(83, 82, '', 'lucio-bruno@ig.com.br'),
(84, 83, '', 'ed.lucio@fortaleza'),
(85, 84, '', 'jornalistamoacirmaia@gmail.com'),
(86, 85, '', 'hermann.hesse@fortaleza.ce.gov.br'),
(87, 86, '', 'elcioelcioelcio@gmail.com'),
(88, 88, '', 'prof.thauzer@gmail.com'),
(89, 89, '', 'josecoopir@fortaleza.ce.gov.br'),
(90, 89, '', 'coopir.scdh@fortaleza.ce.gov.br'),
(91, 91, '', 'rodolfo.sikora@fortaleza.ce.gov.br'),
(92, 92, '', 'mjulianasena@gmail.com'),
(93, 93, '', 'mlourdes7@yahoo.com.br'),
(94, 95, '', 'crislicitacaofortaleza@gmail.com'),
(95, 96, '', 'geovania4@hotmail.com'),
(96, 97, '', 'geovania4@hotmail.com'),
(97, 99, '', 'vera.lucia@fortaleza.ce.gov.br'),
(98, 102, '', 'jaderomero@gmail.com'),
(99, 103, '', 'rafaellereis@yahoo.com.br'),
(100, 104, '', 'c.alberto.alves@hotmail.com'),
(101, 105, '', 'c.alberto.alves@hotmail.com'),
(102, 106, '', 'c.alberto.alves@hotmail.com'),
(103, 106, '', 'anicecampos@bol.com.br'),
(104, 108, '', 'sergio.miranda@ctis.com.br'),
(105, 109, '', 'rafaelc@ctis.com.br'),
(106, 111, '', 'filizolina.sousa@fortaleza.ce.gov.br'),
(107, 112, '', 'paulo.afonso@fortaleza.ce.gov.br'),
(108, 113, '', 'valeria.borges@fortaleza.ce.gov.br'),
(109, 114, '', 'cristiano.ferrer@fortaleza.ce.gov.br'),
(110, 117, '', 'otavio.gondim@dnocs.gov.br'),
(111, 118, '', 'ronaldonogueirapmf@gmail.com'),
(112, 123, '', 'carolpinheiro84@hotmail.com'),
(113, 124, '', 'rogerio@etufor.ce.gov.br'),
(114, 126, '', 'giordanny.napolião@gmail.com'),
(115, 127, '', 'noemi.fonseca@fortaleza.ce.gov.br'),
(116, 128, '', 'arquimedespinheiro@hotmail.com'),
(117, 130, '', 'tania.gurgel@fortaleza.ce.gov.br'),
(118, 131, '', 'carol.bezerra@fortaleza.ce.gov.br'),
(119, 132, '', 'celia.medeiros@fortaleza.ce.gov.br'),
(120, 133, '', 'silva_ferreira_cristiana@yahoo.com.br'),
(121, 134, '', 'leticiamm4@gmail.com'),
(122, 135, '', 'gilmar.soares@fortaleza.ce.gov.br'),
(123, 136, '', 'edna.brasil@fortaleza.ce.gov.b'),
(124, 137, '', 'eliane.leao@fortaleza.ce.gov.br'),
(125, 138, '', 'glaucia.diogo@fortaleza.ce.gov.br'),
(126, 140, '', 'evanildorpipoca@hotmail.com'),
(127, 144, '', 'diana.carvalho@fortaleza.ce.gov.br'),
(128, 146, '', 'queiroz.maia@fortaleza.ce.gov.br'),
(129, 147, '', 'queiroz.maia@fortaleza.ce.gov.br'),
(130, 147, '', 'queirozmaia@hotmail.com.com.br'),
(131, 150, '', 'robertoclaudio@gabpref.fortaleza.ce.gov.br'),
(132, 151, '', 'laudelio.bastos@fortaleza.ce.gov.br'),
(133, 152, '', 'gerardo.junior@fortaleza.ce.gov.br'),
(134, 156, '', 'gabinete.sesec@gmail.com'),
(135, 158, '', 'subinspetorarilza@yahoo.com.br'),
(136, 159, '', 'juciana.ribeiro@fortaleza.ce.gov.br'),
(137, 160, '', 'presidenciahabitafor@fortaleza.ce.gov.br'),
(138, 160, '', 'belecoelho@gmail.com'),
(139, 161, '', 'anaxa2006@gmail.com'),
(140, 162, '', 'rodccosta@gmail.com'),
(141, 163, '', 'romulo.ferrer@gmail.com'),
(142, 164, '', 'anaxa2006@gmail.com'),
(143, 165, '', 'adeysejs@hotmail.com.br'),
(144, 166, '', 'walterfrota@hotmail.com'),
(145, 168, '', 'andre.silva8@gmail.com.br'),
(146, 168, '', 'virginiavjmarcio@gmail.com'),
(147, 169, '', 'virginia.oliveira@fortaleza.ce.gov.br'),
(148, 170, '', 'robson.pessoa@ctis.com.br'),
(149, 171, '', 'rantunes@informatica.com'),
(150, 172, '', 'jaime@intelletto.com.br'),
(151, 177, '', 'cleyber.medeiros@ipece.ce.gov.br'),
(152, 178, '', 'arthur.ipem@fortaleza.ce.gov.br'),
(153, 178, '', 'cti.ipem@fortaleza.ce.gov.br'),
(154, 179, '', 'superintendencia.ipm@fortaleza.ce.gov.br'),
(155, 180, '', 'marciacidrack@hotmail.com'),
(156, 181, '', 'bessainacio@gmail.com'),
(157, 182, '', 'rodrigors.petry@gmail.com'),
(158, 183, '', 'alexandrino.diogenes@fortaleza.ce.gov.br'),
(159, 184, '', 'joacyleite@gmail.com'),
(160, 185, '', 'laffittejorge@gmail.com'),
(161, 186, '', 'luiz.santos@fortaleza.ce.gov.br'),
(162, 186, '', 'siul.sant@gmail.com'),
(163, 187, '', 'marcosmendes938@gmail.com'),
(164, 189, '', 'sergio.menezes@fortaleza.com'),
(165, 190, '', 'vaninha.rocha@fortaleza.ce.gov.br'),
(166, 191, '', 'volia.rocha@fortaleza.ce.gov.br'),
(167, 192, '', 'conceicao.cidrack@fortaleza.ce.gov.br'),
(168, 193, '', 'eudorosantana@gmail.com'),
(169, 194, '', ' fabioweydson@gmail.com'),
(170, 195, '', 'felipejteles@gmail.com'),
(171, 196, '', 'luizaperdigao@gmail.com'),
(172, 196, '', 'luiza.perdigao@fortaleza.ce.gov.br'),
(173, 197, '', 'thaisabreumagalhaes@gmail.com'),
(174, 198, '', 'marcio.seabra@fortaleza.ce.gov.br'),
(175, 199, '', 'raquel.honorio@fortaleza.ce.gov.br'),
(176, 199, '', 'raquelshonorio@gmail.com'),
(177, 200, '', 'tamile.solon@fortaleza.ce.gov.br'),
(178, 201, '', ' rodrigo.pordeus@fortaleza.ce.gov.br'),
(179, 202, '', 'lia.parente@fortaleza.ce.gov.br'),
(180, 204, '', 'aline@ipmfor.ce.gov.br'),
(181, 205, '', 'superintendencia.ipem@fortaleza.ce.gov.br'),
(182, 206, '', 'dr.porto@ipmfor.ce.gov.br'),
(183, 209, '', 'cristianneamoris@gmail.com'),
(184, 212, '', 'sergiooliveira@isgh.org.br'),
(185, 213, '', 'edgy.paiva@ivia.com.br'),
(186, 215, '', 'paulo@konpax.com'),
(187, 216, '', 'cristiane.deusdara@fortaleza.ce.gov.br'),
(188, 217, '', 'augusto@n5tecnologia.com.br'),
(189, 218, '', 'elan@nucleoinfo.com.br'),
(190, 219, '', 'monteiro@nucleoinfo.com.br'),
(191, 221, '', 'lilianemptceara@hotmail.com'),
(192, 223, '', 'pedro@omegagrupo.com.br'),
(193, 224, '', 'valdenor@omegagrupo.com.br'),
(194, 225, '', 'valmir@omegagrupo.com.br'),
(195, 226, '', 'claudia.rh@omegagrup.com.br'),
(196, 227, '', 'eliete.castro@fortaleza.ce.gov.br'),
(197, 229, '', 'joseleite@gmail.com'),
(198, 230, '', 'joseleite@gmail.com'),
(199, 231, '', 'cacaulima2@hotmail.com'),
(200, 231, '', 'acessoriaplanejamento@sms.fortaleza.ce.gov.br'),
(201, 232, '', 'andre.ramos@sefin.fortaleza.ce.gov.br'),
(202, 233, '', 'marta.goes@sefin.fortaleza.ce.gov.br'),
(203, 235, '', 'spcavalcante@gmail.com'),
(204, 236, '', 'georgelopesvalentim@hotmail.com'),
(205, 237, '', 'regioliveira.80@gmail.com'),
(206, 241, '', 'karlo.kardozo@fortaleza.ce.gov.br'),
(207, 243, '', 'joao_pupo@hotmail.com'),
(208, 244, '', 'jlenassa@hotmail.com'),
(209, 245, '', 'luiz.saboia@fortaleza.ce.gov.br'),
(210, 246, '', 'rafael.sousa@fortaleza.ce.gov.br'),
(211, 247, '', 'fcofigueredo@hotmail.com'),
(212, 248, '', 'sergio.moraes@fortaleza.ce.gov.br'),
(213, 249, '', 'italo.andrade@fortaleza.ce.gov.br'),
(214, 250, '', 'joyce.oliveira@fortaleza.ce.gov.br'),
(215, 251, '', 'davi.santos@fortaleza.ce.gov.br'),
(216, 252, '', 'robinson.castro@fortaleza.ce.gov.br'),
(217, 253, '', 'karlo.kardozo@fortaleza.ce.gov.br'),
(218, 254, '', 'edna.cleyane@fortaleza.ce.gov.br'),
(219, 255, '', 'marcio.lopes@fortaleza.ce.gov.br'),
(220, 256, '', 'rosiane.sousa@fortaleza.ce.gov.br'),
(221, 257, '', 'sandra.marrocos@fortaleza.ce.gov.br'),
(222, 258, '', 'domingosaguiarneto@gmail.com'),
(223, 259, '', 'domingosaguiarrneto@gmail.com'),
(224, 261, '', 'marlon.cambraia@fortaleza.ce.gov.br'),
(225, 262, '', 'rocha.neto@fortaleza.ce.gov.br'),
(226, 263, '', 'jeissa.lucas@fortaleza.ce.gov.br'),
(227, 264, '', 'secultfor.fortaleza@gmail.com'),
(228, 265, '', 'inacio.coelho@fortaleza.ce.gov.br'),
(229, 266, '', 'secultfor.fortaleza@gmail.com'),
(230, 267, '', 'secultfor.fortaleza@gmail.com'),
(231, 269, '', 'adrianos@seduc.ce.gov.br'),
(232, 270, '', 'giovani@seduc.ce.gov.br'),
(233, 271, '', 'joao.paulo@seduc.ce.gov.br'),
(234, 274, '', 'eveline.campos@sefin.fortaleza.ce.gov.br'),
(235, 276, '', 'fcoricardovribeiro@hotmail.com'),
(236, 276, '', 'ricardo.ribeiro@sefin.fortaleza.ce.gov.br'),
(237, 277, '', 'helcio.nascimento@sefin.fortaleza.ce.gov.br'),
(238, 278, '', 'heloisa.aragao@sefin.fortaleza.ce.gov.br'),
(239, 279, '', 'jaime.cavalcante@fortaleza.ce.gov.br'),
(240, 280, '', 'joseldealencar@yahoo.com.br'),
(241, 281, '', 'jurandir.gurgel@fortaleza.ce.gov.br'),
(242, 283, '', 'mariangela.bezerra@sefin.fortaleza.ce.gov.br'),
(243, 284, '', 'paulo.aguiar@sefin.fortaleza.ce.gov.br'),
(244, 286, '', 'sarah.correia@sefin.fortaleza.ce.gov.br'),
(245, 287, '', 'vanessa.simonassi@sefin.fortaleza.ce.gov.br'),
(246, 289, '', 'veronica.oliveira@sefin.fortaleza.ce.gov.br'),
(247, 290, '', 'clovis.soares@sefin.fortaleza.ce.gov.br'),
(248, 291, '', 'zuilton.mendonca@sefin.fortaleza.ce.gov.br'),
(249, 292, '', 'joao.fernando@sefim.fortaleza.ce.gov.br'),
(250, 293, '', 'elianemtg@hotmail.com'),
(251, 295, '', 'ricardo.ribeiro@sefin.fortaleza.ce.gov.br'),
(252, 297, '', 'ticianamotas@gmail.com'),
(253, 298, '', 'camille.mesquita@fortaleza.ce.gov.br'),
(254, 300, '', 'laudelio.bastos@fortaleza.ce.gov.br'),
(255, 301, '', 'priscobezerra@yahoo.com.br'),
(256, 302, '', 'camille.mesquita@fortaleza.ce.gov.br'),
(257, 303, '', 'breno.coe@fortaleza.ce.gov.br'),
(258, 304, '', 'eduardo.freitas@fortaleza.ce.gov.br'),
(259, 306, '', 'giselle.mafra@fortaleza.ce.gov.br'),
(260, 307, '', 'moacir.casemiro@fortaleza.ce.gov.br'),
(261, 308, '', 'moacir.casemiro@fortaleza.ce.gov.br'),
(262, 309, '', 'samuel.dias@fortaleza.ce.gov.br'),
(263, 310, '', 'samuel.dias@fortaleza.ce.gov.br'),
(264, 311, '', 'thiago.mafra@arcadislogos.com.br'),
(265, 312, '', 'gabriela.maia@fortaleza.ce.gov.br'),
(266, 313, '', 'manuelito.cavalcante@fortaleza.ce.gov.br'),
(267, 314, '', 'joao.menescal@fortaleza.ce.gov.br'),
(268, 315, '', 'agueda.muniz@fortaleza.ce.gov.br'),
(269, 317, '', 'pedro.capibaribe@cidades'),
(270, 317, '', ''),
(271, 318, '', 'ana.luisa@fortaleza.ce.gov.br'),
(272, 319, '', 'ana.carvalho@fortaleza.ce.gov.br'),
(273, 321, '', 'aparecida.facanha@fortaleza.ce.gov.br'),
(274, 323, '', 'cleide.madeiro@fortaleza.ce.gov.br'),
(275, 324, '', 'cristiane.deusdara@fortaleza.ce.gov.br'),
(276, 326, '', 'haroldo.maranhao@fortaleza.ce.gov.br'),
(277, 329, '', 'paulo.neto@fortaleza.ce.gov.br'),
(278, 330, '', 'jorge.alcoforado@fortaleza.ce.gov.br'),
(279, 330, '', 'jalcoforado@gmail.com'),
(280, 331, '', 'lucineide.silva@fortaleza.ce.gov.br'),
(281, 332, '', 'lucio.junior@fortaleza.ce.gov.br'),
(282, 332, '', 'luciocimm@yahoo.com.br'),
(283, 335, '', 'philipe@fortaleza.ce.gov.br'),
(284, 336, '', 'marcos.cavalcante@fortaleza.ce.gov.br'),
(285, 337, '', 'karolilne.cavalcante@fortaleza.ce.gov.br'),
(286, 338, '', 'denise.albuquerque@fortaleza.ce.gov.br'),
(287, 339, '', 'desiree.mota@fortaleza.ce.gov.br'),
(288, 340, '', 'verene.barbosa@fortaleza.ce.gov.br'),
(289, 341, '', 'aline.barbosa@fortaleza.ce.gov.br'),
(290, 342, '', 'marthasouzaa@hotmail.com'),
(291, 343, '', 'cleirtonnune@hotmail.com'),
(292, 344, '', 'ridenia.maia@fortaleza.ce.gov.br'),
(293, 345, '', 'anusia.holanda@fortaleza.ce.gov.br'),
(294, 346, '', 'fatima.canuto@fortaleza.ce.gov.br'),
(295, 347, '', 'guilherme.gouveia@fortaleza.ce.gov.br'),
(296, 348, '', 'jessica.barbosa@fortaleza.ce.gov.br'),
(297, 349, '', 'julio.ramon@fortaleza.ce.gov.br'),
(298, 350, '', 'fan.morao@fort.ce.gov.br'),
(299, 351, '', 'gabineteregional4@hotmail.com'),
(300, 352, '', 'fatimacanuto@yahoo.com.br'),
(301, 353, '', 'claudia_ribeiro@hotmail.com'),
(302, 354, '', 'renato.lima@fortaleza.ce.gov.br'),
(303, 355, '', 'claudio.nelson@fortaleza.ce.gov.br'),
(304, 356, '', 'anisia_2005@hotmail.com'),
(305, 357, '', 'ricardo.sales@fortaleza.ce.gov.br'),
(306, 357, '', 'ricardopsales@gmail.com'),
(307, 358, '', 'samia.cavalcante@fortaleza.ce.gov.br'),
(308, 359, '', 'jackelinefaco@hotmail.com'),
(309, 360, '', 'giselle.alencar@fortaleza.ce.gov.br'),
(310, 360, '', 'gi1fidio9@gmail.com'),
(311, 361, '', 'teresa.saraiva@fortaleza.ce.gov.br'),
(312, 362, '', 'davi.teixeira@fortaleza.ce.gov.br'),
(313, 363, '', 'guto.azevedo@fortaleza.ce.gov.br'),
(314, 364, '', 'rubson@bol.com.br'),
(315, 365, '', 'verbeniapontes@yahoo.com.br'),
(316, 366, '', 'icaroregis@yahoo.com.br'),
(317, 367, '', 'jwellington.guerreiro@hotmail.com'),
(318, 367, '', 'jose.guerreiro@fortaleza.ce.gov.br'),
(319, 368, '', 'neide.lacerda@fortaleza.ce.gov.br'),
(320, 369, '', 'isaac.barbosa@fortaleza'),
(321, 370, '', 'infraestruturaseriv@gmail.com'),
(322, 371, '', 'emannuellamedeiros@hotmail.com'),
(323, 372, '', 'graça.rodrigues@fortaleza.ce.gov.br'),
(324, 373, '', 'jhamoren2013@gmail.com'),
(325, 374, '', 'carlospqf@hotmail.com'),
(326, 374, '', 'carlos.filho@fortaleza.ce.gov.br'),
(327, 375, '', 'regis.dias@fortaleza.ce.gov.br'),
(328, 377, '', 'andresouzagmf@gmail.com'),
(329, 378, '', 'armandovidal26@hotmail.com'),
(330, 381, '', 'fcoveras@gmail.com'),
(331, 382, '', 'teogenis.souza@fortaleza.ce.gov.br'),
(332, 383, '', 'valcorpo@yahoo.com.br'),
(333, 384, '', 'jeane.sampaio@fortaleza.ce.gov.br'),
(334, 385, '', 'salmitofilho@yahoo.com.br'),
(335, 386, '', 'sonia.almeida@fortaleza.ce.gov.br'),
(336, 387, '', 'larissamorais@hotmail.com'),
(337, 388, '', 'lidiana.farias@fortaleza.ce.gov.br'),
(338, 389, '', 'renata.azevedo@fortaleza.ce.gov.br'),
(339, 390, '', 'robsongandrade@hotmail.com'),
(340, 391, '', 'robson.bandeira@fortaleza.ce.gov.br'),
(341, 392, '', 'renata_custodio@yahoo.com.br'),
(342, 393, '', 'rdofilho@gmail.com'),
(343, 394, '', 'claudio.lima@fortaleza.com.br'),
(344, 395, '', 'dinhafeijo@hotmail.com'),
(345, 396, '', 'alfredocmf@gmail.com'),
(346, 397, '', 'cilene.fernandes@fortaleza.ce.gov.br'),
(347, 398, '', 'seuma.fortaleza@gmail.com'),
(348, 400, '', 'delis.carvalho@sme.fortaleza.ce.gov.br'),
(349, 402, '', 'irannobre@yahoo.com.br'),
(350, 403, '', 'ivo23456@uol.com.br'),
(351, 407, '', 'paulocvs@sme.fortaleza.ce.gov.br'),
(352, 408, '', 'analuisa@sme.fortaleza.ce.gov.br'),
(353, 409, '', 'jeovah.carvalho@sme.fortaleza.ce.gov.br'),
(354, 410, '', 'sonialmeidaraujo@gmail.com'),
(355, 411, '', 'alcides@sme.fortaleza.ce.gov.br'),
(356, 415, '', 'eduardocm@sms.fortaleza.ce.gov.br'),
(357, 418, '', 'gsousa@sms.fortaleza.ce.gov.br'),
(358, 419, '', 'igirao@sms.fortaleza.ce.gov.br'),
(359, 420, '', 'moliveira@sms.fortaleza.ce.gov.br'),
(360, 421, '', 'osmarjnascimento@gmail.com'),
(361, 423, '', 'colegiadocotec@sms.fortaleza.ce.gov.br'),
(362, 424, '', 'fjalmeida@sms.fortaleza.ce.gov.br'),
(363, 425, '', 'alinebarbarar@hotmail.com'),
(364, 426, '', 'jhonorato@sms.fortaleza.ce.gov.br'),
(365, 426, '', 'jamillihonorato@gmail.com'),
(366, 427, '', 'mchrisostomo@uol.com.br'),
(367, 428, '', 'antonia.itamarcia@fortaleza.ce.gov.br'),
(368, 429, '', 'auxiliadora123@yahoo.com.br'),
(369, 430, '', 'lorenagmoura@gmail.com'),
(370, 431, '', 'cristianneamoris@gmail.com'),
(371, 432, '', 'biancacoelho@oi.com.br'),
(372, 433, '', 'humberto.vd@hotmail.com'),
(373, 434, '', 'adeny.leite@yahoo.com.br'),
(374, 435, '', 'oselita_gondim@yahoo.com.br'),
(375, 436, '', 'poncianohilda@hotmail.com'),
(376, 437, '', 'lucia.cidao@sms.fortaleza.ce.gov.br'),
(377, 438, '', 'josino.thiala@gmail.com'),
(378, 439, '', 'alpinto@sms.fortaleza.ce.gov.br'),
(379, 439, '', 'alexpinto2@gmail.com'),
(380, 440, '', 'acouto@sms.fortaleza.ce.gov.br'),
(381, 441, '', 'sellnunes@hotmail.com'),
(382, 442, '', 'andrebbomfim@gmail.com'),
(383, 443, '', 'socorrohm@gmail.com'),
(384, 444, '', ' andrebbomfim@gmail.com'),
(385, 450, '', 'franklin.torres@sspds.ce.gov.br'),
(386, 454, '', 'edna.bento@fortaleza.ce.gov.br'),
(387, 455, '', 'tatiana.gomes@fortaleza.ce.gov.br'),
(388, 456, '', 'gaudenciolucena@gmail.com'),
(389, 458, '', 'wagnermoura@vti.com.br'),
(390, 459, '', 'marcony@vti.com.br'),
(391, 460, '', 'marcelo@vti.com.br'),
(392, 461, '', 'luizpedrette@vti.com.br'),
(393, 462, '', 'reginaldomesquitacontas@hotmail.com'),
(394, 468, '', 'email@editado.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos_telefones`
--

CREATE TABLE IF NOT EXISTS `contatos_telefones` (
`id` int(11) NOT NULL,
  `id_contato` int(11) NOT NULL,
  `tipo_fone` varchar(255) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `ramal` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=719 ;

--
-- Extraindo dados da tabela `contatos_telefones`
--

INSERT INTO `contatos_telefones` (`id`, `id_contato`, `tipo_fone`, `telefone`, `ramal`) VALUES
(1, 198, 'Institucional', '(85)3105-1355', ''),
(2, 198, 'Celular', '(85)9927-5721', ''),
(3, 1, 'Geral', '(85)3236-0541', ''),
(4, 4, 'Geral', '(85)3105-1356', ''),
(5, 8, 'Geral', '(85)3452-4562', ''),
(6, 10, 'Geral', '(85)3452-4659', ''),
(7, 12, 'Geral', '(85)3105-1378', ''),
(8, 13, 'Geral', '(85)3131-7712', ''),
(9, 14, 'Geral', '(85)3131-7712', ''),
(10, 20, 'Geral', '(85)3253-1546', ''),
(11, 24, 'Geral', '(85)3244-1531', ''),
(12, 25, 'Geral', '(85)3433-2789', ''),
(13, 27, 'Geral', '(85)3488-5733', ''),
(14, 28, 'Geral', '(85)3488-5737', ''),
(15, 33, 'Geral', '(85)3105-1367', ''),
(16, 34, 'Geral', '(85)3452-6966', ''),
(17, 36, 'Geral', '(85)3276-7836', ''),
(18, 37, 'Geral', '(85)3276-7836', ''),
(19, 40, 'Geral', '(85)3251-7177', ''),
(20, 41, 'Geral', '(85)3268-3639', ''),
(21, 44, 'Geral', '(85)3105-1157', ''),
(22, 45, 'Geral', '(85)3452-3474', ''),
(23, 46, 'Geral', '(85)3105-1157', ''),
(24, 47, 'Geral', '(85)3452-3474', ''),
(25, 48, 'Geral', '(85)3452-4657', ''),
(26, 49, 'Geral', '(85)3452-6181', ''),
(27, 50, 'Geral', '(85)3452-6181', ''),
(28, 51, 'Geral', '(85)3452-6181', ''),
(29, 53, 'Geral', '(85)3452-3472', ''),
(30, 54, 'Geral', '(85)3433-3472', ''),
(31, 55, 'Geral', '(85)3452-3430', ''),
(32, 56, 'Geral', '(85)3433-3472', ''),
(33, 57, 'Geral', '(85)3433-3472', ''),
(34, 58, 'Geral', '(85)3433-3472', ''),
(35, 59, 'Geral', '(85)3452.3430', ''),
(36, 60, 'Geral', '(85)3433-3430', ''),
(37, 63, 'Geral', '(85)3452-3472', ''),
(38, 65, 'Geral', '(85)3452-2344', ''),
(39, 66, 'Geral', '(85)3254-5376', ''),
(40, 67, 'Geral', '(85)3452-5376', ''),
(41, 69, 'Geral', '(85)3105-1569', ''),
(42, 70, 'Geral', '(85)3452-2118', ''),
(43, 74, 'Geral', '(85)3105-1398', ''),
(44, 76, 'Geral', '(85)3452-2364', ''),
(45, 78, 'Geral', '(85)3105-1398', ''),
(46, 81, 'Geral', '(85)3105-1371', ''),
(47, 83, 'Geral', '(85)3105-1447', ''),
(48, 85, 'Geral', '(85)3452-1655', ''),
(49, 88, 'Geral', '(85)3252-3436', ''),
(50, 89, 'Geral', '(85)3452-7747', ''),
(51, 91, 'Geral', '(85)3433-3635', ''),
(52, 93, 'Geral', '(85)3452-7296', ''),
(53, 95, 'Geral', '(85)3105-1150', ''),
(54, 97, 'Geral', '(85)3452-3477', ''),
(55, 98, 'Geral', '(85)3452-3477', ''),
(56, 99, 'Geral', '(85)3452-3480', ''),
(57, 100, 'Geral', '(85)3452-3473', ''),
(58, 101, 'Geral', '(85)3452-3482', ''),
(59, 102, 'Geral', '(85)3452-6780', ''),
(60, 103, 'Geral', '(85)3452-6792', ''),
(61, 104, 'Geral', '(85)3433-9670', ''),
(62, 105, 'Geral', '(85)3433-9670', ''),
(63, 106, 'Geral', '(85)3433-9670', ''),
(64, 109, 'Geral', '(61)3426-9406', ''),
(65, 110, 'Geral', '(85)3452-4658', ''),
(66, 111, 'Geral', '(85)3105-1456', ''),
(67, 113, 'Geral', '(85)3105-1472', ''),
(68, 115, 'Geral', '(85)3253-3962', ''),
(69, 117, 'Geral', '(85)3391-5103', ''),
(70, 121, 'Geral', '(85)3452-9333', ''),
(71, 126, 'Geral', '(85)3105-1360', ''),
(72, 128, 'Geral', '(85)3105-1316', ''),
(73, 129, 'Geral', '(85)3105-1316', ''),
(74, 130, 'Geral', '(85)3105-1316', ''),
(75, 133, 'Geral', '(85)3452-1651', ''),
(76, 134, 'Geral', '(85)3452-7276', ''),
(77, 138, 'Geral', '(85)3105-1369', ''),
(78, 139, 'Geral', '(85)3105-1165', ''),
(79, 141, 'Geral', '(85)3105-1169', ''),
(80, 142, 'Geral', '(85)3105-1460', ''),
(81, 143, 'Geral', '(85)3105-1460', ''),
(82, 144, 'Geral', '(85)3105-1002', ''),
(83, 146, 'Geral', '(85)3105-1378', ''),
(84, 148, 'Geral', '(85)3452-6798', ''),
(85, 150, 'Geral', '(85)3105-1099', ''),
(86, 151, 'Geral', '(85)3105-1461', ''),
(87, 153, 'Geral', '(85)3105-1022', ''),
(88, 154, 'Geral', '(85)3105-1165', ''),
(89, 160, 'Geral', '(85)3488-3377', ''),
(90, 162, 'Geral', '(85)3455-9006', ''),
(91, 167, 'Geral', '(85)3253-1546', ''),
(92, 169, 'Geral', '(85)3467-6704', ''),
(93, 170, 'Geral', '(61)3426-9402', ''),
(94, 171, 'Geral', '(61)3041-9599', ''),
(95, 173, 'Geral', '(85)3101-3512', ''),
(96, 174, 'Geral', '(85)3101-3521', ''),
(97, 175, 'Geral', '(85)3101-3505', ''),
(98, 176, 'Geral', '(85)3105-3496', ''),
(99, 181, 'Geral', '(85)3253-2221', ''),
(100, 184, 'Geral', '(85)3105-1355', ''),
(101, 185, 'Geral', '(85)3105-1355', ''),
(102, 186, 'Geral', '(85)3105-1355', ''),
(103, 189, 'Geral', '(85)3105-1355', ''),
(104, 191, 'Geral', '(85)3105-1314', ''),
(105, 192, 'Geral', '(85)3105-1354', ''),
(106, 193, 'Geral', '(85)3105-1354', ''),
(107, 194, 'Geral', '(85)3105-1354', ''),
(108, 196, 'Geral', '(85)3105-1357', ''),
(109, 197, 'Geral', '(85)3105-1355', ''),
(110, 198, 'Geral', '(85)3105-1355', ''),
(111, 199, 'Geral', '(85)3105-1355', ''),
(112, 200, 'Geral', '(85)3105-1354', ''),
(113, 201, 'Geral', '(85)3105-1354', ''),
(114, 203, 'Geral', '(85)3105-1285', ''),
(115, 210, 'Geral', '(85)3195-2727', ''),
(116, 214, 'Geral', '(85)3105-1247', ''),
(117, 215, 'Geral', '(85)4009-5293', ''),
(118, 216, 'Geral', '(85)3433-3749', ''),
(119, 219, 'Geral', '(85)3455-2716', ''),
(120, 221, 'Geral', '(85)3105-1501', ''),
(121, 223, 'Geral', '(85)3226-9818', ''),
(122, 224, 'Geral', '(85)3226-9818', ''),
(123, 225, 'Geral', '(19)3246-0100', ''),
(124, 226, 'Geral', '(85)3246-0100', ''),
(125, 227, 'Geral', '(85)3234-5422', ''),
(126, 228, 'Geral', '(85)3265-2238', ''),
(127, 230, 'Geral', '(85)3265-5114', ''),
(128, 231, 'Geral', '(85)3452-6999', ''),
(129, 232, 'Geral', '(85)3105-1237', ''),
(130, 233, 'Geral', '(85)3105-1237', ''),
(131, 234, 'Geral', '(85)3452-7281', ''),
(132, 238, 'Geral', '(85)3452-1651', ''),
(133, 239, 'Geral', '(85)3287-4314', ''),
(134, 241, 'Geral', '(85)3452-2320', ''),
(135, 242, 'Geral', '(85)3272-4861', ''),
(136, 243, 'Geral', '(85)3261-6268', ''),
(137, 248, 'Geral', '(85)3452-7274', ''),
(138, 254, 'Geral', '(85)3254-5848', ''),
(139, 258, 'Geral', '(85)3105-2721', ''),
(140, 261, 'Geral', '(85)3452-6776', ''),
(141, 262, 'Geral', '(85)3452-6768', ''),
(142, 263, 'Geral', '(58)3452-6778', ''),
(143, 264, 'Geral', '(85)3105-1146', ''),
(144, 266, 'Geral', '(85)3105-1146', ''),
(145, 268, 'Geral', '(85)3101-6710', ''),
(146, 269, 'Geral', '(85)3101-3969', ''),
(147, 271, 'Geral', '(85)3101-3969', ''),
(148, 272, 'Geral', '(85)3101-9071', ''),
(149, 273, 'Geral', '(85)3101-9420', ''),
(150, 274, 'Geral', '(85)3452-5773', ''),
(151, 275, 'Geral', '(85)3452-3495', ''),
(152, 276, 'Geral', '(85)3452-3495', ''),
(153, 277, 'Geral', '(85)3105-1118', ''),
(154, 279, 'Geral', '(85)3105-1241', ''),
(155, 280, 'Geral', '(85)3452-3477', ''),
(156, 282, 'Geral', '(85)3105-2041', ''),
(157, 283, 'Geral', '(85)3105-1263', ''),
(158, 284, 'Geral', '(85)3105-1263', ''),
(159, 285, 'Geral', '(85)3105-1247', ''),
(160, 286, 'Geral', '(85)3105-1247', ''),
(161, 288, 'Geral', '(85)3105-1247', ''),
(162, 292, 'Geral', '(85)3105-1233', ''),
(163, 293, 'Geral', '(85)3218-6523', ''),
(164, 295, 'Geral', '(85)3452-3495', ''),
(165, 296, 'Geral', '(85)3131-2100', ''),
(166, 298, 'Geral', '(85)3105-1434', ''),
(167, 301, 'Geral', '(85)3105-1434', ''),
(168, 303, 'Geral', '(85)3105-1077', ''),
(169, 311, 'Geral', '(85)3105-1073', ''),
(170, 313, 'Geral', '(85)3105-1109', ''),
(171, 314, 'Geral', '(85)3452-5255', ''),
(172, 319, 'Geral', '(85)3433-3779', ''),
(173, 320, 'Geral', '(85)3433-3749', ''),
(174, 322, 'Geral', '(85)3433-4570', ''),
(175, 323, 'Geral', '(85)3433-1941', ''),
(176, 325, 'Geral', '(85)3101-4525', ''),
(177, 327, 'Geral', '(85)3433-3653', ''),
(178, 328, 'Geral', '(85)3433-3749', ''),
(179, 329, 'Geral', '(85)9956-0737', ''),
(180, 330, 'Geral', '(85)3433-4570', ''),
(181, 334, 'Geral', '(85)3433-3637', ''),
(182, 339, 'Geral', '(85)3101-2186', ''),
(183, 340, 'Geral', '(85)3433-3656', ''),
(184, 341, 'Geral', '(85)3433-3624', ''),
(185, 342, 'Geral', '(85)3433-36651', ''),
(186, 343, 'Geral', '(85)3433-3670', ''),
(187, 345, 'Geral', '(85)3433-2507', ''),
(188, 348, 'Geral', '(85)3488-3104', ''),
(189, 352, 'Geral', '(85)3433-6883', ''),
(190, 355, 'Geral', '(85)3241-4755', ''),
(191, 358, 'Geral', '(85)3105-1323', ''),
(192, 359, 'Geral', '(85)3433-6894', ''),
(193, 360, 'Geral', '(85)3433-6864', ''),
(194, 362, 'Geral', '(85)3241-4868', ''),
(195, 365, 'Geral', '(85)3433-2520', ''),
(196, 366, 'Geral', '(85)3433-2520', ''),
(197, 367, 'Geral', '(85)3433-2548', ''),
(198, 368, 'Geral', '(85)3433-2860', ''),
(199, 370, 'Geral', '(85)3433-2807', ''),
(200, 372, 'Geral', '(85)3433-2902', ''),
(201, 373, 'Geral', '(85)3488-3101', ''),
(202, 374, 'Geral', '(85)3452-1936', ''),
(203, 375, 'Geral', '(85)3242-3081', ''),
(204, 376, 'Geral', '(85)3252-3081', ''),
(205, 377, 'Geral', '(85)3281-8804', ''),
(206, 381, 'Geral', '(85)3281-8804', ''),
(207, 384, 'Geral', '(85)3281-2570', ''),
(208, 388, 'Geral', '(85)3105-3442', ''),
(209, 390, 'Geral', '(85)3105-3445', ''),
(210, 392, 'Geral', '(85)3105-3416', ''),
(211, 399, 'Geral', '(85)3459-5590', ''),
(212, 400, 'Geral', '(85)3459-5904', ''),
(213, 405, 'Geral', '(85)3454-5960', ''),
(214, 407, 'Geral', '(85)3454-5960', ''),
(215, 408, 'Geral', '(85)3459-6761', ''),
(216, 409, 'Geral', '(85)3433-3588', ''),
(217, 411, 'Geral', '(85)3459-5984', ''),
(218, 412, 'Geral', '(85)3459-5916', ''),
(219, 413, 'Geral', '(85)3459-5927', ''),
(220, 414, 'Geral', '(85)3452-6611', ''),
(221, 421, 'Geral', '(85)3452-6954', ''),
(222, 422, 'Geral', '(85)3452-2357', ''),
(223, 423, 'Geral', '(85)3452-2357', ''),
(224, 424, 'Geral', '(85)3452-6984', ''),
(225, 432, 'Geral', '(85)3452-3535', ''),
(226, 434, 'Geral', '(85)3255-5053', ''),
(227, 436, 'Geral', '(85)3255-5042', ''),
(228, 446, 'Geral', '(85)3101-6512', ''),
(229, 447, 'Geral', '(85)3101-6561', ''),
(230, 448, 'Geral', '(85)3101-6551', ''),
(231, 449, 'Geral', '(85)3101-6544', ''),
(232, 450, 'Geral', '(85)3101-6576', ''),
(233, 452, 'Geral', '(85)3105-1450', ''),
(234, 453, 'Geral', '(85)3452-1987', ''),
(235, 454, 'Geral', '(85)3105-1457', ''),
(236, 455, 'Geral', '(85)3452-1653', ''),
(237, 456, 'Geral', '(85)3452-1652', ''),
(238, 457, 'Geral', '(85)4009-5290', ''),
(239, 458, 'Geral', '(85)4009-5290', ''),
(240, 459, 'Geral', '(85)4009-5290', ''),
(241, 460, 'Geral', '(85)4009-5291', ''),
(242, 461, 'Geral', '(85)4009-5292', ''),
(243, 7, 'Geral', '(85)3466-4880', ''),
(244, 11, 'Geral', '(85)3105-1446', ''),
(245, 30, 'Geral', '(85)3433-9717', ''),
(246, 32, 'Geral', '(85)3433-9734', ''),
(247, 42, 'Geral', '(85)3105-1441', ''),
(248, 61, 'Geral', '(85)3452-3430', ''),
(249, 73, 'Geral', '(85)3452-5373', ''),
(250, 75, 'Geral', '(85)3281-7132', ''),
(251, 77, 'Geral', '(85)3452-2349', ''),
(252, 79, 'Geral', '(85)3105-1448', ''),
(253, 80, 'Geral', '(85)3105-1364', ''),
(254, 82, 'Geral', '(85)3105-1371', ''),
(255, 84, 'Geral', '(85)3105-1442', ''),
(256, 92, 'Geral', '(85)3452-7296', ''),
(257, 96, 'Geral', '(85)3252-1630', ''),
(258, 112, 'Geral', '(85)3105-1456', ''),
(259, 114, 'Geral', '(85)3281-7132', ''),
(260, 118, 'Geral', '(85)3131-7619', ''),
(261, 123, 'Geral', '(85)3452-9299', ''),
(262, 124, 'Geral', '(85)3452-9322', ''),
(263, 125, 'Geral', '(85)3433-3742', ''),
(264, 131, 'Geral', '(85)3452-1651', ''),
(265, 132, 'Geral', '(85)3452-1651', ''),
(266, 136, 'Geral', '(85)3105-1373', ''),
(267, 137, 'Geral', '(85)3105-1369', ''),
(268, 145, 'Geral', '(85)3105-1366', ''),
(269, 147, 'Geral', '(85)3105-1378', ''),
(270, 156, 'Geral', '(85)3281-8804', ''),
(271, 159, 'Geral', '(85)3488-3377', ''),
(272, 166, 'Geral', '(85)3255-5205', ''),
(273, 168, 'Geral', '(85)3243-2960', ''),
(274, 177, 'Geral', '(85)3101-3523', ''),
(275, 179, 'Geral', '(85)3256-7044', ''),
(276, 180, 'Geral', '(85)3256-7044', ''),
(277, 182, 'Geral', '(85)3105-1355', ''),
(278, 187, 'Geral', '(85)3105-1355', ''),
(279, 204, 'Geral', '(85)3105-1393', ''),
(280, 205, 'Geral', '(85)3256-7044', ''),
(281, 206, 'Geral', '(85)3252-1797', ''),
(282, 218, 'Geral', '(85)3455-2702', ''),
(283, 229, 'Geral', '(85)3265-5114', ''),
(284, 236, 'Geral', '(85)3105-1136', ''),
(285, 237, 'Geral', '(85)3105-1188', ''),
(286, 244, 'Geral', '(85)3452-7275', ''),
(287, 252, 'Geral', '(85)3105-1573', ''),
(288, 255, 'Geral', '(85)3105-1309', ''),
(289, 257, 'Geral', '(85)3105-1350', ''),
(290, 259, 'Geral', '(85)3105-2710', ''),
(291, 267, 'Geral', '(85)3105-1294', ''),
(292, 270, 'Geral', '(85)3101-3963', ''),
(293, 299, 'Geral', '(85)3105-1438', ''),
(294, 302, 'Geral', '(85)3105-1440', ''),
(295, 305, 'Geral', '(85)3105-1080 ', ''),
(296, 306, 'Geral', '(85)3105-1082', ''),
(297, 310, 'Geral', '(85)3105-1079', ''),
(298, 317, 'Geral', '(85)3101-4457', ''),
(299, 318, 'Geral', '(85)3272-5053', ''),
(300, 321, 'Geral', '(85)3433-4728', ''),
(301, 335, 'Geral', '(85)3433-3644', ''),
(302, 349, 'Geral', '(85)3433-2917', ''),
(303, 351, 'Geral', '(85)3232-6021', ''),
(304, 353, 'Geral', '(85)3433-2918', ''),
(305, 354, 'Geral', '(85)3488-3116', ''),
(306, 379, 'Geral', '(85)3281-8151', ''),
(307, 385, 'Geral', '(85)3105-1514', ''),
(308, 386, 'Geral', '(85)3105-1513', ''),
(309, 394, 'Geral', '(85)3105-3708', ''),
(310, 395, 'Geral', '(85)3105-3440', ''),
(311, 397, 'Geral', '(85)3253-3911', ''),
(312, 398, 'Geral', '(85)3452-6901', ''),
(313, 403, 'Geral', '(85)3459-5933', ''),
(314, 404, 'Geral', '(85)3454-5960', ''),
(315, 417, 'Geral', '(85)3452-6992', ''),
(316, 418, 'Geral', '(85)3452-6992', ''),
(317, 419, 'Geral', '(85)3452-6992', ''),
(318, 426, 'Geral', '(85)3452-6600', ''),
(319, 443, 'Geral', '(85)3452-6605', ''),
(320, 7, 'Geral', '(85)3466-4881', ''),
(321, 11, 'Geral', '(85)3105-1447', ''),
(322, 30, 'Geral', '(85)3433-9734', ''),
(323, 32, 'Geral', '(85)3433-9732', ''),
(324, 42, 'Geral', '(85)3105-1446', ''),
(325, 61, 'Geral', '(85)3452-3472', ''),
(326, 73, 'Geral', '(85)3452-5371', ''),
(327, 75, 'Geral', '(85)3281-6229', ''),
(328, 77, 'Geral', '(85)3452-2345', ''),
(329, 79, 'Geral', '(85)3452-7299', ''),
(330, 80, 'Geral', '(85)3105-1365', ''),
(331, 80, 'Geral', '(85)3105-1366', ''),
(332, 82, 'Geral', '(85)3105-1013', ''),
(333, 84, 'Geral', '(85)3105-1446', ''),
(334, 92, 'Geral', '(85)3452-7283', ''),
(335, 96, 'Geral', '(85)3452-3477', ''),
(336, 112, 'Geral', '(85)3105-1472', ''),
(337, 114, 'Geral', '(85)3281-6229', ''),
(338, 118, 'Geral', '(85)3131-7604', ''),
(339, 123, 'Geral', '(85)3452-9322', ''),
(340, 123, 'Geral', '(85)3452-9252', ''),
(341, 124, 'Geral', '(85)3452-9252', ''),
(342, 124, 'Geral', '(85)3452-9205', ''),
(343, 125, 'Geral', '(85)3433-3748', ''),
(344, 131, 'Geral', '(85)3452-2116', ''),
(345, 131, 'Geral', '(85)3452-2112', ''),
(346, 132, 'Geral', '(85)3452-1656', ''),
(347, 136, 'Geral', '(85)3105-1374', ''),
(348, 137, 'Geral', '(85)3105-1369', ''),
(349, 145, 'Geral', '(85)3105-1365', ''),
(350, 147, 'Geral', '(85)3105-1167', ''),
(351, 156, 'Geral', '(85)3281-8151', ''),
(352, 159, 'Geral', '(85)3488-3376', ''),
(353, 166, 'Geral', '(85)3255-5206', ''),
(354, 166, 'Geral', '(85)3255-3255', ''),
(355, 168, 'Geral', '(85)3243-2961', ''),
(356, 177, 'Geral', '(85)3101-3518', ''),
(357, 179, 'Geral', '(85)3256-2390', ''),
(358, 180, 'Geral', '(85)3256-2390', ''),
(359, 182, 'Geral', '(85)3232-0645', ''),
(360, 187, 'Geral', '(85)3105-1355', ''),
(361, 204, 'Geral', '(85)3252-1797', ''),
(362, 204, 'Geral', '(85)3252-1776', ''),
(363, 205, 'Geral', '(85)3256-2390', ''),
(364, 206, 'Geral', '(85)3252-1776', ''),
(365, 218, 'Geral', '(85)3455-2700', ''),
(366, 229, 'Geral', '(85)3265-5977', ''),
(367, 236, 'Geral', '(85)3105-1296', ''),
(368, 237, 'Geral', '(85)3105-1296', ''),
(369, 237, 'Geral', '(85)3105-1136', ''),
(370, 244, 'Geral', '(85)3261-6268', ''),
(371, 252, 'Geral', '(85)3105-1574', ''),
(372, 255, 'Geral', '(85)3254-5848', ''),
(373, 257, 'Geral', '(85)3105-1309', ''),
(374, 259, 'Geral', '(85)3105-2711', ''),
(375, 267, 'Geral', '(85)3105-1146', ''),
(376, 270, 'Geral', '(85)3101-3969', ''),
(377, 299, 'Geral', '(85)3105-1437', ''),
(378, 302, 'Geral', '(85)3105-1434', ''),
(379, 305, 'Geral', '(85)3105-1079', ''),
(380, 306, 'Geral', '(85)3105-1089', ''),
(381, 310, 'Geral', '(85)3105-1089', ''),
(382, 310, 'Geral', '(85)3105-1080', ''),
(383, 317, 'Geral', '(85)3101-4427', ''),
(384, 318, 'Geral', '(85)3433-3644', ''),
(385, 321, 'Geral', '(85)3433-1941', ''),
(386, 335, 'Geral', '(85)3433-3637', ''),
(387, 349, 'Geral', '(85)3433-2916', ''),
(388, 349, 'Geral', '(85)3433-2919', ''),
(389, 349, 'Geral', '(85)3433-7285', ''),
(390, 351, 'Geral', '(85)3433-2802', ''),
(391, 353, 'Geral', '(85)3433-2916', ''),
(392, 353, 'Geral', '(85)3433-2916', ''),
(393, 353, 'Geral', '(85)3433-2919', ''),
(394, 354, 'Geral', '(85)3488-3170', ''),
(395, 379, 'Geral', '(85)3281-8804', ''),
(396, 385, 'Geral', '(85)3105-1535', ''),
(397, 386, 'Geral', '(85)3105-1514', ''),
(398, 394, 'Geral', '(85)3105-3711', ''),
(399, 395, 'Geral', '(85)3105-3708', ''),
(400, 395, 'Geral', '(85)3105-3445', ''),
(401, 395, 'Geral', '(85)3105-3711', ''),
(402, 397, 'Geral', '(85)3452-6901', ''),
(403, 397, 'Geral', '(85)3452-6903', ''),
(404, 398, 'Geral', '(85)3452-6903', ''),
(405, 403, 'Geral', '(85)5993-5941', ''),
(406, 404, 'Geral', '(85)3454-5993', ''),
(407, 404, 'Geral', '(85)3454-5941', ''),
(408, 417, 'Geral', '(85)3452-6604', ''),
(409, 417, 'Geral', '(85)3452-6605', ''),
(410, 418, 'Geral', '(85)3452-6604', ''),
(411, 418, 'Geral', '(85)3452-6605', ''),
(412, 419, 'Geral', '(85)3452-6604', ''),
(413, 419, 'Geral', '(85)3452-6605', ''),
(414, 419, 'Geral', '(85)3452-6611', ''),
(415, 426, 'Geral', '(85)3452-6602', ''),
(416, 443, 'Geral', '(85)3452-6604', ''),
(417, 443, 'Geral', '(85)3452-1786', ''),
(418, 281, 'Geral', '(85)3105-1239', ''),
(419, 315, 'Geral', '(85)3452-6903', ''),
(420, 347, 'Geral', '(85)3433-6856', ''),
(421, 35, 'Geral', '(85)3216-7967', ''),
(422, 35, 'Geral', '(85)3216-7976', ''),
(423, 64, 'Geral', '(85)3452-6773', ''),
(424, 64, 'Geral', '(85)3452-6777', ''),
(425, 165, 'Geral', '(85)3255-5180', ''),
(426, 165, 'Geral', '(85)3255-5081 ', ''),
(427, 213, 'Geral', '(85)3305-4747', ''),
(428, 213, 'Geral', '(85)3305-4749', ''),
(429, 240, 'Geral', '(85)3488-9248', ''),
(430, 240, 'Geral', '(85)3105-1355', ''),
(431, 253, 'Geral', '(85)3452-2320', ''),
(432, 256, 'Geral', '(85)3105-1309', ''),
(433, 265, 'Geral', '(85)3105-1146', ''),
(434, 287, 'Geral', '(85)3452-3495', ''),
(435, 287, 'Geral', '(85)3105-1240', ''),
(436, 316, 'Geral', '(85)3105-3711', ''),
(437, 324, 'Geral', '(85)3433-3644 ', ''),
(438, 326, 'Geral', '(85)3433-3644 ', ''),
(439, 331, 'Geral', '(85)3252-4833', ''),
(440, 331, 'Geral', '(85)3101-2186', ''),
(441, 346, 'Geral', '(85)3433 -6883', ''),
(442, 378, 'Geral', '(85)3281-8151', ''),
(443, 420, 'Geral', '(85)3452-2357', ''),
(444, 420, 'Geral', '(85)3105-1493', ''),
(445, 444, 'Geral', '(85)3488-6966', ''),
(446, 444, 'Geral', '(85)3488-6973', ''),
(447, 1, 'Celular', '(85)9981-7163', ''),
(448, 2, 'Celular', '(85)8821-5525', ''),
(449, 4, 'Celular', '(85)8970-4549', ''),
(450, 5, 'Celular', '(85)9984-0577', ''),
(451, 8, 'Celular', '(85)8895-5682', ''),
(452, 15, 'Celular', '(85)9991-9718', ''),
(453, 16, 'Celular', '(85)8730-2148', ''),
(454, 17, 'Celular', '(85)9197-3602', ''),
(455, 18, 'Celular', '(85)8886-5132', ''),
(456, 19, 'Celular', '(85)9998-9893', ''),
(457, 19, 'Celular', '(85)8833-0682', ''),
(458, 23, 'Celular', '(85)9181-3223', ''),
(459, 24, 'Celular', '(85)9693-5300', ''),
(460, 24, 'Celular', '(85)9693-5300', ''),
(461, 26, 'Celular', '(85)9900-2688', ''),
(462, 35, 'Celular', '(85)9603-8001', ''),
(463, 36, 'Celular', '(85)8802-8529', ''),
(464, 37, 'Celular', '(85)8703-7831', ''),
(465, 38, 'Celular', '(85)8916-4876', ''),
(466, 39, 'Celular', '(85)8772-1419', ''),
(467, 40, 'Celular', '(85)8838-4420', ''),
(468, 43, 'Celular', '(85)9206-3297', ''),
(469, 44, 'Celular', '(85)9175-3703', ''),
(470, 45, 'Celular', '(85)9749-0401', ''),
(471, 46, 'Celular', '(85)3105-1157', ''),
(472, 47, 'Celular', '(85)9932-3876', ''),
(473, 48, 'Celular', '(85)8868-7070', ''),
(474, 49, 'Celular', '(85)8970-4864', ''),
(475, 50, 'Celular', '(85)9997-8951', ''),
(476, 52, 'Celular', '(85)9994-5287', ''),
(477, 53, 'Celular', '(85)8898-5353', ''),
(478, 54, 'Celular', '(85)8970-3033', ''),
(479, 55, 'Celular', '(85)8970-6139', ''),
(480, 56, 'Celular', '(85)8970-4071', ''),
(481, 56, 'Celular', '(85)9996-3221', ''),
(482, 57, 'Celular', '(85)8687-2577', ''),
(483, 58, 'Celular', '(85)9725-1730', ''),
(484, 59, 'Celular', '(85)8970-3494', ''),
(485, 60, 'Celular', '(85)8630-3442', ''),
(486, 62, 'Celular', '(85)8970-3726', ''),
(487, 64, 'Celular', '(85)9813-2814', ''),
(488, 66, 'Celular', '(85)8819-1153', ''),
(489, 67, 'Celular', '(85)8965-4460', ''),
(490, 71, 'Celular', '(85)8840-7777', ''),
(491, 86, 'Celular', '(85)8970-3031', ''),
(492, 87, 'Celular', '(85)8808-1158', ''),
(493, 90, 'Celular', '(85)8794-1119', ''),
(494, 91, 'Celular', '(85)8888-0103', ''),
(495, 95, 'Celular', '(85)8890-9945', ''),
(496, 100, 'Celular', '(85)8657-4243', ''),
(497, 103, 'Celular', '(85)8818-5791', ''),
(498, 109, 'Celular', '(61)9276-8364', ''),
(499, 110, 'Celular', '(85)8868-7070', ''),
(500, 114, 'Celular', '(85)8713-4300', ''),
(501, 133, 'Celular', '(85)8543-5484', ''),
(502, 134, 'Celular', '(85)8768-8997', ''),
(503, 135, 'Celular', '(85)8890-9944', ''),
(504, 140, 'Celular', '(85)8710-7196', ''),
(505, 140, 'Celular', '(85)8863-4308', ''),
(506, 140, 'Celular', '(85)9764-9333', ''),
(507, 152, 'Celular', '(85)8888-2601', ''),
(508, 154, 'Celular', '(85)8788-1927', ''),
(509, 157, 'Celular', '(85)8867-9277', ''),
(510, 158, 'Celular', '(85)8879-7623', ''),
(511, 161, 'Celular', '(85)8105-8070', ''),
(512, 162, 'Celular', '(85)8102-2854', ''),
(513, 163, 'Celular', '(85)9970-3890', ''),
(514, 163, 'Celular', '(85)8162-7874', ''),
(515, 164, 'Celular', '(85)8150-8070', ''),
(516, 165, 'Celular', '(85)9996-4447', ''),
(517, 167, 'Celular', '(85)8728-0863', ''),
(518, 170, 'Celular', '(61)8406-8667', ''),
(519, 171, 'Celular', '(61)9929-9701', ''),
(520, 172, 'Celular', '(61)9943-5472', ''),
(521, 172, 'Celular', '(61)9233-5472', ''),
(522, 172, 'Celular', '(85)8203-6161', ''),
(523, 178, 'Celular', '(85)9624-4608', ''),
(524, 181, 'Celular', '(85)9983-2400', ''),
(525, 181, 'Celular', '(85)8814-1229', ''),
(526, 182, 'Celular', '(85)9627-8697', ''),
(527, 184, 'Celular', '(85)9998-9438', ''),
(528, 185, 'Celular', '(85)9635-3556', ''),
(529, 186, 'Celular', '(85)9621-7016', ''),
(530, 187, 'Celular', '(85)8815-1976', ''),
(531, 188, 'Celular', '(85)8811-3338', ''),
(532, 189, 'Celular', '(85)8970-4354', ''),
(533, 191, 'Celular', '(85)9938-8369', ''),
(534, 194, 'Celular', '(85)9799-9991', ''),
(535, 194, 'Celular', '(85)9766-3119', ''),
(536, 195, 'Celular', '(85)9136-9382', ''),
(537, 195, 'Celular', '(85)8970-4618', ''),
(538, 196, 'Celular', '(85)8970-3818', ''),
(539, 197, 'Celular', '(85)9748-7345', ''),
(540, 198, 'Celular', '(85)9927-5721', ''),
(541, 199, 'Celular', '(85)8741-7219', ''),
(542, 199, 'Celular', '(85)9901-9793', ''),
(543, 201, 'Celular', '(85)8805-7378', ''),
(544, 201, 'Celular', '(85)8970-4619', ''),
(545, 202, 'Celular', '(85)8897-0581', ''),
(546, 207, 'Celular', '(85)8619-0958', ''),
(547, 207, 'Celular', '(85)9939-6881', ''),
(548, 208, 'Celular', '(85)8970-7740', ''),
(549, 208, 'Celular', '(85)8970-7780', ''),
(550, 209, 'Celular', '(85)8970-4074', ''),
(551, 209, 'Celular', '(85)8680-5901', ''),
(552, 211, 'Celular', '(85)8970-1892', ''),
(553, 212, 'Celular', '(85)8628-6016', ''),
(554, 213, 'Celular', '(85)9982-3893', ''),
(555, 215, 'Celular', '(85)8122-1100', ''),
(556, 216, 'Celular', '(85)8970-3492', ''),
(557, 217, 'Celular', '(85)8675-0182', ''),
(558, 218, 'Celular', '(85)8802-0175', ''),
(559, 219, 'Celular', '(85)8804-0876', ''),
(560, 220, 'Celular', '(85)8906-5957', ''),
(561, 220, 'Celular', '(85)9950-4273', ''),
(562, 222, 'Celular', '(85)8664-9574', ''),
(563, 222, 'Celular', '(85)9993-0222', ''),
(564, 223, 'Celular', '(85)8820-9278', ''),
(565, 223, 'Celular', '(19)99766-2513', ''),
(566, 224, 'Celular', '(19)9619-2051', ''),
(567, 224, 'Celular', '(85)9669-7302', ''),
(568, 225, 'Celular', '(19)99604-8446', ''),
(569, 231, 'Celular', '(85)8657-2291', ''),
(570, 232, 'Celular', '(85)8843-2409', ''),
(571, 235, 'Celular', '(85)9989-5091', ''),
(572, 242, 'Celular', '(85)8519-1386', ''),
(573, 242, 'Celular', '(85)8970-4079', ''),
(574, 245, 'Celular', '(85)8970-4079', ''),
(575, 246, 'Celular', '(85)8897-7182', ''),
(576, 247, 'Celular', '(85)9996-1805', ''),
(577, 247, 'Celular', '(85)8708-3004', ''),
(578, 248, 'Celular', '(85)8898-3494', ''),
(579, 249, 'Celular', '(85)8970-2062', ''),
(580, 249, 'Celular', '(85)9992-7295', ''),
(581, 251, 'Celular', '(85)8501-6618', ''),
(582, 253, 'Celular', '(85)8970-2222', ''),
(583, 256, 'Celular', '(85)8898-9922', ''),
(584, 259, 'Celular', '(85)9707-0033', ''),
(585, 260, 'Celular', '(85)8814-8208', ''),
(586, 263, 'Celular', '(85)8970-6144', ''),
(587, 265, 'Celular', '(85)8970-4530', ''),
(588, 265, 'Celular', '(85)9994-1963', ''),
(589, 266, 'Celular', '(85)8970-2020', ''),
(590, 274, 'Celular', '(85)8757-5057', ''),
(591, 276, 'Celular', '(85)9718-4400', ''),
(592, 277, 'Celular', '(85)8888-8669', ''),
(593, 280, 'Celular', '(85)9133-9580', ''),
(594, 281, 'Celular', '(85)8970-2892', ''),
(595, 287, 'Celular', '(85)9164-2994', ''),
(596, 289, 'Celular', '(85)9954-0186', ''),
(597, 289, 'Celular', '(85)3105-1267', ''),
(598, 290, 'Celular', '(85)3452-3495', ''),
(599, 291, 'Celular', '(85)9760-5069', ''),
(600, 292, 'Celular', '(85)9920-5555', ''),
(601, 292, 'Celular', '(85)8888-0076', ''),
(602, 293, 'Celular', '(85)9936-6587', ''),
(603, 294, 'Celular', '(85)9902-1532', ''),
(604, 295, 'Celular', '(85)8879-9097', ''),
(605, 297, 'Celular', '(85)8970-6138', ''),
(606, 297, 'Celular', '(85)8671-4000', ''),
(607, 300, 'Celular', '(85)8970-3039', ''),
(608, 304, 'Celular', '(85)8878-7781', ''),
(609, 307, 'Celular', '(85)9679-6000', ''),
(610, 308, 'Celular', '(85)9679-6000', ''),
(611, 309, 'Celular', '(85)8970-2956', ''),
(612, 312, 'Celular', '(85)9925-2332', ''),
(613, 313, 'Celular', '(85)9994-1200', ''),
(614, 314, 'Celular', '(85)8970-3804', ''),
(615, 315, 'Celular', '(85)8970-2424', ''),
(616, 316, 'Celular', '(85)8970-3032', ''),
(617, 319, 'Celular', '(85)8956-3779', ''),
(618, 321, 'Celular', '(85)8970-4060', ''),
(619, 321, 'Celular', '(85)8606-9677', ''),
(620, 323, 'Celular', '(85)8754-9950', ''),
(621, 326, 'Celular', '(85)8970-3033', ''),
(622, 330, 'Celular', '(85)8802-9144', ''),
(623, 332, 'Celular', '(85)8614-0440', ''),
(624, 333, 'Celular', '(85)8807-8003', ''),
(625, 333, 'Celular', '(85)9612-5917', ''),
(626, 336, 'Celular', '(85)8868-9784', ''),
(627, 337, 'Celular', '(85)8890-9943', ''),
(628, 338, 'Celular', '(85)8678-8115', ''),
(629, 339, 'Celular', '(85)8563-3726', ''),
(630, 340, 'Celular', '(85)8899-8084', ''),
(631, 342, 'Celular', '(85)8850-2154', ''),
(632, 343, 'Celular', '(85)8898-9747', ''),
(633, 344, 'Celular', '(85)8814-3430', ''),
(634, 346, 'Celular', '(85)8970-3024', ''),
(635, 347, 'Celular', '(85)8970-3025', ''),
(636, 350, 'Celular', '(85)8970-3019', ''),
(637, 357, 'Celular', '(85)8682-2164', ''),
(638, 358, 'Celular', '(85)8697-3100', ''),
(639, 359, 'Celular', '(85)8898-4499', ''),
(640, 360, 'Celular', '(85)9924-8901', ''),
(641, 361, 'Celular', '(85)8970-2068', ''),
(642, 361, 'Celular', '(85)9614-9038', ''),
(643, 362, 'Celular', '(85)8723-0810', ''),
(644, 363, 'Celular', '(85)9624-3512', ''),
(645, 364, 'Celular', '(85)8970-2065', ''),
(646, 365, 'Celular', '(85)9997-3143', ''),
(647, 366, 'Celular', '(85)8689-2878', ''),
(648, 367, 'Celular', '(85)9983-9755', ''),
(649, 369, 'Celular', '(85)9723-3068', ''),
(650, 370, 'Celular', '(85)8814-8058', ''),
(651, 371, 'Celular', '(85)9905-7591', ''),
(652, 372, 'Celular', '(85)8570-2709', ''),
(653, 373, 'Celular', '(85)8591-2150', ''),
(654, 374, 'Celular', '(85)8603-1020', ''),
(655, 374, 'Celular', '(85)8970-3486', ''),
(656, 377, 'Celular', '(85)8865-2007', ''),
(657, 378, 'Celular', '(85)8531-9363', ''),
(658, 382, 'Celular', '(85)8750-3556', ''),
(659, 384, 'Celular', '(85)8869-0679', ''),
(660, 387, 'Celular', '(85)8715-1197', ''),
(661, 388, 'Celular', '(85)8970-3506', ''),
(662, 389, 'Celular', '(85)8600-6059', ''),
(663, 390, 'Celular', '(85)8203-1510', ''),
(664, 391, 'Celular', '(85)9630-9342', ''),
(665, 391, 'Celular', '(85)8970-4614', ''),
(666, 392, 'Celular', '(85)8600-6059', ''),
(667, 393, 'Celular', '(85)8970-3548', ''),
(668, 396, 'Celular', '(85)8847-1120', ''),
(669, 402, 'Celular', '(85)8943-6146', ''),
(670, 402, 'Celular', '(85)8732-1286', ''),
(671, 402, 'Celular', '(85)9717-2632', ''),
(672, 404, 'Celular', '(85)8970-2045', ''),
(673, 405, 'Celular', '(85)8834-6934', ''),
(674, 407, 'Celular', '(85)8723-3280', ''),
(675, 408, 'Celular', '(85)9955-9120', ''),
(676, 409, 'Celular', '(85)8543-4787', ''),
(677, 411, 'Celular', '(85)8970 -2102', ''),
(678, 415, 'Celular', '(85)8970-3273', ''),
(679, 415, 'Celular', '(85)8970-3273', ''),
(680, 416, 'Celular', '(85)8690-7644', ''),
(681, 418, 'Celular', '(85)9989-8421', ''),
(682, 419, 'Celular', '(85)8807-8123', ''),
(683, 421, 'Celular', '(85)8623-4245', ''),
(684, 422, 'Celular', '(85)9925-9506', ''),
(685, 424, 'Celular', '(85)8970-4627', ''),
(686, 425, 'Celular', '(85)8699-7339', ''),
(687, 425, 'Celular', '(85)8970-3556', ''),
(688, 426, 'Celular', '(85)8859-5407', ''),
(689, 427, 'Celular', '(85)8864-6196', ''),
(690, 428, 'Celular', '(85)9969-7349', ''),
(691, 429, 'Celular', '(85)8844-1600', ''),
(692, 430, 'Celular', '(85)8800-5420', ''),
(693, 431, 'Celular', '(85)8970-4074', ''),
(694, 431, 'Celular', '(85)8680-5901', ''),
(695, 432, 'Celular', '(85)8822-7212', ''),
(696, 433, 'Celular', '(85)8563-2627', ''),
(697, 434, 'Celular', '(85)9611-9133', ''),
(698, 435, 'Celular', '(85)8789-1889', ''),
(699, 436, 'Celular', '(85)9954-1964', ''),
(700, 437, 'Celular', '(85)8906-2139', ''),
(701, 438, 'Celular', '(85)8771-7325', ''),
(702, 439, 'Celular', '(85)8588-8486', ''),
(703, 439, 'Celular', '(85)9731-7329', ''),
(704, 440, 'Celular', '(85)8537-0739', ''),
(705, 441, 'Celular', '(85)8652-8052', ''),
(706, 442, 'Celular', '(85)8827-2903', ''),
(707, 444, 'Celular', '(85)8827-2903', ''),
(708, 445, 'Celular', '(85)8841-0332', ''),
(709, 445, 'Celular', '(85)8749-0118', ''),
(710, 447, 'Celular', '(85)8841-0332', ''),
(711, 451, 'Celular', '(21)982588285', ''),
(712, 457, 'Celular', '(85)9728-8889', ''),
(713, 458, 'Celular', '(85)9728-8889', ''),
(714, 459, 'Celular', '(85)9728-9394', ''),
(715, 460, 'Celular', '(85)9986-8522', ''),
(716, 461, 'Celular', '(85)9943-2839', ''),
(717, 463, 'Celular', '(85)9998-9438', ''),
(718, 464, 'Celular', '(85)9757-6981', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `envolvido_projeto`
--

CREATE TABLE IF NOT EXISTS `envolvido_projeto` (
  `id_envolvido` int(11) NOT NULL,
  `id_projeto` int(11) DEFAULT NULL,
  `id_etapa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `etapas_projeto`
--

CREATE TABLE IF NOT EXISTS `etapas_projeto` (
`id_etapa` int(11) NOT NULL,
  `id_projeto` int(11) DEFAULT NULL,
  `titulo_etapa` varchar(255) DEFAULT NULL,
  `data_inicio` datetime DEFAULT NULL,
  `data_termino` datetime DEFAULT NULL,
  `descricao` longtext,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `etapas_projeto`
--

INSERT INTO `etapas_projeto` (`id_etapa`, `id_projeto`, `titulo_etapa`, `data_inicio`, `data_termino`, `descricao`, `status`) VALUES
(2, 3, 'Etapa do Projeto', '2014-12-01 08:00:00', '2014-12-05 17:35:36', 'Descrição da Etapa', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ligacoes`
--

CREATE TABLE IF NOT EXISTS `ligacoes` (
`id_ligacao` int(5) NOT NULL,
  `membro` varchar(255) NOT NULL,
  `destinatario` varchar(255) NOT NULL,
  `assunto` varchar(255) NOT NULL,
  `data_hora` datetime NOT NULL,
  `status_ligacao` enum('Realizado','Remarcado','Pendente','Cancelado') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `ligacoes`
--

INSERT INTO `ligacoes` (`id_ligacao`, `membro`, `destinatario`, `assunto`, `data_hora`, `status_ligacao`) VALUES
(5, 'Responsável', 'Destinatário', 'Assunto novo', '2014-11-25 14:47:36', 'Realizado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ligacoes_log`
--

CREATE TABLE IF NOT EXISTS `ligacoes_log` (
`id_log` int(11) NOT NULL,
  `id_ligacao` int(11) NOT NULL,
  `data_log` datetime NOT NULL,
  `duracao` varchar(255) NOT NULL,
  `nota` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `ligacoes_log`
--

INSERT INTO `ligacoes_log` (`id_log`, `id_ligacao`, `data_log`, `duracao`, `nota`) VALUES
(1, 5, '2014-11-16 07:25:37', '10:00', 'Uma anotação sobre a ligação'),
(2, 5, '2014-11-17 05:20:30', '15:00', 'outra anotação'),
(3, 5, '2014-11-16 23:54:38', '15:00', '123456');

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_users`
--

CREATE TABLE IF NOT EXISTS `log_users` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `datahora` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Extraindo dados da tabela `log_users`
--

INSERT INTO `log_users` (`id`, `id_user`, `descricao`, `datahora`) VALUES
(1, 1, 'Descricao', '2014-06-17 05:15:25'),
(2, 1, 'editou UNIDADE ORÇAMENTÁRIA &quot;01101&quot; para &quot;C&Acirc;MARA MUNICIPAL DE FORTALEZA&quot;', '2014-06-17 23:03:34'),
(3, 1, 'editou UNIDADE ORÇAMENTÁRIA &quot;01101&quot; para &quot;C&Acirc;MARA MUNICIPAL DE FORTALEZA&quot;', '2014-06-24 18:53:43'),
(4, 1, 'editou USUÁRIO &quot;Marcio Seabra&quot; tipo &quot;A&quot;', '2014-06-24 21:49:14'),
(5, 4, 'editou AÇÃO &quot;24&quot; para &quot;&quot;', '2014-06-24 22:03:54'),
(6, 4, 'editou META FÍSICA &quot;24&quot;', '2014-06-24 22:06:48'),
(7, 1, 'editou EIXO &quot;001&quot; para &quot;MELHORIA DA QUALIDADE DE VIDA E JUSTI&Ccedil;A SOCIAL&quot;', '2014-06-25 09:01:38'),
(8, 1, 'editou EIXO &quot;001&quot; para &quot;MELHORIA DA QUALIDADE DE VIDA E JUSTI&Ccedil;A SOCIAL 1&quot;', '2014-06-25 09:01:49'),
(9, 1, 'editou EIXO &quot;001&quot; para &quot;MELHORIA DA QUALIDADE DE VIDA E JUSTI&Ccedil;A SOCIAL&quot;', '2014-06-25 09:01:56'),
(10, 1, 'editou USUÁRIO &quot;Usu&aacute;rio Editor&quot; tipo &quot;U&quot;', '2014-06-27 16:03:29'),
(11, 1, 'editou META FÍSICA &quot;15&quot;', '2014-06-30 15:34:50'),
(12, 1, 'editou META FÍSICA &quot;16&quot;', '2014-06-30 15:35:02'),
(13, 1, 'editou META FÍSICA &quot;17&quot;', '2014-06-30 15:35:10'),
(14, 1, 'editou META FÍSICA &quot;18&quot;', '2014-06-30 15:35:20'),
(15, 1, 'editou META FÍSICA &quot;15&quot;', '2014-06-30 15:36:58'),
(16, 1, 'editou META FÍSICA &quot;16&quot;', '2014-06-30 15:37:06'),
(17, 1, 'editou META FÍSICA &quot;17&quot;', '2014-06-30 15:37:15'),
(18, 1, 'editou META FÍSICA &quot;18&quot;', '2014-06-30 15:37:24'),
(19, 1, 'editou META FÍSICA &quot;19&quot;', '2014-06-30 15:37:34'),
(20, 1, 'editou META FÍSICA &quot;24&quot;', '2014-06-30 15:37:53'),
(21, 1, 'editou META FÍSICA &quot;15&quot;', '2014-06-30 15:39:11'),
(22, 1, 'editou META FÍSICA &quot;16&quot;', '2014-06-30 15:39:22'),
(23, 1, 'editou META FÍSICA &quot;17&quot;', '2014-06-30 15:39:28'),
(24, 1, 'editou META FÍSICA &quot;18&quot;', '2014-06-30 15:39:37'),
(25, 1, 'editou META FÍSICA &quot;19&quot;', '2014-06-30 15:39:45'),
(26, 1, 'editou META FÍSICA &quot;24&quot;', '2014-06-30 15:40:12'),
(27, 1, 'adicionou META FÍSICA para o projeto &quot;1&quot;', '2014-07-05 21:53:21'),
(28, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:31:12'),
(29, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:42:45'),
(30, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:42:50'),
(31, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:42:59'),
(32, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 13:43:25'),
(33, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 14:10:15'),
(34, 1, 'editou META FÍSICA &quot;6&quot;', '2014-07-23 14:10:28'),
(35, 1, 'editou META FÍSICA &quot;3&quot;', '2014-07-23 14:21:23'),
(36, 1, 'editou USUÁRIO &quot;Marcio Seabra&quot; tipo &quot;A&quot;', '2014-08-14 10:35:50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `orgao`
--

CREATE TABLE IF NOT EXISTS `orgao` (
`codigo` int(11) NOT NULL,
  `orgao` varchar(2) DEFAULT NULL,
  `orgaoSefin` varchar(2) DEFAULT NULL,
  `unorc` varchar(5) DEFAULT NULL,
  `gestor` varchar(2) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `sigla` varchar(12) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Extraindo dados da tabela `orgao`
--

INSERT INTO `orgao` (`codigo`, `orgao`, `orgaoSefin`, `unorc`, `gestor`, `descricao`, `sigla`) VALUES
(1, '01', '01', '01101', '01', 'C&Acirc;MARA MUNICIPAL DE FORTALEZA', NULL),
(2, NULL, '53', '01901', '01', 'FUNDO ESPECIAL DA CÂMARA MUNICIPAL DE FORTALEZA', NULL),
(3, '11', '11', '11101', '11', 'GABINETE DO PREFEITO', NULL),
(4, NULL, '78', '11202', '11', 'INSTITUTO DE PLANEJAMENTO DE FORTALEZA', NULL),
(5, NULL, '84', '11203', '11', 'FUNDAÇÃO DE DESENVOLVIMENTO HABITACIONAL DE FORTALEZA', NULL),
(6, NULL, '82', '11901', '11', 'FUNDO MUNICIPAL DE JUVENTUDE DE FORTALEZA', NULL),
(7, '12', '12', '12101', '12', 'GABINETE DO VICE-PREFEITO', NULL),
(8, '13', '13', '13101', '13', 'PROCURADORIA GERAL DO MUNICÍPIO', NULL),
(9, NULL, '88', '13201', '13', 'AUTARQUIA DE REGULAÇÃO, FISCALIZAÇÃO E CONTROLE DOS SERVIÇOS PÚBLICOS DE SANEAMENTO AMBIENTAL', NULL),
(10, NULL, '89', '13901', '13', 'FUNDO DE APERFEIÇOAMENTO DA PROCURADORIA GERAL DO MUNICÍPIO', NULL),
(11, '15', '15', '15101', '15', 'SECRETARIA MUNICIPAL DE GOVERNO', NULL),
(12, '16', '16', '16101', '16', 'SECRETARIA DA CONTROLADORIA E TRANSPARÊNCIA', NULL),
(13, '17', '17', '17101', '17', 'SECRETARIA MUNICIPAL DE SEGURANÇA CIDADÃ', NULL),
(14, NULL, '97', '17102', '17', 'GUARDA MUNICIPAL DE FORTALEZA', NULL),
(15, '18', '18', '18101', '18', 'SECRETARIA MUNICIPAL DE PLANEJAMENTO, ORÇAMENTO  E GESTÃO', NULL),
(16, NULL, '62', '18201', '18', 'INSTITUTO MUNICIPAL DE PESQUISAS, ADMINISTRAÇÃO E RECURSOS HUMANOS', NULL),
(17, NULL, '67', '18202', '18', 'INSTITUTO DE PREVIDÊNCIA DO MUNICÍPIO - PREVFOR', NULL),
(18, NULL, '68', '18203', '18', 'INSTITUTO DE PREVIDÊNCIA DO MUNICÍPIO - SAÚDE', NULL),
(19, '19', '19', '19101', '19', 'SECRETARIA MUNICIPAL DE CONSERVAÇÃO E SERVIÇOS PÚBLICOS', NULL),
(20, NULL, '63', '19201', '19', 'AUTARQUIA MUNICIPAL DE TRÂNSITO, SERVIÇOS PÚBLICOS E CIDADANIA DE FORTALEZA', NULL),
(21, NULL, '69', '19202', '19', 'EMPRESA MUNICIPAL DE LIMPEZA E URBANIZAÇÃO', NULL),
(22, NULL, '87', '19203', '19', 'INSTITUTO DE PESOS E MEDIDAS DE FORTALEZA', NULL),
(25, NULL, '70', '19901', '19', 'FUNDO MUNICIPAL DE LIMPEZA URBANA', NULL),
(26, '23', '23', '23101', '23', 'SECRETARIA MUNICIPAL DE FINANÇAS', NULL),
(27, NULL, '37', '24901', '24', 'FUNDO MUNICIPAL DE EDUCAÇÃO', NULL),
(28, NULL, '36', '25201', '25', 'INSTITUTO DR. JOSÉ FROTA', NULL),
(29, NULL, '72', '25901', '25', 'FUNDO MUNICIPAL DE SAÚDE - ADMINISTRAÇÃO GERAL', NULL),
(30, NULL, '05', '25908', '25', 'HOSPITAL DISTRITAL GONZAGA MOTA/BARRA DO CEARÁ', NULL),
(31, NULL, '10', '25909', '25', 'CENTRO DE ESPECIALIZAÇÕES MÉDICAS JOSÉ DE ALENCAR', NULL),
(32, NULL, '02', '25910', '25', 'HOSPITAL DISTRITAL EVANDRO AYRES DE MOURA', NULL),
(33, NULL, '03', '25911', '25', 'HOSPITAL DISTRITAL  MARIA JOSÉ BARROSO', NULL),
(34, NULL, '08', '25912', '25', 'HOSPITAL LÚCIA DE FÁTIMA/CROA', NULL),
(35, NULL, '06', '25913', '25', 'HOSPITAL DISTRITAL GONZAGA MOTA/JOSÉ WALTER', NULL),
(36, NULL, '07', '25914', '25', 'HOSPITAL DISTRITAL NOSSA SENHORA DA CONCEIÇÃO', NULL),
(37, NULL, '04', '25915', '25', 'HOSPITAL DISTRITAL GONZAGA MOTA/MESSEJANA', NULL),
(38, NULL, '09', '25916', '25', 'HOSPITAL DISTRITAL EDMILSON BARROS DE OLIVEIRA', NULL),
(39, NULL, '86', '25918', '25', 'HOSPITAL DA MULHER', NULL),
(40, '26', '26', '26101', '26', 'SECRETARIA MUNICIPAL DE DESENVOLVIMENTO ECONÔMICO', NULL),
(41, NULL, '64', '26201', '26', 'FUNDAÇÃO DE CULTURA, ESPORTE E TURISMO DE FORTALEZA', NULL),
(42, NULL, '46', '26901', '26', 'FUNDO MUNICIPAL DE DESENVOLVIMENTO SOCIOECONÔMICO', NULL),
(43, NULL, '47', '26902', '26', 'FUNDO MUNICIPAL DE FINANCIAMENTO DO PROGRAMA CREDJOVEM', NULL),
(44, '27', '27', '27101', '27', 'SECRETARIA MUNICIPAL DE INFRAESTRUTURA', NULL),
(45, '28', '28', '28101', '28', 'SECRETARIA MUNICIPAL DE URBANISMO E MEIO AMBIENTE', NULL),
(46, NULL, '74', '28901', '28', 'FUNDO DE DEFESA DO MEIO AMBIENTE', NULL),
(47, '29', '29', '29101', '29', 'SECRETARIA MUNICIPAL DE ESPORTE E LAZER', NULL),
(48, '30', '30', '30101', '30', 'SECRETARIA MUNICIPAL DE TURISMO DE FORTALEZA', NULL),
(49, '31', '31', '31101', '31', 'SECRETARIA MUNICIPAL DE TRABALHO, DESENVOLVIMENTO SOCIAL E COMBATE A FOME', NULL),
(50, NULL, '59', '31901', '31', 'FUNDO MUNICIPAL DE ASSISTÊNCIA SOCIAL', NULL),
(51, '32', '32', '32101', '32', 'SECRETARIA MUNICIPAL DE CULTURA DE FORTALEZA', NULL),
(52, NULL, '49', '32901', '32', 'FUNDO MUNICIPAL DE CULTURA', NULL),
(53, '35', '35', '35101', '35', 'SECRETARIA MUNICIPAL DE CIDADANIA E DIREITOS HUMANOS', NULL),
(54, NULL, '71', '35201', '35', 'FUNDAÇÃO DA CRIANÇA E DA FAMÍLIA CIDADÃ', NULL),
(55, NULL, '76', '35901', '35', 'FUNDO MUNICIPAL DE DEFESA DOS DIREITOS DIFUSOS', NULL),
(56, NULL, '77', '35902', '35', 'FUNDO MUNICIPAL DE DEFESA DOS DIREITOS DA CRIANÇA E DO ADOLESCENTE', NULL),
(57, NULL, '39', '39101', '39', 'SECRETARIA REGIONAL DO CENTRO', NULL),
(58, '40', '40', '40101', '40', 'SECRETARIA REGIONAL I', NULL),
(59, '41', '41', '41101', '41', 'SECRETARIA REGIONAL II', NULL),
(60, '42', '42', '42101', '42', 'SECRETARIA REGIONAL III', NULL),
(61, '43', '43', '43101', '43', 'SECRETARIA REGIONAL IV', NULL),
(62, '44', '44', '44101', '44', 'SECRETARIA REGIONAL V', NULL),
(63, '45', '45', '45101', '45', 'SECRETARIA REGIONAL VI', NULL),
(64, '52', '52', '52101', '52', 'SECRETARIA MUNICIPAL EXTRAORDINÁRIA DA COPA 2014', NULL),
(65, '', '95', '80101', '80', 'RECURSOS SOB A SUPERVISÃO DA SECRETARIA MUNICIPAL DE FINANÇAS', NULL),
(66, NULL, '96', '80102', '80', 'RECURSOS SOB A SUPERVISÃO DA SECRETARIA MUNICIPAL DE PLANEJAMENTO, ORÇAMENTO E GESTÃO', NULL),
(67, '90', '90', '90101', '90', 'RESERVA DE CONTINGÊNCIA', NULL),
(68, '24', '24', '24101', '24', 'SECRETARIA MUNICIPAL DE EDUCAÇÃO', NULL),
(69, '25', '25', '25101', '25', 'SECRETARIA MUNICIPAL DE SAÚDE', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
`id` int(10) unsigned NOT NULL,
  `permission_name` varchar(45) NOT NULL COMMENT 'Action dos módulos',
  `resource_id` int(10) unsigned NOT NULL COMMENT 'ID do controller/módulo',
  `n_amigavel` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=203 ;

--
-- Extraindo dados da tabela `permission`
--

INSERT INTO `permission` (`id`, `permission_name`, `resource_id`, `n_amigavel`) VALUES
(95, 'index', 7, 'Principal'),
(96, 'get-grupos', 7, 'get Grupos'),
(97, 'get-modulos', 7, 'Get Modulos'),
(98, 'grupos', 7, 'Grupos'),
(99, 'grupo-add', 7, 'Adicionar Grupo'),
(100, 'grupo-edit', 7, 'Editar Grupo'),
(101, 'grupo-del', 7, 'Excluir Grupo'),
(102, 'modulos', 7, 'Modulos'),
(103, 'modulo-add', 7, 'Adicionar Modulo'),
(104, 'modulo-edit', 7, 'Editar Modulo'),
(105, 'modulo-del', 7, 'Excluir Modulo'),
(109, 'get-ligacoes', 8, 'Get Ligacoes'),
(110, 'listaligacoes', 8, 'Lista Ligações'),
(111, 'add', 8, 'Adicionar Ligação'),
(112, 'edit', 8, 'Editar Ligação'),
(113, 'del', 8, 'Excluir Ligação'),
(114, 'anotacoes', 8, 'Anotações'),
(115, 'view', 8, 'Detalhes'),
(116, 'index', 8, 'Principal'),
(127, 'index', 9, 'Principal'),
(128, 'change-password', 9, 'Alterar Senha'),
(129, 'forgot-password', 9, 'Recuperar Senha'),
(130, 'reset-password', 9, 'Resetar Senha'),
(131, 'password-reset-confirmation', 9, 'Confirmação de Reset'),
(132, 'logout', 9, 'Sair'),
(133, 'usuarios', 9, 'Principal'),
(134, 'user-add', 9, 'Adicionar Usuário'),
(135, 'user-edit', 9, 'Editar Usuário'),
(136, 'user-del', 9, 'Excluir Usuário'),
(137, 'home', 9, 'Principal'),
(138, 'users', 9, 'Users'),
(139, 'user', 9, 'User'),
(160, 'get-agenda', 4, 'Lista Agenda'),
(161, 'get-ligacoes', 4, 'Lista Ligações'),
(162, 'index', 4, 'Index'),
(163, 'home', 4, 'Home'),
(164, 'update-user', 4, 'Update User'),
(182, 'index', 10, 'Página Principal'),
(183, 'view', 10, 'Visualização de Detalhes'),
(184, 'anotacoes', 10, 'Anotações'),
(185, 'del', 10, 'Excluir'),
(186, 'edit', 10, 'Editar'),
(187, 'add', 10, 'Adicionar'),
(188, 'listacomunicacoes', 10, 'Lista JSON'),
(189, 'get-etapas', 10, 'Pega Etapas'),
(190, 'get-contatos', 6, 'Get Contatos'),
(191, 'listacontatos', 6, 'Lista Contatos'),
(192, 'add', 6, 'Cadastro'),
(193, 'edit', 6, 'Editar'),
(194, 'del', 6, 'Excluir'),
(195, 'index', 6, 'Principal'),
(196, 'listaemails', 6, 'Lista Emails JSON'),
(197, 'get-agenda', 5, 'Get Json'),
(198, 'list-agenda', 5, 'Lista Agenda'),
(199, 'addedit-agenda', 5, 'Crud Agenda'),
(200, 'index', 5, 'Agenda'),
(201, 'list-users', 5, 'Lista Usuários'),
(202, 'view', 5, 'Visualizar Detalhes');

-- --------------------------------------------------------

--
-- Estrutura da tabela `projetos`
--

CREATE TABLE IF NOT EXISTS `projetos` (
`id_proj` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  `data_inicio` datetime DEFAULT NULL,
  `data_termino` datetime DEFAULT NULL,
  `prioridade` int(11) DEFAULT NULL,
  `descricao` longtext,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='	' AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `projetos`
--

INSERT INTO `projetos` (`id_proj`, `titulo`, `data`, `data_inicio`, `data_termino`, `prioridade`, `descricao`, `status`) VALUES
(3, 'Projeto Teste 1', '2014-11-29 09:00:00', '2014-11-30 17:31:00', '2014-11-30 23:00:00', 1, '1', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `projetos_log`
--

CREATE TABLE IF NOT EXISTS `projetos_log` (
`id_log` int(11) NOT NULL,
  `id_projeto` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `descricao` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `resource`
--

CREATE TABLE IF NOT EXISTS `resource` (
`id` int(10) unsigned NOT NULL,
  `resource_name` varchar(50) NOT NULL COMMENT 'Controller do módulo',
  `n_amigavel` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Extraindo dados da tabela `resource`
--

INSERT INTO `resource` (`id`, `resource_name`, `n_amigavel`) VALUES
(4, 'Home\\Controller\\Index', 'Home Page'),
(5, 'Agenda\\Controller\\Index', 'Agenda'),
(6, 'Contatos\\Controller\\Index', 'Contatos'),
(7, 'Grupos\\Controller\\Index', 'Grupos'),
(8, 'Ligacoes\\Controller\\Index', 'Ligações'),
(9, 'Users\\Controller\\User', 'Usuários'),
(10, 'Comunicacoes\\Controller\\Index', 'Comuinicações');

-- --------------------------------------------------------

--
-- Estrutura da tabela `role`
--

CREATE TABLE IF NOT EXISTS `role` (
`rid` int(10) unsigned NOT NULL,
  `role_name` varchar(45) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `role`
--

INSERT INTO `role` (`rid`, `role_name`, `status`) VALUES
(1, 'Super Admin', 'Active');

-- --------------------------------------------------------

--
-- Estrutura da tabela `role_permission`
--

CREATE TABLE IF NOT EXISTS `role_permission` (
`id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL COMMENT 'id grupo/papel',
  `permission_nome` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=593 ;

--
-- Extraindo dados da tabela `role_permission`
--

INSERT INTO `role_permission` (`id`, `role_id`, `permission_nome`) VALUES
(536, 1, 'index'),
(537, 1, 'get-grupos'),
(538, 1, 'get-modulos'),
(539, 1, 'grupos'),
(540, 1, 'grupo-add'),
(541, 1, 'grupo-edit'),
(542, 1, 'grupo-del'),
(543, 1, 'modulos'),
(544, 1, 'modulo-add'),
(545, 1, 'modulo-edit'),
(546, 1, 'modulo-del'),
(547, 1, 'get-ligacoes'),
(548, 1, 'listaligacoes'),
(549, 1, 'add'),
(550, 1, 'edit'),
(551, 1, 'del'),
(552, 1, 'anotacoes'),
(553, 1, 'view'),
(554, 1, 'index'),
(555, 1, 'index'),
(556, 1, 'change-password'),
(557, 1, 'forgot-password'),
(558, 1, 'reset-password'),
(559, 1, 'password-reset-confirmation'),
(560, 1, 'logout'),
(561, 1, 'usuarios'),
(562, 1, 'user-add'),
(563, 1, 'user-edit'),
(564, 1, 'user-del'),
(565, 1, 'home'),
(566, 1, 'users'),
(567, 1, 'user'),
(568, 1, 'get-agenda'),
(569, 1, 'list-agenda'),
(570, 1, 'addedit-agenda'),
(571, 1, 'index'),
(572, 1, 'list-users'),
(573, 1, 'get-agenda'),
(574, 1, 'get-ligacoes'),
(575, 1, 'index'),
(576, 1, 'home'),
(577, 1, 'update-user'),
(578, 1, 'index'),
(579, 1, 'view'),
(580, 1, 'anotacoes'),
(581, 1, 'del'),
(582, 1, 'edit'),
(583, 1, 'add'),
(584, 1, 'listacomunicacoes'),
(585, 1, 'get-etapas'),
(586, 1, 'get-contatos'),
(587, 1, 'listacontatos'),
(588, 1, 'add'),
(589, 1, 'edit'),
(590, 1, 'del'),
(591, 1, 'index'),
(592, 1, 'listaemails');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `email` varchar(101) NOT NULL,
  `password` varchar(45) NOT NULL,
  `login_attempts` int(11) NOT NULL DEFAULT '0',
  `login_attempt_time` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `orgaos` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `last_signed_in` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `login_attempts`, `login_attempt_time`, `first_name`, `last_name`, `orgaos`, `status`, `last_signed_in`) VALUES
(1, 'mscriacoes@gmail.com', 'd7d833534a39afbac08ec536bed7ae9eeac45638', 0, 0, 'Marcio', 'Seabra', '01101,01901', 'Active', '2014-08-29 13:38:48');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL COMMENT 'ID usuario',
  `role_id` int(10) unsigned NOT NULL COMMENT 'ID regra/grupo/tipo'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `user_role`
--

INSERT INTO `user_role` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda`
--
ALTER TABLE `agenda`
 ADD PRIMARY KEY (`id_agenda`);

--
-- Indexes for table `arquivos`
--
ALTER TABLE `arquivos`
 ADD PRIMARY KEY (`id_arquivo`), ADD KEY `id_comunicacao_log` (`id_comunicacao_log`);

--
-- Indexes for table `comunicacoes`
--
ALTER TABLE `comunicacoes`
 ADD PRIMARY KEY (`id_comunicacao`);

--
-- Indexes for table `comunicacoes_log`
--
ALTER TABLE `comunicacoes_log`
 ADD PRIMARY KEY (`id_log`), ADD KEY `id_comunicacao` (`id_comunicacao`);

--
-- Indexes for table `contatos`
--
ALTER TABLE `contatos`
 ADD PRIMARY KEY (`idcontatos`);

--
-- Indexes for table `contatos_emails`
--
ALTER TABLE `contatos_emails`
 ADD PRIMARY KEY (`id`), ADD KEY `id_contato` (`id_contato`);

--
-- Indexes for table `contatos_telefones`
--
ALTER TABLE `contatos_telefones`
 ADD PRIMARY KEY (`id`), ADD KEY `id_contato` (`id_contato`);

--
-- Indexes for table `envolvido_projeto`
--
ALTER TABLE `envolvido_projeto`
 ADD PRIMARY KEY (`id_envolvido`), ADD KEY `id_projeto` (`id_projeto`), ADD KEY `id_etapa` (`id_etapa`);

--
-- Indexes for table `etapas_projeto`
--
ALTER TABLE `etapas_projeto`
 ADD PRIMARY KEY (`id_etapa`), ADD KEY `id_projeto` (`id_projeto`);

--
-- Indexes for table `ligacoes`
--
ALTER TABLE `ligacoes`
 ADD PRIMARY KEY (`id_ligacao`);

--
-- Indexes for table `ligacoes_log`
--
ALTER TABLE `ligacoes_log`
 ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `log_users`
--
ALTER TABLE `log_users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orgao`
--
ALTER TABLE `orgao`
 ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projetos`
--
ALTER TABLE `projetos`
 ADD PRIMARY KEY (`id_proj`);

--
-- Indexes for table `projetos_log`
--
ALTER TABLE `projetos_log`
 ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `resource`
--
ALTER TABLE `resource`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
 ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `role_permission`
--
ALTER TABLE `role_permission`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agenda`
--
ALTER TABLE `agenda`
MODIFY `id_agenda` int(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `arquivos`
--
ALTER TABLE `arquivos`
MODIFY `id_arquivo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `comunicacoes`
--
ALTER TABLE `comunicacoes`
MODIFY `id_comunicacao` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `comunicacoes_log`
--
ALTER TABLE `comunicacoes_log`
MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contatos`
--
ALTER TABLE `contatos`
MODIFY `idcontatos` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=469;
--
-- AUTO_INCREMENT for table `contatos_emails`
--
ALTER TABLE `contatos_emails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=395;
--
-- AUTO_INCREMENT for table `contatos_telefones`
--
ALTER TABLE `contatos_telefones`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=719;
--
-- AUTO_INCREMENT for table `etapas_projeto`
--
ALTER TABLE `etapas_projeto`
MODIFY `id_etapa` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ligacoes`
--
ALTER TABLE `ligacoes`
MODIFY `id_ligacao` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ligacoes_log`
--
ALTER TABLE `ligacoes_log`
MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `log_users`
--
ALTER TABLE `log_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `orgao`
--
ALTER TABLE `orgao`
MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=203;
--
-- AUTO_INCREMENT for table `projetos`
--
ALTER TABLE `projetos`
MODIFY `id_proj` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `projetos_log`
--
ALTER TABLE `projetos_log`
MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `resource`
--
ALTER TABLE `resource`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
MODIFY `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `role_permission`
--
ALTER TABLE `role_permission`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=593;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `arquivos`
--
ALTER TABLE `arquivos`
ADD CONSTRAINT `arquivos_ibfk_1` FOREIGN KEY (`id_comunicacao_log`) REFERENCES `comunicacoes_log` (`id_log`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `comunicacoes_log`
--
ALTER TABLE `comunicacoes_log`
ADD CONSTRAINT `comunicacoes_log_ibfk_1` FOREIGN KEY (`id_comunicacao`) REFERENCES `comunicacoes` (`id_comunicacao`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `contatos_emails`
--
ALTER TABLE `contatos_emails`
ADD CONSTRAINT `contatos_emails_ibfk_1` FOREIGN KEY (`id_contato`) REFERENCES `contatos` (`idcontatos`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `contatos_telefones`
--
ALTER TABLE `contatos_telefones`
ADD CONSTRAINT `contatos_telefones_ibfk_1` FOREIGN KEY (`id_contato`) REFERENCES `contatos` (`idcontatos`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `envolvido_projeto`
--
ALTER TABLE `envolvido_projeto`
ADD CONSTRAINT `envolvido_projeto_ibfk_1` FOREIGN KEY (`id_projeto`) REFERENCES `projetos` (`id_proj`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `envolvido_projeto_ibfk_2` FOREIGN KEY (`id_etapa`) REFERENCES `etapas_projeto` (`id_etapa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `etapas_projeto`
--
ALTER TABLE `etapas_projeto`
ADD CONSTRAINT `etapas_projeto_ibfk_1` FOREIGN KEY (`id_projeto`) REFERENCES `projetos` (`id_proj`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
